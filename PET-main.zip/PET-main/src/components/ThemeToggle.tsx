import { useTheme, type Theme } from "../hooks/useTheme";

const OPTIONS: { value: Theme; label: string }[] = [
  { value: "light", label: "Claro" },
  { value: "dark", label: "Escuro" },
  { value: "high-contrast", label: "Alto Contraste" },
];

export default function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="theme-control">
      <select
        value={theme}
        onChange={e => setTheme(e.target.value as Theme)}
        aria-label="Selecionar tema"
      >
        {OPTIONS.map(option => (
          <option key={option.value} value={option.value}>{option.label}</option>
        ))}
      </select>
    </div>
  );
}
