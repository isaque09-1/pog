import jsPDF from "jspdf";
import type { PETRecord } from "../types";
import { EMPLOYEES } from "../data/employees";

const L = 14;
const R = 196;
const W = R - L;

/* ── helpers ───────────────────────────────────────────────── */
function setBold(doc: jsPDF, size: number) {
  doc.setFont("helvetica", "bold");
  doc.setFontSize(size);
}

function setNormal(doc: jsPDF, size: number) {
  doc.setFont("helvetica", "normal");
  doc.setFontSize(size);
}

function setColor(doc: jsPDF, hex: string) {
  const h = hex.replace("#", "");
  doc.setTextColor(parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16));
}

function fillRect(doc: jsPDF, x: number, y: number, w: number, h: number, hex: string) {
  const hx = hex.replace("#", "");
  doc.setFillColor(parseInt(hx.slice(0, 2), 16), parseInt(hx.slice(2, 4), 16), parseInt(hx.slice(4, 6), 16));
  doc.rect(x, y, w, h, "F");
}

function cell(
  doc: jsPDF,
  x: number, y: number, w: number, h: number,
  text: string,
  opts: { bold?: boolean; size?: number; align?: "left" | "center" | "right"; fillHex?: string; colorHex?: string } = {}
) {
  const { bold = false, size = 7, align = "left", fillHex, colorHex = "#000000" } = opts;
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.2);
  if (fillHex) {
    fillRect(doc, x, y, w, h, fillHex);
    doc.rect(x, y, w, h, "S");
  } else {
    doc.rect(x, y, w, h);
  }
  if (!text) return;
  bold ? setBold(doc, size) : setNormal(doc, size);
  setColor(doc, colorHex);
  const px = align === "center" ? x + w / 2 : align === "right" ? x + w - 1.5 : x + 1.5;
  const jAlign = align === "center" ? "center" : align === "right" ? "right" : "left";
  const lines = doc.splitTextToSize(text, w - 3);
  doc.text(lines[0] ?? "", px, y + h / 2 + size * 0.17, { align: jAlign, baseline: "middle" });
}

function sectionHdr(doc: jsPDF, x: number, y: number, w: number, h: number, text: string) {
  fillRect(doc, x, y, w, h, "#1a1a2e");
  doc.setDrawColor(0, 0, 0);
  doc.rect(x, y, w, h);
  setBold(doc, 7.5);
  setColor(doc, "#ffffff");
  doc.text(text, x + w / 2, y + h / 2 + 1, { align: "center", baseline: "middle" });
}

function labeledField(doc: jsPDF, x: number, y: number, w: number, h: number, label: string, value: string) {
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.2);
  doc.rect(x, y, w, h);
  setBold(doc, 5);
  setColor(doc, "#555555");
  doc.text(label.toUpperCase(), x + 1.5, y + 2.2);
  setNormal(doc, 7);
  setColor(doc, "#000000");
  const lines = doc.splitTextToSize(value, w - 3);
  doc.text(lines[0] ?? "", x + 1.5, y + h - 1.8);
}

/* ── draw check mark using lines (safe, no unicode) ─────────── */
function drawMark(doc: jsPDF, x: number, y: number, w: number, h: number, type: "check" | "cross" | "dash") {
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.8);
  const cx = x + w / 2;
  const cy = y + h / 2;
  const s = Math.min(w, h) * 0.28;
  if (type === "check") {
    doc.line(cx - s, cy, cx - s * 0.2, cy + s * 0.7);
    doc.line(cx - s * 0.2, cy + s * 0.7, cx + s, cy - s * 0.5);
  } else if (type === "cross") {
    doc.line(cx - s * 0.7, cy - s * 0.7, cx + s * 0.7, cy + s * 0.7);
    doc.line(cx + s * 0.7, cy - s * 0.7, cx - s * 0.7, cy + s * 0.7);
  } else {
    doc.line(cx - s, cy, cx + s, cy);
  }
  doc.setLineWidth(0.2);
}

/* ── main export ────────────────────────────────────────────── */
export function generatePDF(pet: PETRecord): void {
  const doc = new jsPDF({ format: "a4", orientation: "portrait", unit: "mm" });
  doc.setLineWidth(0.2);
  doc.setDrawColor(0, 0, 0);

  let y = 10;

  /* ── HEADER ─────────────────────────────────────────────── */
  const hH = 22;

  // Logo
  fillRect(doc, L, y, 28, hH, "#eef4ff");
  doc.rect(L, y, 28, hH);
  setBold(doc, 13);
  setColor(doc, "#0050a0");
  doc.text("Lar", L + 14, y + 8, { align: "center" });
  setNormal(doc, 5.5);
  setColor(doc, "#444444");
  doc.text("Cooperativa", L + 14, y + 13, { align: "center" });

  // Title
  const tX = L + 28, tW = W - 28 - 40;
  fillRect(doc, tX, y, tW, hH, "#f0f4ff");
  doc.rect(tX, y, tW, hH);
  setBold(doc, 9);
  setColor(doc, "#000000");
  const permitTitle = pet.permitType === "PT" ? "PERMISSAO DE TRABALHO - PT" : "PERMISSAO DE ENTRADA E TRABALHO - PET";
  doc.text(permitTitle, tX + tW / 2, y + 7, { align: "center" });
  setNormal(doc, 7.5);
  doc.text("PERMISSAO DE TRABALHO", tX + tW / 2, y + 12, { align: "center" });
  setNormal(doc, 5.5);
  setColor(doc, "#666666");
  doc.text("NUMERO FO 060 330-37", tX + tW / 2, y + 18, { align: "center" });

  // Number box
  const nX = tX + tW;
  fillRect(doc, nX, y, 40, hH, "#fffbe6");
  doc.rect(nX, y, 40, hH);
  setBold(doc, 6.5);
  setColor(doc, "#000000");
  doc.text("NUMERO", nX + 20, y + 4.5, { align: "center" });
  setBold(doc, 12);
  setColor(doc, "#b30000");
  doc.text(`N ${pet.numero}`, nX + 20, y + 12, { align: "center" });
  setNormal(doc, 5.5);
  setColor(doc, "#555555");
  doc.text("REV: 01/10/24", nX + 20, y + 19, { align: "center" });

  y += hH;

  /* ── INFO ROWS ───────────────────────────────────────────── */
  const rH = 7;
  const c3 = W / 3;
  labeledField(doc, L, y, c3, rH, "Unidade", "PET Manager");
  labeledField(doc, L + c3, y, c3, rH, "Empresa", "Organizacao cadastrada");
  labeledField(doc, L + c3 * 2, y, c3, rH, "Data/Hora Inicio da Autorizacao", pet.abertura);
  y += rH;
  labeledField(doc, L, y, c3, rH, "Local", pet.local);
  labeledField(doc, L + c3, y, c3, rH, "Telefone", "(45) 3243-1293");
  labeledField(doc, L + c3 * 2, y, c3, rH, "Data/Hora Termino da Autorizacao", "____/____  ____:____");
  y += rH;
  labeledField(doc, L, y, W, rH, "Tipo / Motivo / Atividade", `${pet.permitType} - ${pet.tipo} - ${pet.setor}`);
  y += rH;

  /* ── WORKERS ─────────────────────────────────────────────── */
  const tH = 5.5;
  sectionHdr(doc, L, y, W, 5, "IDENTIFICACAO DOS TRABALHADORES");
  y += 5;
  cell(doc, L, y, 22, tH, "MATRICULA", { bold: true, fillHex: "#e0e0e0", align: "center" });
  cell(doc, L + 22, y, 75, tH, "NOME COMPLETO", { bold: true, fillHex: "#e0e0e0" });
  cell(doc, L + 97, y, 55, tH, "CARGO / FUNCAO", { bold: true, fillHex: "#e0e0e0" });
  cell(doc, L + 152, y, W - 152, tH, "ASSINATURA", { bold: true, fillHex: "#e0e0e0", align: "center" });
  y += tH;
  for (const w of pet.workers) {
    cell(doc, L, y, 22, tH, w.matricula, { align: "center" });
    cell(doc, L + 22, y, 75, tH, w.name);
    cell(doc, L + 97, y, 55, tH, w.cargo);
    cell(doc, L + 152, y, W - 152, tH, "");
    y += tH;
  }
  // spare row
  cell(doc, L, y, 22, tH, ""); cell(doc, L + 22, y, 75, tH, ""); cell(doc, L + 97, y, 55, tH, ""); cell(doc, L + 152, y, W - 152, tH, "");
  y += tH;

  /* ── VIGIA + RESGATISTAS ─────────────────────────────────── */
  const half = W / 2;
  sectionHdr(doc, L, y, half, 5, "IDENTIFICACAO VIGIA");
  sectionHdr(doc, L + half, y, half, 5, "IDENTIFICACAO RESGATISTAS");
  y += 5;
  cell(doc, L, y, 22, tH, "MATRICULA", { bold: true, fillHex: "#e0e0e0", align: "center" });
  cell(doc, L + 22, y, half - 22, tH, "NOME", { bold: true, fillHex: "#e0e0e0" });
  cell(doc, L + half, y, 22, tH, "MATRICULA", { bold: true, fillHex: "#e0e0e0", align: "center" });
  cell(doc, L + half + 22, y, half - 22, tH, "NOME", { bold: true, fillHex: "#e0e0e0" });
  y += tH;
  const vigRows = Math.max(1, pet.vigias.length);
  for (let i = 0; i < vigRows; i++) {
    const v = pet.vigias[i];
    cell(doc, L, y, 22, tH, v?.matricula ?? "", { align: "center" });
    cell(doc, L + 22, y, half - 22, tH, v?.name ?? "");
    cell(doc, L + half, y, 22, tH, "", { align: "center" });
    cell(doc, L + half + 22, y, half - 22, tH, "");
    y += tH;
  }

  /* ── RESPONSAVEL ─────────────────────────────────────────── */
  sectionHdr(doc, L, y, W, 5, "IDENTIFICACAO DO RESPONSAVEL TECNICO");
  y += 5;
  cell(doc, L, y, 22, tH, "MATRICULA", { bold: true, fillHex: "#e0e0e0", align: "center" });
  cell(doc, L + 22, y, 75, tH, "NOME", { bold: true, fillHex: "#e0e0e0" });
  cell(doc, L + 97, y, 55, tH, "CARGO", { bold: true, fillHex: "#e0e0e0" });
  cell(doc, L + 152, y, W - 152, tH, "ASSINATURA", { bold: true, fillHex: "#e0e0e0", align: "center" });
  y += tH;
  const respEmp = EMPLOYEES.find(e => e.id === pet.responsavelId);
  cell(doc, L, y, 22, tH, respEmp?.matricula ?? "—", { align: "center" });
  cell(doc, L + 22, y, 75, tH, pet.responsavel);
  cell(doc, L + 97, y, 55, tH, respEmp?.cargo ?? "Responsavel Tecnico");
  // signature in pdf
  const sigBoxX = L + 152, sigBoxW = W - 152;
  doc.rect(sigBoxX, y, sigBoxW, tH);
  if (pet.signatureResp) {
    try {
      doc.addImage(pet.signatureResp, "PNG", sigBoxX + 1, y + 0.5, sigBoxW - 2, tH - 1);
    } catch (_) { /* ignore */ }
  }
  y += tH + 2;

  /* ── NR SPECIFIC FIELDS ──────────────────────────────────── */
  sectionHdr(doc, L, y, W, 5, `${pet.nr} - ${pet.nrDef.name.toUpperCase()}`);
  y += 5;

  const fW = W / 2, fH = 6.5;
  const fieldEntries = Object.entries(pet.fields).filter(([k]) => k !== "setor");
  for (let i = 0; i < fieldEntries.length; i += 2) {
    const [k1, v1] = fieldEntries[i];
    const nf1 = pet.nrDef.fields.find(f => f.id === k1);
    const lbl1 = nf1 ? `${nf1.label}${nf1.unit ? ` (${nf1.unit})` : ""}` : k1;
    labeledField(doc, L, y, fW, fH, lbl1, v1 ?? "—");
    if (fieldEntries[i + 1]) {
      const [k2, v2] = fieldEntries[i + 1];
      const nf2 = pet.nrDef.fields.find(f => f.id === k2);
      const lbl2 = nf2 ? `${nf2.label}${nf2.unit ? ` (${nf2.unit})` : ""}` : k2;
      labeledField(doc, L + fW, y, fW, fH, lbl2, v2 ?? "—");
    } else {
      doc.rect(L + fW, y, fW, fH);
    }
    y += fH;
  }
  y += 1;

  /* ── CHECKLIST ───────────────────────────────────────────── */
  if (y > 200) { doc.addPage(); y = 14; }
  sectionHdr(doc, L, y, W, 5, "CHECKLIST DE SEGURANCA");
  y += 5;

  const chkH = 6;
  const ansW = 7;
  const descW = W - 8 - ansW * 3;

  // header row
  cell(doc, L, y, 8, chkH, "No.", { bold: true, fillHex: "#e0e0e0", align: "center" });
  cell(doc, L + 8, y, descW, chkH, "ITEM DE VERIFICACAO", { bold: true, fillHex: "#e0e0e0" });
  cell(doc, R - ansW * 3, y, ansW, chkH, "SIM", { bold: true, fillHex: "#c8f0c8", align: "center" });
  cell(doc, R - ansW * 2, y, ansW, chkH, "NAO", { bold: true, fillHex: "#f0c8c8", align: "center" });
  cell(doc, R - ansW, y, ansW, chkH, "N/A", { bold: true, fillHex: "#e0e0e0", align: "center" });
  y += chkH;

  for (let i = 0; i < pet.nrDef.checklist.length; i++) {
    if (y > 255) { doc.addPage(); y = 14; }
    const item = pet.nrDef.checklist[i];
    const ans = pet.checkAnswers[item.id] ?? "";
    const rowBg = i % 2 === 0 ? "#f8f8f8" : "#ffffff";

    // Number cell
    fillRect(doc, L, y, 8, chkH, rowBg);
    doc.rect(L, y, 8, chkH);
    setNormal(doc, 6.5);
    setColor(doc, "#666666");
    doc.text(String(i + 1).padStart(2, "0"), L + 4, y + chkH / 2 + 1, { align: "center" });

    // Description cell — may need more height for long text
    const labelLines = doc.splitTextToSize(item.label, descW - 3);
    const rowH = Math.max(chkH, labelLines.length * 3.8 + 2);

    fillRect(doc, L + 8, y, descW, rowH, rowBg);
    doc.rect(L + 8, y, descW, rowH);
    setNormal(doc, 6.5);
    setColor(doc, "#111111");
    doc.text(labelLines, L + 10, y + 2.5, { baseline: "top" });

    // Answer cells
    for (const [opt, col, okHex, errHex] of [
      ["SIM", R - ansW * 3, "#d4edda", "#f8f8f8"],
      ["NAO", R - ansW * 2, "#f8d7da", "#f8f8f8"],
      ["N/A", R - ansW, "#e8e8e8", "#f8f8f8"],
    ] as [string, number, string, string][]) {
      const checkAns = ans === "SIM" ? "SIM" : ans === "NÃO" ? "NAO" : ans === "NA" ? "N/A" : "";
      const isChecked = checkAns === opt;
      const bgHex = isChecked ? okHex : rowBg;
      fillRect(doc, col, y, ansW, rowH, bgHex);
      doc.rect(col, y, ansW, rowH);

      if (isChecked) {
        // draw a checkmark using lines — no unicode
        drawMark(doc, col, y, ansW, rowH, opt === "NAO" ? "cross" : opt === "N/A" ? "dash" : "check");
      }
    }
    y += rowH;
  }
  y += 2;

  /* ── EPI ─────────────────────────────────────────────────── */
  if (y > 220) { doc.addPage(); y = 14; }
  sectionHdr(doc, L, y, W, 5, "EQUIPAMENTO DE PROTECAO INDIVIDUAL (EPI)");
  y += 5;

  const epiCols = 2, epiW = W / epiCols, epiH = 5;
  for (let i = 0; i < pet.nrDef.epiList.length; i += epiCols) {
    if (y > 255) { doc.addPage(); y = 14; }
    for (let j = 0; j < epiCols; j++) {
      const epi = pet.nrDef.epiList[i + j];
      const ex = L + j * epiW;
      if (epi !== undefined) {
        doc.rect(ex, y, epiW, epiH);
        // mini checkbox square
        doc.rect(ex + 2, y + 1.5, 2, 2);
        drawMark(doc, ex + 2, y + 1.5, 2, 2, "check");
        setNormal(doc, 6.5);
        setColor(doc, "#111111");
        doc.text(epi, ex + 5.5, y + epiH / 2 + 0.8);
      } else {
        doc.rect(ex, y, epiW, epiH);
      }
    }
    y += epiH;
  }
  y += 2;

  /* ── OBSERVACOES ─────────────────────────────────────────── */
  if (y > 240) { doc.addPage(); y = 14; }
  sectionHdr(doc, L, y, W, 5, "OBSERVACOES");
  y += 5;
  doc.rect(L, y, W, 14);
  y += 15;

  /* ── ORIENTACOES EMERGENCIA ──────────────────────────────── */
  if (y > 240) { doc.addPage(); y = 14; }
  sectionHdr(doc, L, y, W, 5, "ORIENTACOES GERAIS / EMERGENCIA");
  y += 5;
  fillRect(doc, L, y, W, 16, "#fffef0");
  doc.rect(L, y, W, 16);
  setNormal(doc, 6.5);
  setColor(doc, "#333333");
  const oriText = `Em caso de emergencia, acionar: SAMU 192 | Bombeiros 193 | SESMT Ramal 190. ` +
    `O vigia deve permanecer no local, manter comunicacao constante e registrar rondas a cada 30 minutos. ` +
    `A PET deve ser encerrada em caso de condicoes adversas ou risco nao previsto. ` +
    `Todos os trabalhadores devem portar EPIs durante toda a execucao.`;
  doc.text(doc.splitTextToSize(oriText, W - 4), L + 2, y + 3.5, { baseline: "top" });
  y += 17;

  /* ── RONDAS ──────────────────────────────────────────────── */
  if (y > 240) { doc.addPage(); y = 14; }
  sectionHdr(doc, L, y, W, 5, "VIGIA NO LOCAL - REGISTRO DE RONDAS (30 MIN)");
  y += 5;
  const rH2 = 5.5;
  cell(doc, L, y, 18, rH2, "HORA", { bold: true, fillHex: "#e0e0e0", align: "center" });
  cell(doc, L + 18, y, half - 18, rH2, "NOME DO VIGIA", { bold: true, fillHex: "#e0e0e0" });
  cell(doc, L + half, y, 18, rH2, "HORA", { bold: true, fillHex: "#e0e0e0", align: "center" });
  cell(doc, L + half + 18, y, half - 18, rH2, "NOME DO VIGIA", { bold: true, fillHex: "#e0e0e0" });
  y += rH2;
  const rondas = pet.rondas.length > 0 ? pet.rondas : Array(4).fill(null);
  for (let i = 0; i < Math.max(4, rondas.length); i += 2) {
    if (y > 265) break;
    const r1 = rondas[i], r2 = rondas[i + 1];
    cell(doc, L, y, 18, rH2, r1?.time ?? "", { align: "center" });
    cell(doc, L + 18, y, half - 18, rH2, r1?.vigia ?? "");
    cell(doc, L + half, y, 18, rH2, r2?.time ?? "", { align: "center" });
    cell(doc, L + half + 18, y, half - 18, rH2, r2?.vigia ?? "");
    y += rH2;
  }
  y += 2;

  /* ── ASSINATURAS DIGITAIS ────────────────────────────────── */
  if (y > 230) { doc.addPage(); y = 14; }
  sectionHdr(doc, L, y, W, 5, "ASSINATURAS");
  y += 5;

  const sigH = 24;
  const nSigs = pet.signatureVigia ? 2 : 1;
  const sigW = W / nSigs;

  for (let i = 0; i < nSigs; i++) {
    const sx = L + i * sigW;
    const isResp = i === 0;
    const sigData = isResp ? pet.signatureResp : pet.signatureVigia;
    const sigLabel = isResp ? `Responsavel: ${pet.responsavel}` : `Vigia: ${pet.vigias[0]?.name ?? ""}`;

    doc.rect(sx, y, sigW, sigH);
    setBold(doc, 5.5);
    setColor(doc, "#555555");
    doc.text(sigLabel, sx + sigW / 2, y + 3.5, { align: "center" });

    if (sigData) {
      try {
        doc.addImage(sigData, "PNG", sx + 4, y + 5, sigW - 8, sigH - 9);
      } catch (_) { /* ignore */ }
    }
    // baseline
    doc.setDrawColor(0, 0, 0);
    doc.line(sx + 4, y + sigH - 3, sx + sigW - 4, y + sigH - 3);
  }
  y += sigH + 2;

  /* ── CANCELAMENTO + SUPERVISOR ───────────────────────────── */
  if (y > 250) { doc.addPage(); y = 14; }
  labeledField(doc, L, y, 28, rH, "Cancelamento", "");
  labeledField(doc, L + 28, y, 20, rH, "Data", "");
  labeledField(doc, L + 48, y, 18, rH, "Hora", "");
  labeledField(doc, L + 66, y, W - 66, rH, "Motivo / Nome", "");
  y += rH;

  const sw = W / 3;
  cell(doc, L, y, sw, rH, "SUPERVISOR / RESPONSAVEL", { bold: true, fillHex: "#e0e0e0", align: "center" });
  cell(doc, L + sw, y, sw, rH, "MATRICULA", { bold: true, fillHex: "#e0e0e0", align: "center" });
  cell(doc, L + sw * 2, y, sw, rH, "ASSINATURA / MATRICULA", { bold: true, fillHex: "#e0e0e0", align: "center" });
  y += rH;
  cell(doc, L, y, sw, 10, pet.responsavel);
  cell(doc, L + sw, y, sw, 10, respEmp?.matricula ?? "—", { align: "center" });
  doc.rect(L + sw * 2, y, sw, 10);
  if (pet.signatureResp) {
    try { doc.addImage(pet.signatureResp, "PNG", L + sw * 2 + 2, y + 1, sw - 4, 8); } catch (_) { /* */ }
  }
  y += 12;

  /* ── FOOTER ──────────────────────────────────────────────── */
  setNormal(doc, 5.5);
  setColor(doc, "#999999");
  doc.text(
    `PET Manager v2.5.0  |  Gerado em ${new Date().toLocaleString("pt-BR")}  |  ${pet.nr} - ${pet.nrDef.name}`,
    (L + R) / 2, y, { align: "center" }
  );

  doc.save(`PET-${pet.numero}-${pet.nr}.pdf`);
}
