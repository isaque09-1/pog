export type NRCode = "NR-11" | "NR-20" | "NR-33" | "NR-34" | "NR-35";

export interface NRField {
  id: string;
  label: string;
  type: "text" | "number" | "select";
  unit?: string;
  options?: string[];
  required?: boolean;
}

export interface CheckItem {
  id: string;
  label: string;
}

export interface NRDefinition {
  code: NRCode;
  name: string;
  subtitle: string;
  color: string;
  icon: string;
  fields: NRField[];
  checklist: CheckItem[];
  epiList: string[];
}

export const NR_DATA: NRDefinition[] = [
  {
    code: "NR-33",
    name: "Espaço Confinado",
    subtitle: "Trabalho em espaço confinado",
    color: "#3b82f6",
    icon: "⬡",
    fields: [
      { id: "espaco", label: "Identificação do Espaço Confinado", type: "text", required: true },
      { id: "multigas", label: "Nº Aparelho Multi Gases", type: "text", required: true },
      { id: "o2", label: "Concentração O₂", type: "number", unit: "%", required: true },
      { id: "co", label: "Concentração CO", type: "number", unit: "ppm", required: true },
      { id: "h2s", label: "Concentração H₂S", type: "number", unit: "ppm", required: true },
    ],
    checklist: [
      { id: "lel", label: "Limite de explosividade (LIE/LEL) está nulo?" },
      { id: "gases", label: "Possibilidade de formação de gases foi anulada?" },
      { id: "poeira", label: "Poeira e pó em suspensão estão controlados?" },
      { id: "iluminacao", label: "Ambiente iluminado?" },
      { id: "bloqueio", label: "Realizado bloqueio e sinalização (elétrico/mecânico)?" },
      { id: "afogamento", label: "Eliminado risco de afogamento, engolfamento e soterramento?" },
      { id: "nr33trein", label: "Trabalhadores com treinamentos válidos em NR-33?" },
      { id: "fisico", label: "Trabalhadores em condições físicas/clínicas?" },
      { id: "comunicacao", label: "Comunicação clara entre vigia/trabalhadores?" },
      { id: "comunicacao2", label: "Comunicação entre equipe de vigias/resgatistas?" },
      { id: "monitor", label: "Equipamentos de monitoramento testados e calibrados?" },
      { id: "escorada", label: "Escavação escorada? (se +1,5m de profundidade)" },
      { id: "nr18", label: "Trabalhadores com afastamentos válidos em NR-18?" },
    ],
    epiList: [
      "Capacete com jugular",
      "Protetor auricular",
      "Óculos de segurança",
      "Luvas de proteção (mecânica/química)",
      "Botina de segurança (mecânica/química)",
      "Cinto de segurança com talabarte ou trava quedas",
      "Vestimenta impermeável (amônia)",
      "Respirador semi facial (PFF1/2)",
      "Respirador facial completo / EPR",
      "Proteção respiratória conforme mandado",
    ],
  },
  {
    code: "NR-35",
    name: "Trabalho em Altura",
    subtitle: "Trabalho acima de 2 metros",
    color: "#a855f7",
    icon: "△",
    fields: [
      {
        id: "tipo",
        label: "Tipo de Estrutura",
        type: "select",
        options: ["Escada", "Estrutura", "Andaime", "PEMT", "Plataforma Suspensa", "Outro"],
        required: true,
      },
      { id: "altura", label: "Altura Estimada", type: "number", unit: "m", required: true },
      { id: "local", label: "Local / Identificação", type: "text", required: true },
    ],
    checklist: [
      { id: "nr35trein", label: "Trabalhadores com treinamento válido em NR-35?" },
      { id: "sinalizado", label: "Área está sinalizada e isolada?" },
      { id: "impedimentos", label: "Ausência de condições impedidas (chuva, vento, etc)?" },
      { id: "escada_piso", label: "Escada em piso aderente e nivelado?" },
      { id: "escada_travas", label: "Escada com bico/travas nos rodilhos?" },
      { id: "andaime_piso", label: "Andaime possui torção com piso?" },
      { id: "andaime_estaiado", label: "Andaime estaiado (altura +4x base menor)?" },
      { id: "pontos_ancoragem", label: "Pontos seguros de ancoragem disponíveis?" },
      { id: "fisico35", label: "Trabalhadores em condições físicas/clínicas?" },
      { id: "epi_altura", label: "EPI de altura (cinto/talabarte/trava quedas) disponíveis?" },
    ],
    epiList: [
      "Capacete com jugular",
      "Cinto de segurança com talabarte",
      "Trava quedas retrátil",
      "Luvas de proteção",
      "Botina de segurança",
      "Óculos de segurança",
      "Protetor auricular",
    ],
  },
  {
    code: "NR-11",
    name: "Içamento de Carga",
    subtitle: "Movimentação e içamento de materiais",
    color: "#f59e0b",
    icon: "⇧",
    fields: [
      { id: "carga_peso", label: "Peso da Carga", type: "number", unit: "ton", required: true },
      { id: "maquina_cap", label: "Capacidade da Máquina", type: "number", unit: "ton", required: true },
      { id: "equipamento", label: "Equipamento de Içamento", type: "select", options: ["Guindaste", "Empilhadeira", "Ponte Rolante", "Munck", "Talha", "Outro"], required: true },
      { id: "local_manobra", label: "Local da Manobra", type: "text", required: true },
    ],
    checklist: [
      { id: "operador", label: "Operador capacitado e habilitado?" },
      { id: "fisico11", label: "Trabalhadores em condições físicas/clínicas?" },
      { id: "clima11", label: "Ausência de condições impedientes (clima, raios, vento)?" },
      { id: "sinal11", label: "Área está sinalizada e isolada?" },
      { id: "ilum11", label: "Boa iluminação e visibilidade?" },
      { id: "energia11", label: "Manobra distante das redes de energia (alta tensão)?" },
      { id: "art", label: "Plano Rigging e ART estão conformes?" },
      { id: "peso_cap", label: "Peso da carga conforme capacidade da máquina?" },
      { id: "maquina_ok", label: "Máquina, cintas e cordas em boas condições?" },
      { id: "amarra", label: "Carga está amarrada/presa adequadamente?" },
      { id: "cabo_guia", label: "Cabo guia para estabilização da carga disponível?" },
    ],
    epiList: [
      "Capacete com jugular",
      "Luvas de proteção (mecânica)",
      "Botina de segurança com biqueira",
      "Óculos de segurança",
      "Colete refletivo",
      "Protetor auricular",
    ],
  },
  {
    code: "NR-34",
    name: "Descarga Gases/Líquidos",
    subtitle: "Descarga de substâncias inflamáveis",
    color: "#22c55e",
    icon: "⥥",
    fields: [
      { id: "produto", label: "Produto a ser Descarregado", type: "text", required: true },
      { id: "volume", label: "Volume Estimado", type: "number", unit: "L", required: true },
      {
        id: "veiculo",
        label: "Tipo de Veículo",
        type: "select",
        options: ["Caminhão Tanque", "Carreta Tanque", "Isotanque", "Outro"],
        required: true,
      },
      { id: "placa", label: "Placa do Veículo", type: "text", required: true },
    ],
    checklist: [
      { id: "motorista", label: "Motorista capacitado NR-20/MOPP?" },
      { id: "fisico34", label: "Trabalhadores em condições físicas/clínicas?" },
      { id: "clima34", label: "Ausência de condições impedientes (clima, raios, etc)?" },
      { id: "sinal34", label: "Área está sinalizada e isolada?" },
      { id: "eletrico34", label: "Ausência de equipamentos elétricos/eletrônicos ligados?" },
      { id: "extintor34", label: "Equipamento de combate a incêndio próximo?" },
      { id: "saida", label: "Caminhão direcionado para saída?" },
      { id: "aterrado", label: "Caminhão está aterrado (anti-estático)?" },
      { id: "mangueiras", label: "Caminhão, mangueiras e bombas em boas condições?" },
    ],
    epiList: [
      "Capacete com jugular",
      "Óculos de segurança",
      "Luvas de proteção química",
      "Botina de segurança antiestática",
      "Vestimenta impermeável",
      "Respirador semi facial com filtro químico",
    ],
  },
  {
    code: "NR-20",
    name: "Trabalho a Quente",
    subtitle: "Inflamáveis e combustíveis",
    color: "#ef4444",
    icon: "🔥",
    fields: [
      {
        id: "tipo_trabalho",
        label: "Tipo de Trabalho a Quente",
        type: "select",
        options: ["Solda", "Corte", "Brasagem", "Maçarico", "Esmerilhamento", "Outro"],
        required: true,
      },
      { id: "material", label: "Material / Estrutura Trabalhada", type: "text", required: true },
      { id: "local_tq", label: "Local Exato", type: "text", required: true },
    ],
    checklist: [
      { id: "equip_tq", label: "Equipamentos e ferramentas em boas condições?" },
      { id: "sinal20", label: "Área está sinalizada e isolada?" },
      { id: "bloq20", label: "Realizado bloqueio elétrico/mecânico?" },
      { id: "inflamavel", label: "Retirado todo inflamável do ambiente?" },
      { id: "combustivel", label: "Retirado material combustível da área?" },
      { id: "lonas", label: "Lonas resistentes a fogo para recolher fagulhas posicionadas?" },
      { id: "aberturas", label: "Aberturas nas paredes e piso foram cobertas?" },
      { id: "extintor20", label: "Equipamento de combate a incêndio próximo?" },
      { id: "vigia_incendio", label: "Vigias capacitados em combate a incêndio (ronda 30min)?" },
    ],
    epiList: [
      "Capacete com jugular",
      "Máscara de solda / óculos de corte",
      "Avental de couro",
      "Luvas de raspa de couro",
      "Botina de segurança",
      "Perneira de couro",
      "Respirador semi facial (P2 ou específico)",
      "Protetor auricular",
    ],
  },
];

export const NR_COLORS: Record<NRCode, string> = {
  "NR-11": "#f59e0b",
  "NR-20": "#ef4444",
  "NR-33": "#3b82f6",
  "NR-34": "#22c55e",
  "NR-35": "#a855f7",
};

export type CheckAnswer = "SIM" | "NÃO" | "NA";
