export type PETRole = "Trabalhador" | "Líder de Equipe" | "Responsável Técnico" | "Vigia";

export interface Employee {
  id: string;
  name: string;
  matricula: string;
  cargo: string;
  setor: string;
  treinamentos: string[];
}

export const EMPLOYEES: Employee[] = [
  { id: "e1", name: "Carlos Alberto Mendes", matricula: "12345", cargo: "Operador de Produção", setor: "Operacional", treinamentos: ["NR-33", "NR-35", "NR-11"] },
  { id: "e2", name: "Ana Paula Lima", matricula: "12346", cargo: "Técnica de Segurança", setor: "SESMT", treinamentos: ["NR-33", "NR-35", "NR-11", "NR-20", "NR-34"] },
  { id: "e3", name: "João Carlos Silva", matricula: "12347", cargo: "Operador de Guindaste", setor: "Produção", treinamentos: ["NR-11", "NR-35"] },
  { id: "e4", name: "Marcos Vieira Santos", matricula: "12348", cargo: "Soldador", setor: "Manutenção", treinamentos: ["NR-20", "NR-35"] },
  { id: "e5", name: "Renata Costa Alves", matricula: "12349", cargo: "Mecânica Industrial", setor: "Manutenção", treinamentos: ["NR-33", "NR-11", "NR-20"] },
  { id: "e6", name: "Paulo Henrique Rocha", matricula: "12350", cargo: "Auxiliar de Produção", setor: "Produção", treinamentos: ["NR-33", "NR-35"] },
  { id: "e7", name: "Fernanda Gomes Albuquerque", matricula: "12351", cargo: "Engenheira de Segurança", setor: "SESMT", treinamentos: ["NR-33", "NR-35", "NR-11", "NR-20", "NR-34"] },
  { id: "e8", name: "Lucas Alves Pereira", matricula: "12352", cargo: "Eletricista Industrial", setor: "Manutenção", treinamentos: ["NR-33", "NR-35", "NR-11"] },
  { id: "e9", name: "Bruna Martins Ferreira", matricula: "12353", cargo: "Motorista de Caminhão", setor: "Logística", treinamentos: ["NR-34", "NR-20"] },
  { id: "e10", name: "Thiago Nunes Barbosa", matricula: "12354", cargo: "Inspetor de Qualidade", setor: "Controle de Qualidade", treinamentos: ["NR-35", "NR-33"] },
  { id: "e11", name: "Daniela Sousa Castro", matricula: "12355", cargo: "Técnica de Manutenção", setor: "Manutenção", treinamentos: ["NR-33", "NR-11", "NR-35", "NR-20"] },
  { id: "e12", name: "Roberto Lemos Faria", matricula: "12356", cargo: "Operador de Empilhadeira", setor: "Logística", treinamentos: ["NR-11"] },
  { id: "e13", name: "Priscila Andrade Lima", matricula: "12357", cargo: "Vigia de Segurança", setor: "SESMT", treinamentos: ["NR-33", "NR-35", "NR-11", "NR-20", "NR-34"] },
  { id: "e14", name: "Eduardo Carvalho Torres", matricula: "12358", cargo: "Vigia de Segurança", setor: "SESMT", treinamentos: ["NR-33", "NR-35", "NR-11", "NR-20"] },
  { id: "e15", name: "Mariana Oliveira Dias", matricula: "12359", cargo: "Técnico de Segurança", setor: "SESMT", treinamentos: ["NR-33", "NR-35", "NR-11", "NR-20", "NR-34"] },
];

export const VIGIAS = EMPLOYEES.filter(e =>
  e.cargo.toLowerCase().includes("vigia") || e.cargo.toLowerCase().includes("segurança") || e.setor === "SESMT"
);

export const RESPONSAVEIS = EMPLOYEES.filter(e =>
  e.cargo.toLowerCase().includes("técnic") ||
  e.cargo.toLowerCase().includes("engenheir") ||
  e.cargo.toLowerCase().includes("segurança")
);
