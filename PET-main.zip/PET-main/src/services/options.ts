import { supabase } from "../lib/supabase";

export type OrganizationOption = { id: string; category: string; label: string };

export async function listOrganizationOptions(organizationId: string, category?: string): Promise<OrganizationOption[]> {
  if (!supabase) throw new Error("Supabase não configurado.");
  let query = supabase.from("organization_options").select("id, category, label").eq("organization_id", organizationId).eq("active", true).order("label");
  if (category) query = query.eq("category", category);
  const { data, error } = await query;
  if (error) throw error;
  return data ?? [];
}

export async function createOrganizationOption(organizationId: string, category: string, label: string): Promise<OrganizationOption> {
  if (!supabase) throw new Error("Supabase não configurado.");
  const { data, error } = await supabase.from("organization_options").upsert({ organization_id: organizationId, category, label: label.trim(), active: true }, { onConflict: "organization_id,category,label" }).select("id, category, label").single();
  if (error) throw error;
  return data;
}