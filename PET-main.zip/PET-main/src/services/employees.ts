import { supabase } from "../lib/supabase";
import type { Employee } from "../data/employees";

export async function listOrganizationEmployees(organizationId: string): Promise<Employee[]> {
  if (!supabase) throw new Error("Supabase não configurado.");
  const { data, error } = await supabase
    .from("employees")
    .select("id, full_name, matricula, cargo, setor, treinamentos")
    .eq("organization_id", organizationId)
    .eq("active", true)
    .order("full_name");
  if (error) throw error;
  return (data ?? []).map(employee => ({
    id: employee.id,
    name: employee.full_name,
    matricula: employee.matricula,
    cargo: employee.cargo,
    setor: employee.setor,
    treinamentos: employee.treinamentos ?? [],
  }));
}

export async function createOrganizationEmployee(organizationId: string, employee: Omit<Employee, "id">): Promise<Employee> {
  if (!supabase) throw new Error("Supabase não configurado.");
  const { data, error } = await supabase
    .from("employees")
    .insert({
      organization_id: organizationId,
      full_name: employee.name,
      matricula: employee.matricula,
      cargo: employee.cargo,
      setor: employee.setor,
      treinamentos: employee.treinamentos,
    })
    .select("id, full_name, matricula, cargo, setor, treinamentos")
    .single();
  if (error) throw error;
  return {
    id: data.id,
    name: data.full_name,
    matricula: data.matricula,
    cargo: data.cargo,
    setor: data.setor,
    treinamentos: data.treinamentos ?? [],
  };
}

export async function updateOrganizationEmployee(organizationId: string, employee: Employee): Promise<Employee> {
  if (!supabase) throw new Error("Supabase não configurado.");
  const { data, error } = await supabase
    .from("employees")
    .update({
      full_name: employee.name,
      matricula: employee.matricula,
      cargo: employee.cargo,
      setor: employee.setor,
      treinamentos: employee.treinamentos,
    })
    .eq("id", employee.id)
    .eq("organization_id", organizationId)
    .select("id, full_name, matricula, cargo, setor, treinamentos")
    .single();
  if (error) throw error;
  return {
    id: data.id,
    name: data.full_name,
    matricula: data.matricula,
    cargo: data.cargo,
    setor: data.setor,
    treinamentos: data.treinamentos ?? [],
  };
}

export async function deactivateOrganizationEmployee(organizationId: string, employeeId: string): Promise<void> {
  if (!supabase) throw new Error("Supabase não configurado.");
  const { error } = await supabase
    .from("employees")
    .update({ active: false })
    .eq("id", employeeId)
    .eq("organization_id", organizationId);
  if (error) throw error;
}
