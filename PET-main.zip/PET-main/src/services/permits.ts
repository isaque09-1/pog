import { NR_DATA } from "../data/nrData";
import type { Employee } from "../data/employees";
import type { PETRecord, PermitType } from "../types";
import { supabase } from "../lib/supabase";

type PermitRow = {
  id: string;
  organization_id: string;
  number: string;
  permit_type: PermitType;
  nr_code: string;
  sector: string;
  location: string;
  title: string;
  responsible_user_id: string;
  status: PETRecord["status"];
  fields: Record<string, string>;
  check_answers: PETRecord["checkAnswers"];
  signature_resp: string | null;
  signature_vigia: string | null;
  opened_at: string;
  closed_at: string | null;
  cancel_reason: string | null;
  permit_workers: { employee: EmployeeRow[] }[];
  permit_watchers: { employee: EmployeeRow[] }[];
};

type EmployeeRow = {
  id: string;
  full_name: string;
  matricula: string;
  cargo: string;
  setor: string;
  treinamentos: string[];
};

function employeeFromRow(employee: EmployeeRow): Employee {
  return {
    id: employee.id,
    name: employee.full_name,
    matricula: employee.matricula,
    cargo: employee.cargo,
    setor: employee.setor,
    treinamentos: employee.treinamentos ?? [],
  };
}

function profileAsEmployee(profile: { id: string; full_name: string; matricula: string | null }): Employee {
  return {
    id: profile.id,
    name: profile.full_name,
    matricula: profile.matricula ?? "",
    cargo: "Usuário da organização",
    setor: "",
    treinamentos: [],
  };
}

export async function listPermits(organizationId: string): Promise<PETRecord[]> {
  if (!supabase) throw new Error("Supabase não configurado.");

  const { data, error } = await supabase
    .from("permits")
    .select("id, organization_id, number, permit_type, nr_code, sector, location, title, responsible_user_id, status, fields, check_answers, signature_resp, signature_vigia, opened_at, closed_at, cancel_reason, permit_workers(employee:employees(id, full_name, matricula, cargo, setor, treinamentos)), permit_watchers(employee:employees(id, full_name, matricula, cargo, setor, treinamentos))")
    .eq("organization_id", organizationId)
    .order("opened_at", { ascending: false });

  if (error) throw error;
  const rows = (data ?? []) as PermitRow[];
  const responsibleIds = [...new Set(rows.map(row => row.responsible_user_id))];
  const { data: profiles, error: profileError } = responsibleIds.length
    ? await supabase.from("profiles").select("id, full_name, matricula").in("id", responsibleIds)
    : { data: [], error: null };

  if (profileError) throw profileError;
  const profileMap = new Map((profiles ?? []).map(profile => [profile.id, profileAsEmployee(profile)]));

  return rows.map(row => {
    const nrDef = NR_DATA.find(definition => definition.code === row.nr_code) ?? NR_DATA[0];
    const responsible = profileMap.get(row.responsible_user_id);
    return {
      id: row.id,
      permitType: row.permit_type,
      numero: row.number,
      nr: nrDef.code,
      setor: row.sector,
      local: row.location,
      tipo: row.title,
      responsavel: responsible?.name ?? "Usuário da organização",
      responsavelId: row.responsible_user_id,
      vigias: row.permit_watchers?.flatMap(item => item.employee.map(employeeFromRow)) ?? [],
      workers: row.permit_workers?.flatMap(item => item.employee.map(employeeFromRow)) ?? [],
      fields: row.fields ?? {},
      checkAnswers: row.check_answers ?? {},
      signatureResp: row.signature_resp ?? undefined,
      signatureVigia: row.signature_vigia ?? undefined,
      abertura: new Date(row.opened_at).toLocaleString("pt-BR"),
      encerramento: row.closed_at ? new Date(row.closed_at).toLocaleString("pt-BR") : undefined,
      status: row.status,
      cancelReason: row.cancel_reason ?? undefined,
      nrDef,
      rondas: [],
    };
  });
}

export async function createPermit(organizationId: string, userId: string, permit: PETRecord): Promise<void> {
  if (!supabase) throw new Error("Supabase não configurado.");

  const { data: created, error } = await supabase.rpc("create_permit_with_people", {
    payload: {
      organization_id: organizationId,
      number: permit.numero,
      permit_type: permit.permitType,
      nr_code: permit.nr,
      sector: permit.setor,
      location: permit.local,
      title: permit.tipo,
      status: permit.status,
      fields: permit.fields,
      check_answers: permit.checkAnswers,
      signature_resp: permit.signatureResp ?? null,
      signature_vigia: permit.signatureVigia ?? null,
      opened_at: new Date(permit.abertura).toISOString(),
      worker_ids: permit.workers.map(worker => worker.id),
      watcher_ids: permit.vigias.map(watcher => watcher.id),
    },
  });

  if (error) throw error;
  if (!created) throw new Error("A permissão foi criada sem identificador.");
}

export async function closePermit(id: string, mode: "encerrar" | "cancelar", reason?: string): Promise<void> {
  if (!supabase) throw new Error("Supabase não configurado.");

  const { error } = await supabase.rpc("close_permit", {
    target_permit_id: id,
    target_status: mode === "cancelar" ? "cancelada" : "encerrada",
    target_reason: reason ?? null,
  });

  if (error) throw error;
}
