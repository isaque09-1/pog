import type { Employee } from "./data/employees";
import type { NRCode, NRDefinition, CheckAnswer } from "./data/nrData";

export type { CheckAnswer };

export interface Ronda {
  id: string;
  time: string;
  vigia: string;
  note: string;
  ok: boolean;
}

export type PermitType = "PET" | "PT";

export interface PETRecord {
  id: string;
  permitType: PermitType;
  numero: string;
  nr: NRCode;
  setor: string;
  local: string;
  tipo: string;
  responsavel: string;
  responsavelId: string;
  vigias: Employee[];
  workers: Employee[];
  fields: Record<string, string>;
  checkAnswers: Record<string, CheckAnswer>;
  abertura: string;
  encerramento?: string;
  status: "aberta" | "encerrada" | "cancelada";
  cancelReason?: string;
  nrDef: NRDefinition;
  rondas: Ronda[];
  signatureResp?: string;
  signatureVigia?: string;
}
