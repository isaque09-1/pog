import { useEffect, useState } from "react";
import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import type { PETRecord, Ronda } from "./types";
import Login from "./screens/Login";
import NovaPET from "./screens/NovaPET";
import VigiaView from "./screens/VigiaView";
import Professionals from "./screens/Professionals";
import { EMPLOYEES, Employee } from "./data/employees";
import { NR_COLORS, NRCode, NR_DATA, CheckAnswer } from "./data/nrData";
import { isSupabaseConfigured, supabase } from "./lib/supabase";
import { closePermit, createPermit, listPermits } from "./services/permits";
import { createOrganizationEmployee, listOrganizationEmployees } from "./services/employees";
import { createOrganizationOption, listOrganizationOptions, type OrganizationOption } from "./services/options";
import ThemeToggle from "./components/ThemeToggle";

/* ─── Shared Types (re-exported for convenience) ────────── */
export type { Ronda, PETRecord } from "./types";

type Screen = "login" | "dashboard" | "nova-pet" | "vigia" | "professionals";
type Period = "dia" | "semanal" | "mensal" | "semestral" | "anual";
type UserRole = "admin" | "gestor" | "tecnico" | "vigia";

/* ─── Seed PETs ─────────────────────────────────────────── */
function makeCheck(ids: string[]): Record<string, CheckAnswer> {
  return Object.fromEntries(ids.map(id => [id, "SIM" as CheckAnswer]));
}

const INITIAL_PETS: PETRecord[] = (() => {
  const nrMap = Object.fromEntries(NR_DATA.map(n => [n.code, n]));
  const emp = (id: string) => EMPLOYEES.find(e => e.id === id)!;

  const p1nr = nrMap["NR-33"];
  const p2nr = nrMap["NR-35"];
  const p3nr = nrMap["NR-11"];
  const p4nr = nrMap["NR-20"];
  const p5nr = nrMap["NR-35"];

  return [
    {
      id: "p1", numero: "452610", nr: "NR-33", setor: "Operacional", local: "Tanque T-07",
      permitType: "PET",
      tipo: p1nr.name, responsavel: emp("e2").name, responsavelId: "e2",
      vigias: [emp("e13")], workers: [emp("e1")],
      fields: { setor: "Operacional", espaco: "Tanque T-07", multigas: "MG-4521", o2: "20.9", co: "0", h2s: "0" } as Record<string, string>,
      checkAnswers: makeCheck(["lel","gases","poeira","iluminacao","bloqueio","afogamento","nr33trein","fisico","comunicacao","comunicacao2","monitor"]),
      abertura: "05/09 08:14", status: "aberta", nrDef: p1nr, rondas: [],
    },
    {
      id: "p2", numero: "452611", nr: "NR-35", setor: "Manutenção", local: "Torre de Resfriamento",
      permitType: "PET",
      tipo: p2nr.name, responsavel: emp("e7").name, responsavelId: "e7",
      vigias: [emp("e14")], workers: [emp("e8")],
      fields: { setor: "Manutenção", altura: "8.5", local: "Torre de Resfriamento" } as Record<string, string>,
      checkAnswers: makeCheck(["nr35trein","sinalizado","impedimentos","escada_piso","pontos_ancoragem","fisico35","epi_altura"]),
      abertura: "05/09 09:00", status: "aberta", nrDef: p2nr, rondas: [],
    },
    {
      id: "p3", numero: "452612", nr: "NR-11", setor: "Produção", local: "Galpão Central",
      permitType: "PET",
      tipo: p3nr.name, responsavel: emp("e2").name, responsavelId: "e2",
      vigias: [emp("e15")], workers: [emp("e3")],
      fields: { setor: "Produção", carga_peso: "2.5", maquina_cap: "5.0", equipamento: "Ponte Rolante", local_manobra: "Galpão Central" } as Record<string, string>,
      checkAnswers: makeCheck(["operador","fisico11","clima11","sinal11","ilum11","peso_cap","maquina_ok","amarra","cabo_guia"]),
      abertura: "05/09 07:30", status: "aberta", nrDef: p3nr, rondas: [],
    },
    {
      id: "p4", numero: "452613", nr: "NR-20", setor: "Controle de Qualidade", local: "Sala de GLP",
      permitType: "PET",
      tipo: p4nr.name, responsavel: emp("e7").name, responsavelId: "e7",
      vigias: [emp("e13")], workers: [emp("e4")],
      fields: { setor: "Controle de Qualidade", material: "GLP", local_tq: "Sala de GLP" } as Record<string, string>,
      checkAnswers: makeCheck(["equip_tq","sinal20","bloq20","inflamavel","combustivel","extintor20","vigia_incendio"]),
      abertura: "05/09 10:45", status: "aberta", nrDef: p4nr, rondas: [],
    },
    {
      id: "p5", numero: "452614", nr: "NR-35", setor: "Operacional", local: "Silo S-03",
      permitType: "PET",
      tipo: p5nr.name, responsavel: emp("e2").name, responsavelId: "e2",
      vigias: [emp("e14")], workers: [emp("e5")],
      fields: { setor: "Operacional", altura: "12.0", local: "Silo S-03" } as Record<string, string>,
      checkAnswers: makeCheck(["nr35trein","sinalizado","impedimentos","pontos_ancoragem","fisico35","epi_altura"]),
      abertura: "05/09 11:20", status: "aberta", nrDef: p5nr, rondas: [],
    },
  ];
})();

/* ─── Period Data ───────────────────────────────────────── */
const MULT: Record<Period, number> = { dia: 1, semanal: 5, mensal: 22, semestral: 130, anual: 260 };

const LOCAL_COLORS = [
  "#00d4aa", "#f59e0b", "#3b82f6", "#a855f7", "#ef4444", "#22c55e", "#ec4899", "#06b6d4",
];

function getPeriodData(pets: PETRecord[], period: Period) {
  const m = MULT[period];
  const nrCount: Record<NRCode, number> = { "NR-11": 0, "NR-20": 0, "NR-33": 0, "NR-34": 0, "NR-35": 0 };
  pets.forEach(p => { nrCount[p.nr] = (nrCount[p.nr] ?? 0) + 1; });
  const nrData = Object.entries(nrCount).map(([name, val]) => ({
    name,
    value: Math.max(1, Math.round(val * m)),
  }));
  const localMap: Record<string, number> = {};
  pets.forEach(p => { localMap[p.local] = (localMap[p.local] ?? 0) + 1; });
  const localData = Object.entries(localMap)
    .sort((a, b) => b[1] - a[1])
    .map(([name, val], i) => ({
      name,
      value: Math.max(1, Math.round(val * m)),
      color: LOCAL_COLORS[i % LOCAL_COLORS.length],
    }));
  const setorMap: Record<string, number> = {};
  pets.forEach(p => { setorMap[p.setor] = (setorMap[p.setor] ?? 0) + 1; });
  const setorData = [
    { setor: "Operacional", total: Math.round((setorMap["Operacional"] ?? 0) * m + 2 * m) },
    { setor: "Produção", total: Math.round((setorMap["Produção"] ?? 0) * m + 1 * m) },
    { setor: "Manutenção", total: Math.round((setorMap["Manutenção"] ?? 0) * m + 1 * m) },
    { setor: "C. Qualidade", total: Math.round((setorMap["Controle de Qualidade"] ?? 0) * m) || m },
    { setor: "Adm.", total: Math.round((setorMap["Administrativo"] ?? 0) * m) || m },
  ];
  return { nrData, localData, setorData };
}

/* ─── Tooltip Components ─────────────────────────────────── */
function PieTip({ active, payload }: { active?: boolean; payload?: { name: string; value: number }[] }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg px-3 py-2 text-xs" style={{ background: "var(--secondary)", border: "1px solid var(--border)", color: "var(--foreground)" }}>
      <div className="font-bold">{payload[0].name}</div>
      <div style={{ color: "var(--primary)" }}>{payload[0].value} permissões</div>
    </div>
  );
}

function BarTip({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg px-3 py-2 text-xs" style={{ background: "var(--secondary)", border: "1px solid var(--border)", color: "var(--foreground)" }}>
      <div className="font-bold">{label}</div>
      <div style={{ color: "var(--primary)" }}>{payload[0].value} permissões</div>
    </div>
  );
}

/* ─── Icons ─────────────────────────────────────────────── */
function IconShield() {
  return (
    <svg width="16" height="16" viewBox="0 0 20 20" fill="none">
      <path d="M10 2L3 5.5v5c0 4 3.1 7.4 7 8 3.9-.6 7-4 7-8v-5L10 2z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M7 10l2 2 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function IconPlus() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M8 3v10M3 8h10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function IconLogout() {
  return (
    <svg width="16" height="16" viewBox="0 0 18 18" fill="none">
      <path d="M7 3H4a1 1 0 00-1 1v10a1 1 0 001 1h3M12 13l4-4-4-4M16 9H7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function IconX() {
  return (
    <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
      <path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" />
    </svg>
  );
}

function IconDownload() {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <path d="M8 2v8M5 7l3 3 3-3" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M3 12h10" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );
}

function IconEye() {
  return (
    <svg width="14" height="14" viewBox="0 0 22 22" fill="none">
      <path d="M1 11S4.5 5 11 5s10 6 10 6-3.5 6-10 6S1 11 1 11z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
      <circle cx="11" cy="11" r="2.5" stroke="currentColor" strokeWidth="1.8" />
    </svg>
  );
}

/* ─── Dashboard ─────────────────────────────────────────── */
function Dashboard({
  pets,
  userName,
  userRole,
  onNovaPET,
  onProfessionals,
  onLogout,
  onVigia,
  onClosePet,
  justCreatedId,
  onSeenNew,
}: {
  pets: PETRecord[];
  userName: string;
  userRole: UserRole;
  onNovaPET: () => void;
  onProfessionals: () => void;
  onLogout: () => void;
  onVigia: (pet: PETRecord) => void;
  onClosePet: (id: string, mode: "encerrar" | "cancelar", reason?: string) => void;
  justCreatedId: string | null;
  onSeenNew: () => void;
}) {
  const [period, setPeriod] = useState<Period>("dia");
  const [pieDim, setPieDim] = useState<"nr" | "local">("nr");
  const [activeTab, setActiveTab] = useState<"abertas" | "historico">("abertas");
  const [closeModal, setCloseModal] = useState<{ petId: string; step: "choose" | "reason" } | null>(null);
  const [cancelReason, setCancelReason] = useState("");
  const [highlightId, setHighlightId] = useState<string | null>(null);

  useEffect(() => {
    if (!justCreatedId) return;
    setActiveTab("abertas");
    const timer = window.setTimeout(() => {
      const el = document.getElementById(`pet-card-${justCreatedId}`);
      el?.scrollIntoView({ behavior: "smooth", block: "center" });
      setHighlightId(justCreatedId);
      onSeenNew();
    }, 150);
    return () => window.clearTimeout(timer);
  }, [justCreatedId, onSeenNew]);

  useEffect(() => {
    if (!highlightId) return;
    const timer = window.setTimeout(() => setHighlightId(null), 2500);
    return () => window.clearTimeout(timer);
  }, [highlightId]);

  async function downloadReport(pet: PETRecord) {
    try {
      const { generatePDF } = await import("./utils/generatePDF");
      generatePDF(pet);
    } catch (error) {
      console.error("Não foi possível gerar o relatório.", error);
      window.alert("Não foi possível gerar o relatório. Tente novamente.");
    }
  }

  const openPets = pets.filter(p => p.status === "aberta");
  const historyPets = pets.filter(p => p.status === "encerrada" || p.status === "cancelada");
  const { nrData, localData, setorData } = getPeriodData(pets, period);
  const pieData = pieDim === "nr" ? nrData : localData;
  const totalPie = pieData.reduce((a, b) => a + b.value, 0);

  const PERIODS: { key: Period; label: string }[] = [
    { key: "dia", label: "Dia" },
    { key: "semanal", label: "Semanal" },
    { key: "mensal", label: "Mensal" },
    { key: "semestral", label: "Semestral" },
    { key: "anual", label: "Anual" },
  ];

  function openCloseModal(petId: string) {
    setCancelReason("");
    setCloseModal({ petId, step: "choose" });
  }

  function confirmClose(mode: "encerrar" | "cancelar") {
    if (!closeModal) return;
    if (mode === "cancelar" && closeModal.step === "choose") {
      setCloseModal({ petId: closeModal.petId, step: "reason" });
      return;
    }
    onClosePet(closeModal.petId, mode, mode === "cancelar" ? cancelReason : undefined);
    setCloseModal(null);
    setCancelReason("");
  }

  return (
    <div className="theme-screen flex flex-col min-h-full pb-10" style={{ background: "var(--background)" }}>
      {/* top bar */}
      <div className="flex items-center justify-between px-5 pt-12 pb-4">
        <div>
          <div className="flex items-center gap-2 mb-0.5">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}>
              <IconShield />
            </div>
            <span className="font-bold text-base" style={{ color: "var(--foreground)" }}>PET Manager</span>
          </div>
          <div className="text-[10px] pl-9" style={{ color: "var(--muted-foreground)", fontFamily: "'JetBrains Mono',monospace" }}>
            {userName.split(" ")[0]} · {userRole === "vigia" ? "Vigia" : userRole === "admin" ? "Administrador" : userRole === "gestor" ? "Gestor" : "Técnico"}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          {userRole !== "vigia" && (
            <button
              onClick={onNovaPET}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-bold"
              style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
            >
              <IconPlus />
              Nova permissão
            </button>
          )}
          {(userRole === "admin" || userRole === "gestor") && (
            <button onClick={onProfessionals} className="flex items-center gap-1 px-3 py-2.5 rounded-xl text-xs" style={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--secondary-foreground)" }}>
              Profissionais
            </button>
          )}
          <button
            onClick={onLogout}
            className="flex items-center gap-1 px-3 py-2.5 rounded-xl text-xs"
            style={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--muted-foreground)" }}
          >
            <IconLogout />
          </button>
        </div>
      </div>

      {/* stats */}
      <div className="px-5 mb-5">
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: "Permissões Abertas", value: openPets.length, color: "var(--primary)" },
            { label: "Total Geral", value: pets.length, color: "var(--warning)" },
            { label: "Encerradas", value: pets.filter(p => p.status === "encerrada").length, color: "var(--muted-foreground)" },
            { label: "Canceladas", value: pets.filter(p => p.status === "cancelada").length, color: "var(--danger)" },
          ].map(s => (
            <div key={s.label} className="rounded-xl p-3.5" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
              <div className="text-2xl font-bold leading-none mb-1" style={{ color: s.color }}>{s.value}</div>
              <div className="text-[10px] leading-tight" style={{ color: "var(--muted-foreground)" }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* period filter */}
      <div className="px-5 mb-5">
        <div className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--muted-foreground)", fontFamily: "'JetBrains Mono',monospace" }}>
          Período Amostrado
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
          {PERIODS.map(p => (
            <button
              key={p.key}
              onClick={() => setPeriod(p.key)}
              className="flex-shrink-0 px-4 py-2 rounded-lg text-xs font-semibold transition-all"
              style={{
                background: period === p.key ? "var(--primary)" : "var(--card)",
                color: period === p.key ? "var(--primary-foreground)" : "var(--muted-foreground)",
                border: `1px solid ${period === p.key ? "var(--primary)" : "var(--border)"}`,
              }}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* pie chart */}
      <div className="px-5 mb-5">
        <div className="rounded-2xl p-4" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
          {/* header + dim toggle */}
          <div className="flex items-start justify-between mb-4">
            <div>
              <div className="text-sm font-bold" style={{ color: "var(--foreground)" }}>
                {pieDim === "nr" ? "Permissões por Norma Regulamentadora" : "Permissões por Local do Serviço"}
              </div>
              <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>Total: {totalPie} PETs</div>
            </div>
            <div className="flex rounded-lg overflow-hidden flex-shrink-0" style={{ border: "1px solid var(--border)" }}>
              {([["nr", "Por NR"], ["local", "Locais"]] as const).map(([key, label]) => (
                <button
                  key={key}
                  onClick={() => setPieDim(key)}
                  className="px-3 py-1.5 text-[10px] font-semibold transition-all"
                  style={{
                    background: pieDim === key ? "var(--primary)" : "var(--background)",
                    color: pieDim === key ? "var(--primary-foreground)" : "var(--muted-foreground)",
                  }}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div style={{ width: 140, height: 140, flexShrink: 0 }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={38} outerRadius={62} paddingAngle={2} dataKey="value" strokeWidth={0}>
                    {pieData.map((entry, i) => (
                      <Cell
                        key={entry.name}
                        fill={pieDim === "nr" ? NR_COLORS[entry.name as NRCode] : LOCAL_COLORS[i % LOCAL_COLORS.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<PieTip />} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-col gap-2 flex-1 min-w-0">
              {pieData.map((entry, i) => {
                const col = pieDim === "nr" ? NR_COLORS[entry.name as NRCode] : LOCAL_COLORS[i % LOCAL_COLORS.length];
                return (
                  <div key={entry.name} className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: col }} />
                    <div className="flex-1 min-w-0">
                      <div className="text-[11px] font-bold leading-none truncate" style={{ color: "var(--foreground)" }}>{entry.name}</div>
                    </div>
                    <div className="text-xs font-bold flex-shrink-0" style={{ color: col }}>{entry.value}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* bar chart */}
      <div className="px-5 mb-5">
        <div className="rounded-2xl p-4" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
          <div className="mb-3">
            <div className="text-sm font-bold" style={{ color: "var(--foreground)" }}>Permissões por Setor</div>
            <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>Distribuição por área</div>
          </div>
          <div style={{ height: 170 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={setorData} barSize={20} margin={{ top: 0, right: 6, left: -18, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke="var(--border)" strokeDasharray="3 0" />
                <XAxis dataKey="setor" tick={{ fill: "var(--muted-foreground)", fontSize: 9, fontFamily: "DM Sans" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip content={<BarTip />} cursor={{ fill: "var(--chart-hover)" }} />
                <Bar dataKey="total" fill="var(--primary)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* tabs */}
      <div className="px-5 mb-4">
        <div className="flex rounded-xl overflow-hidden" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
          {[
            { key: "abertas" as const, label: "Abertas", count: openPets.length },
            { key: "historico" as const, label: "Histórico", count: historyPets.length },
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold transition-all"
              style={{
                background: activeTab === tab.key ? "var(--primary)" : "transparent",
                color: activeTab === tab.key ? "var(--primary-foreground)" : "var(--muted-foreground)",
              }}
            >
              {tab.label}
              <span
                className="px-1.5 py-0.5 rounded-full text-[10px] font-bold"
                style={{
                  background: activeTab === tab.key ? "#0f111730" : "var(--border)",
                  color: activeTab === tab.key ? "var(--primary-foreground)" : "var(--secondary-foreground)",
                }}
              >
                {tab.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* open PETs list */}
      {activeTab === "abertas" && (
      <div className="px-5">
        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="text-sm font-bold" style={{ color: "var(--foreground)" }}>Permissões abertas agora</div>
            <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>{openPets.length} ativa(s)</div>
          </div>
          <div className="px-2.5 py-1 rounded-full text-[10px] font-bold" style={{ background: openPets.length > 0 ? "#ef444420" : "#00d4aa20", color: openPets.length > 0 ? "var(--danger)" : "var(--primary)" }}>
            {openPets.length > 0 ? "● ATIVO" : "● LIMPO"}
          </div>
        </div>

        {openPets.length === 0 && (
          <div className="rounded-2xl p-8 text-center" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
            <div className="text-3xl mb-2">✓</div>
            <div className="text-sm font-semibold" style={{ color: "var(--foreground)" }}>Nenhuma PET aberta</div>
          </div>
        )}

        <div className="flex flex-col gap-3">
          {openPets.map(pet => {
            const col = NR_COLORS[pet.nr];
            const isHighlighted = pet.id === highlightId;
            return (
              <div
                key={pet.id}
                id={`pet-card-${pet.id}`}
                className="rounded-2xl overflow-hidden transition-all"
                style={{
                  background: "var(--card)",
                  border: `1px solid ${isHighlighted ? "var(--primary)" : `${col}40`}`,
                  boxShadow: isHighlighted ? `0 0 0 3px ${col}30` : "none",
                }}
              >
                <div className="h-[3px]" style={{ background: col }} />
                <div className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: `${col}25`, color: col }}>{pet.nr}</span>
                        <span className="text-[10px]" style={{ color: "var(--muted-foreground)", fontFamily: "'JetBrains Mono',monospace" }}>Nº {pet.numero}</span>
                        {isHighlighted && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}>
                            ● Novo
                          </span>
                        )}
                      </div>
                      <div className="text-sm font-bold" style={{ color: "var(--foreground)" }}>{pet.tipo}</div>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {/* PDF download */}
                      <button
                        onClick={() => downloadReport(pet)}
                        className="flex items-center gap-1 px-2.5 py-2 rounded-lg text-[11px] font-semibold"
                        style={{ background: "var(--secondary)", color: "var(--secondary-foreground)", border: "1px solid var(--border)" }}
                        title="Baixar PDF"
                      >
                        <IconDownload />
                      </button>
                      {/* vigia button — NR-33 only */}
                      {pet.nr === "NR-33" && (
                        <button
                          onClick={() => onVigia(pet)}
                          className="flex items-center gap-1 px-2.5 py-2 rounded-lg text-[11px] font-semibold"
                          style={{ background: "var(--secondary)", color: "var(--secondary-foreground)", border: "1px solid var(--border)" }}
                        >
                          <IconEye /> Vigia
                        </button>
                      )}
                      {/* encerrar button */}
                      {userRole !== "vigia" && (
                        <button
                          onClick={() => openCloseModal(pet.id)}
                          className="flex items-center gap-1 px-2.5 py-2 rounded-lg text-[11px] font-semibold"
                          style={{ background: "#ef444415", color: "var(--danger)", border: "1px solid #ef444430" }}
                        >
                          <IconX /> Encerrar
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
                    {[
                      { label: "Local", value: pet.local },
                      { label: "Setor", value: pet.setor },
                      { label: "Responsável", value: pet.responsavel.split(" ")[0] || "—" },
                      { label: "Abertura", value: pet.abertura },
                    ].map(r => (
                      <div key={r.label}>
                        <div className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>{r.label}</div>
                        <div className="text-[11px] font-medium" style={{ color: "var(--secondary-foreground)" }}>{r.value}</div>
                      </div>
                    ))}
                  </div>

                  {/* workers preview */}
                  {pet.workers.length > 0 && (
                    <div className="flex items-center gap-1.5 mt-3 pt-3" style={{ borderTop: "1px solid var(--border)" }}>
                      <div className="flex -space-x-2">
                        {pet.workers.slice(0, 3).map(w => (
                          <div
                            key={w.id}
                            className="w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-bold ring-2"
                            style={{ background: `${col}30`, color: col, outline: "2px solid var(--card)" }}
                          >
                            {w.name[0]}
                          </div>
                        ))}
                      </div>
                      <span className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>
                        {pet.workers.length} trabalhador(es) · {pet.vigias.length} vigia(s)
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      )}

      {/* history */}
      {activeTab === "historico" && (
      <div className="px-5">
        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="text-sm font-bold" style={{ color: "var(--foreground)" }}>Histórico de PETs</div>
            <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>{historyPets.length} registro(s)</div>
          </div>
          <div className="px-2.5 py-1 rounded-full text-[10px] font-bold" style={{ background: "#6b759020", color: "var(--muted-foreground)" }}>
            ● HISTÓRICO
          </div>
        </div>

        {historyPets.length === 0 && (
          <div className="rounded-2xl p-8 text-center" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
            <div className="text-3xl mb-2">📋</div>
            <div className="text-sm font-semibold" style={{ color: "var(--foreground)" }}>Nenhum registro ainda</div>
            <div className="text-xs mt-1" style={{ color: "var(--muted-foreground)" }}>As PETs encerradas e canceladas aparecerão aqui</div>
          </div>
        )}

        <div className="flex flex-col gap-3">
          {historyPets.map(pet => {
            const isCancelled = pet.status === "cancelada";
            return (
              <div
                key={pet.id}
                className="rounded-2xl overflow-hidden"
                style={{ background: "var(--card)", border: `1px solid ${isCancelled ? "#ef444425" : "var(--border)"}` }}
              >
                <div className="h-[3px]" style={{ background: isCancelled ? "var(--danger)" : "var(--faint)" }} />
                <div className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: "#3a425520", color: "var(--muted-foreground)" }}>{pet.nr}</span>
                        <span className="text-[10px]" style={{ color: "var(--muted-foreground)", fontFamily: "'JetBrains Mono',monospace" }}>Nº {pet.numero}</span>
                      </div>
                      <div className="text-sm font-bold" style={{ color: "var(--secondary-foreground)" }}>{pet.tipo}</div>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <button
                        onClick={() => downloadReport(pet)}
                        className="flex items-center px-2 py-1.5 rounded-lg"
                        style={{ background: "var(--background)", border: "1px solid var(--border)", color: "var(--muted-foreground)" }}
                        title="Baixar PDF"
                      >
                        <IconDownload />
                      </button>
                      <div
                        className="px-2.5 py-1 rounded-full text-[10px] font-bold"
                        style={{
                          background: isCancelled ? "#ef444415" : "#22c55e15",
                          color: isCancelled ? "var(--danger)" : "var(--success)",
                        }}
                      >
                        {isCancelled ? "✕ Cancelada" : "✓ Encerrada"}
                      </div>
                    </div>
                  </div>

                  {isCancelled && pet.cancelReason && (
                    <div className="mb-3 px-3 py-2 rounded-lg text-xs" style={{ background: "#ef444412", border: "1px solid #ef444425", color: "var(--danger)" }}>
                      <span className="font-semibold">Motivo: </span>{pet.cancelReason}
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
                    {[
                      { label: "Local", value: pet.local },
                      { label: "Setor", value: pet.setor },
                      { label: "Responsável", value: pet.responsavel.split(" ")[0] || "—" },
                      { label: "Abertura", value: pet.abertura },
                    ].map(r => (
                      <div key={r.label}>
                        <div className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>{r.label}</div>
                        <div className="text-[11px] font-medium" style={{ color: "var(--muted-foreground)" }}>{r.value}</div>
                      </div>
                    ))}
                  </div>

                  {pet.workers.length > 0 && (
                    <div className="flex items-center gap-1.5 mt-3 pt-3" style={{ borderTop: "1px solid var(--border)" }}>
                      <div className="flex -space-x-2">
                        {pet.workers.slice(0, 3).map(w => (
                          <div
                            key={w.id}
                            className="w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-bold"
                            style={{ background: "#3a425530", color: "var(--muted-foreground)", outline: "2px solid var(--card)" }}
                          >
                            {w.name[0]}
                          </div>
                        ))}
                      </div>
                      <span className="text-[10px]" style={{ color: "var(--faint)" }}>
                        {pet.workers.length} trabalhador(es) · {pet.vigias.length} vigia(s)
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      )}

      {/* close/cancel modal */}
      {closeModal && (
        <div
          className="fixed inset-0 flex items-end justify-center z-50"
          style={{ background: "var(--overlay)" }}
          onClick={() => setCloseModal(null)}
        >
          <div
            className="w-full rounded-t-3xl p-6 pb-10"
            style={{ maxWidth: 430, background: "var(--card)", border: "1px solid var(--border)" }}
            onClick={e => e.stopPropagation()}
          >
            {closeModal.step === "choose" ? (
              <>
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "#ef444420" }}>
                    <IconX />
                  </div>
                  <div>
                    <div className="text-base font-bold" style={{ color: "var(--foreground)" }}>Encerrar PET</div>
                    <div className="text-xs" style={{ color: "var(--muted-foreground)" }}>Escolha o tipo de encerramento</div>
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  <button
                    onClick={() => confirmClose("encerrar")}
                    className="w-full rounded-2xl p-4 text-left"
                    style={{ background: "#22c55e12", border: "1px solid #22c55e30" }}
                  >
                    <div className="text-sm font-bold mb-0.5" style={{ color: "var(--success)" }}>Encerrar normalmente</div>
                    <div className="text-xs" style={{ color: "var(--muted-foreground)" }}>Serviço concluído conforme planejado</div>
                  </button>
                  <button
                    onClick={() => confirmClose("cancelar")}
                    className="w-full rounded-2xl p-4 text-left"
                    style={{ background: "#ef444412", border: "1px solid #ef444430" }}
                  >
                    <div className="text-sm font-bold mb-0.5" style={{ color: "var(--danger)" }}>Cancelar por incidente</div>
                    <div className="text-xs" style={{ color: "var(--muted-foreground)" }}>Serviço interrompido — registrar ocorrência</div>
                  </button>
                </div>
                <button
                  onClick={() => setCloseModal(null)}
                  className="w-full mt-3 py-3 rounded-xl text-sm"
                  style={{ color: "var(--muted-foreground)" }}
                >
                  Voltar
                </button>
              </>
            ) : (
              <>
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "#ef444420" }}>
                    <IconX />
                  </div>
                  <div>
                    <div className="text-base font-bold" style={{ color: "var(--danger)" }}>Cancelamento por Incidente</div>
                    <div className="text-xs" style={{ color: "var(--muted-foreground)" }}>Descreva o motivo do cancelamento</div>
                  </div>
                </div>
                <div className="mb-4">
                  <label className="text-[10px] font-semibold uppercase tracking-wider block mb-2" style={{ color: "var(--muted-foreground)" }}>
                    Motivo / Ocorrência <span style={{ color: "var(--danger)" }}>*</span>
                  </label>
                  <textarea
                    value={cancelReason}
                    onChange={e => setCancelReason(e.target.value)}
                    placeholder="Descreva o incidente que motivou o cancelamento..."
                    rows={4}
                    className="w-full rounded-xl px-4 py-3 text-sm outline-none resize-none"
                    style={{ background: "var(--background)", border: "1px solid var(--border)", color: "var(--foreground)" }}
                    autoFocus
                  />
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => setCloseModal({ petId: closeModal.petId, step: "choose" })}
                    className="flex-1 rounded-xl py-3 text-sm font-semibold"
                    style={{ background: "var(--background)", border: "1px solid var(--border)", color: "var(--muted-foreground)" }}
                  >
                    Voltar
                  </button>
                  <button
                    onClick={() => confirmClose("cancelar")}
                    disabled={!cancelReason.trim()}
                    className="flex-1 rounded-xl py-3 text-sm font-bold transition-all"
                    style={{
                      background: cancelReason.trim() ? "var(--danger)" : "#ef444430",
                      color: cancelReason.trim() ? "#fff" : "#ef444480",
                    }}
                  >
                    Confirmar Cancelamento
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── App Root ──────────────────────────────────────────── */
export default function App() {
  const [screen, setScreen] = useState<Screen>("login");
  const [userRole, setUserRole] = useState<UserRole>("tecnico");
  const [userName, setUserName] = useState("");
  const [userEmployeeId, setUserEmployeeId] = useState("");
  const [organizationId, setOrganizationId] = useState("");
  const [pets, setPets] = useState<PETRecord[]>(isSupabaseConfigured ? [] : INITIAL_PETS);
  const [employees, setEmployees] = useState<Employee[]>(isSupabaseConfigured ? [] : EMPLOYEES);
  const [organizationOptions, setOrganizationOptions] = useState<OrganizationOption[]>([]);
  const [activePet, setActivePet] = useState<PETRecord | null>(null);
  const [isTestMode, setIsTestMode] = useState(false);
  const [testBannerDismissed, setTestBannerDismissed] = useState(false);
  const [justCreatedId, setJustCreatedId] = useState<string | null>(null);

  useEffect(() => {
    if (!isSupabaseConfigured || !organizationId || screen !== "dashboard") return;
    let cancelled = false;
    listPermits(organizationId)
      .then(loadedPermits => { if (!cancelled) setPets(loadedPermits); })
      .catch(error => console.error("Não foi possível carregar as permissões.", error));
    return () => { cancelled = true; };
  }, [organizationId, screen]);

  useEffect(() => {
    if (!isSupabaseConfigured || !organizationId) return;
    listOrganizationOptions(organizationId)
      .then(setOrganizationOptions)
      .catch(error => console.error("Não foi possível carregar as opções da organização.", error));
  }, [organizationId, screen]);

  useEffect(() => {
    if (!isSupabaseConfigured || !organizationId) return;
    listOrganizationEmployees(organizationId)
      .then(setEmployees)
      .catch(error => console.error("Não foi possível carregar os profissionais.", error));
  }, [organizationId, screen]);

  function handleLogin(role: UserRole, name: string, _matricula: string, employeeId: string, loggedOrganizationId?: string) {
    setIsTestMode(false);
    setUserRole(role);
    setUserName(name);
    setUserEmployeeId(employeeId);
    setOrganizationId(loggedOrganizationId ?? "");
    setScreen("dashboard");
  }

  function handleEnterTestMode() {
    setUserRole("tecnico");
    setUserName("Usuário de Teste");
    setUserEmployeeId(EMPLOYEES[0]?.id ?? "");
    setOrganizationId("");
    setPets([...INITIAL_PETS]);
    setEmployees([...EMPLOYEES]);
    setIsTestMode(true);
    setTestBannerDismissed(false);
    setScreen("dashboard");
  }

  async function handleEmitPet(pet: PETRecord) {
    if (isSupabaseConfigured && organizationId) {
      try {
        await createPermit(organizationId, userEmployeeId, pet);
      } catch (error) {
        console.error("Não foi possível salvar a permissão.", error);
        window.alert("Não foi possível salvar a permissão. Verifique o vínculo do usuário e tente novamente.");
        return;
      }
    }
    setPets(prev => [pet, ...prev]);
    setJustCreatedId(pet.id);
    setScreen("dashboard");
  }

  async function handleClosePet(id: string, mode: "encerrar" | "cancelar", reason?: string) {
    if (isSupabaseConfigured) {
      try {
        await closePermit(id, mode, reason);
      } catch (error) {
        console.error("Não foi possível atualizar a permissão.", error);
        const message = error instanceof Error ? error.message : "Erro desconhecido";
        window.alert(`Não foi possível atualizar a permissão.\n\n${message}`);
        return;
      }
    }
    const now = new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
    setPets(prev => prev.map(p => p.id === id
      ? { ...p, status: mode === "cancelar" ? "cancelada" : "encerrada", encerramento: now, cancelReason: reason }
      : p
    ));
  }

  function handleOpenVigia(pet: PETRecord) {
    setActivePet(pet);
    setScreen("vigia");
  }

  function handleUpdatePet(updated: PETRecord) {
    setPets(prev => prev.map(p => p.id === updated.id ? updated : p));
    setActivePet(updated);
  }

  async function handleLogout() {
    if (supabase) await supabase.auth.signOut();
    setOrganizationId("");
    setPets(isSupabaseConfigured ? [] : INITIAL_PETS);
    setEmployees(isSupabaseConfigured ? [] : EMPLOYEES);
    setOrganizationOptions([]);
    setIsTestMode(false);
    setJustCreatedId(null);
    setScreen("login");
  }

  return (
    <div className="app-shell">
      {isTestMode && !testBannerDismissed && (
        <div
          className="flex items-start gap-3 px-4 py-3 text-xs"
          style={{ background: "var(--warning)", color: "#1a1400" }}
        >
          <span className="text-base leading-none">⚠</span>
          <div className="flex-1">
            <div className="font-bold mb-0.5">Modo de teste — dados fictícios</div>
            <div>
              Você está acessando o protótipo para visualização e testes da ferramenta. Existem funcionalidades que ainda não
              estão funcionando como deveriam — por exemplo, o dashboard ainda não busca no banco de dados a quantidade real
              de documentos para alimentar os gráficos e os indicadores (os números por período são estimados).
            </div>
          </div>
          <button
            onClick={() => setTestBannerDismissed(true)}
            className="font-bold flex-shrink-0 px-1"
            aria-label="Fechar aviso"
          >
            ✕
          </button>
        </div>
      )}
      {screen === "login" && (
        <Login onLogin={handleLogin} onEnterTestMode={handleEnterTestMode} />
      )}
      {screen === "dashboard" && (
        <Dashboard
          pets={userRole === "vigia"
            ? pets.filter(p => p.vigias.some(v => v.id === userEmployeeId))
            : pets}
          userName={userName}
          userRole={userRole}
          onNovaPET={() => setScreen("nova-pet")}
          onProfessionals={() => setScreen("professionals")}
          onLogout={handleLogout}
          onVigia={handleOpenVigia}
          onClosePet={handleClosePet}
          justCreatedId={justCreatedId}
          onSeenNew={() => setJustCreatedId(null)}
        />
      )}
      {screen === "nova-pet" && (
        <NovaPET
          employees={employees}
          organizationOptions={organizationOptions}
          onOptionCreated={async option => {
            const created = organizationId
              ? await createOrganizationOption(organizationId, option.category, option.label)
              : { ...option, id: `local-${Date.now()}` };
            setOrganizationOptions(current => [...current, created]);
            return created;
          }}
          onCreateEmployee={async employee => {
            const created = organizationId
              ? await createOrganizationEmployee(organizationId, employee)
              : { ...employee, id: `local-${Date.now()}` };
            setEmployees(current => [...current, created].sort((a, b) => a.name.localeCompare(b.name)));
            return created;
          }}
          onBack={() => setScreen("dashboard")}
          onEmit={handleEmitPet}
        />
      )}
      {screen === "vigia" && activePet && (
        <VigiaView
          pet={activePet}
          vigiaName={userName || activePet.vigias[0]?.name || "Vigia"}
          onUpdatePet={handleUpdatePet}
          onBack={() => setScreen("dashboard")}
        />
      )}
      {screen === "professionals" && organizationId && (
        <Professionals organizationId={organizationId} onBack={() => setScreen("dashboard")} />
      )}
    </div>
  );
}
