import { useState, useRef, useEffect } from "react";
import { NR_DATA, NRCode, CheckAnswer, NRDefinition } from "../data/nrData";
import type { Employee } from "../data/employees";
import type { PETRecord, PermitType } from "../types";
import type { OrganizationOption } from "../services/options";

/* ─── Step system ────────────────────────────────────────── */
type StepName = "Tipo" | "NR" | "Dados" | "Checklist" | "Equipe" | "Vigia" | "Horário" | "Assinatura" | "Revisão";

function getStepNames(nrCode: NRCode | null): StepName[] {
  if (nrCode === "NR-33") {
    return ["Tipo", "NR", "Dados", "Checklist", "Equipe", "Vigia", "Horário", "Assinatura", "Revisão"];
  }
  return ["Tipo", "NR", "Dados", "Checklist", "Equipe", "Horário", "Assinatura", "Revisão"];
}

// Workers eligible for the PET: must have the required NR in their training
function getEligibleWorkers(nrCode: string, employees: Employee[]) {
  const responsaveis = employees.filter(e => e.cargo.toLowerCase().includes("técnic") || e.cargo.toLowerCase().includes("engenheir") || e.cargo.toLowerCase().includes("segurança"));
  const vigias = employees.filter(e => e.cargo.toLowerCase().includes("vigia") || e.cargo.toLowerCase().includes("segurança") || e.setor === "SESMT");
  return employees.filter(
    e =>
      e.treinamentos.includes(nrCode) &&
      !responsaveis.some(r => r.id === e.id) &&
      !vigias.some(v => v.id === e.id)
  );
}

interface Props {
  employees: Employee[];
  onBack: () => void;
  onEmit: (pet: PETRecord) => void;
  organizationOptions: OrganizationOption[];
  onOptionCreated: (option: OrganizationOption) => Promise<OrganizationOption>;
  onCreateEmployee: (employee: Omit<Employee, "id">) => Promise<Employee>;
}

/* ─── Icons ─────────────────────────────────────────────── */
function ArrowLeft() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
      <path d="M11 4L6 9l5 5" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Check() {
  return (
    <svg width="11" height="11" viewBox="0 0 11 11" fill="none">
      <path d="M2 5.5l2.5 2.5 4.5-4.5" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ChevronRight() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M5 3l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}


function StepPermitType({ selected, onSelect }: { selected: PermitType | null; onSelect: (type: PermitType) => void }) {
  const options: { type: PermitType; title: string; description: string; icon: string }[] = [
    { type: "PET", title: "Permissão de Entrada e Trabalho", description: "Para espaços confinados, com controle de entrada e vigia quando aplicável.", icon: "◈" },
    { type: "PT", title: "Permissão de Trabalho", description: "Para trabalhos controlados pelas normas e checklists de segurança aplicáveis.", icon: "✓" },
  ];

  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-3">
      <div className="mb-1">
        <h2 className="text-xl font-bold" style={{ color: "var(--foreground)" }}>Tipo de permissão</h2>
        <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>Escolha o documento que será emitido</p>
      </div>
      {options.map(option => (
        <button
          key={option.type}
          onClick={() => onSelect(option.type)}
          className="flex items-center gap-4 p-4 rounded-2xl border text-left transition-all"
          style={{
            background: selected === option.type ? "#00d4aa12" : "var(--card)",
            borderColor: selected === option.type ? "var(--primary)" : "var(--border)",
          }}
        >
          <div className="w-11 h-11 rounded-xl flex items-center justify-center text-xl flex-shrink-0" style={{ background: "#00d4aa20", color: "var(--primary)" }}>{option.icon}</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2"><span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: "#00d4aa25", color: "var(--primary)" }}>{option.type}</span></div>
            <div className="text-sm font-bold mt-0.5" style={{ color: "var(--foreground)" }}>{option.title}</div>
            <div className="text-xs" style={{ color: "var(--muted-foreground)" }}>{option.description}</div>
          </div>
          <ChevronRight />
        </button>
      ))}
    </div>
  );
}
/* ─── Step Progress ─────────────────────────────────────── */
function StepBar({ step, stepNames }: { step: number; stepNames: StepName[] }) {
  const show = stepNames.length <= 7 ? stepNames : stepNames;
  const abbreviated = show.map(s => s.slice(0, 4));
  return (
    <div className="px-5 py-3">
      <div className="flex items-center">
        {abbreviated.map((label, i) => (
          <div key={i} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center gap-0.5">
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-bold transition-all"
                style={{
                  background: i < step ? "var(--primary)" : i === step ? "var(--primary)" : "var(--secondary)",
                  color: i <= step ? "var(--primary-foreground)" : "var(--muted-foreground)",
                }}
              >
                {i < step ? <Check /> : i + 1}
              </div>
              <span
                className="text-[8px] font-semibold"
                style={{ color: i === step ? "var(--primary)" : i < step ? "var(--secondary-foreground)" : "var(--faint)" }}
              >
                {label}
              </span>
            </div>
            {i < abbreviated.length - 1 && (
              <div
                className="flex-1 h-[1px] mb-3 mx-0.5"
                style={{ background: i < step ? "var(--primary)" : "var(--border)" }}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Step: Select NR ────────────────────────────────────── */
function StepNR({ selected, onSelect }: { selected: NRCode | null; onSelect: (c: NRCode) => void }) {
  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-3">
      <div className="mb-1">
        <h2 className="text-xl font-bold" style={{ color: "var(--foreground)" }}>Tipo de Trabalho</h2>
        <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>Selecione a norma regulamentadora</p>
      </div>
      {NR_DATA.map(nr => (
        <button
          key={nr.code}
          onClick={() => onSelect(nr.code)}
          className="flex items-center gap-4 p-4 rounded-2xl border text-left transition-all"
          style={{
            background: selected === nr.code ? `${nr.color}12` : "var(--card)",
            borderColor: selected === nr.code ? nr.color : "var(--border)",
          }}
        >
          <div
            className="w-11 h-11 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
            style={{ background: `${nr.color}20`, color: nr.color }}
          >
            {nr.icon}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: `${nr.color}25`, color: nr.color }}>
                {nr.code}
              </span>
              {nr.code === "NR-33" && (
                <span className="text-[9px] px-1.5 py-0.5 rounded-full font-medium" style={{ background: "#a855f720", color: "#a855f7" }}>
                  Requer Vigia
                </span>
              )}
            </div>
            <div className="text-sm font-bold mt-0.5" style={{ color: "var(--foreground)" }}>{nr.name}</div>
            <div className="text-xs" style={{ color: "var(--muted-foreground)" }}>{nr.subtitle}</div>
          </div>
          <div style={{ color: selected === nr.code ? nr.color : "var(--faint)" }}>
            <ChevronRight />
          </div>
        </button>
      ))}
    </div>
  );
}

/* ─── Step: NR Fields ────────────────────────────────────── */
function StepFields({
  nr,
  values,
  onChange,
  organizationOptions,
  onOptionCreated,
}: {
  nr: NRDefinition;
  values: Record<string, string>;
  onChange: (id: string, val: string) => void;
  organizationOptions: OrganizationOption[];
  onOptionCreated: (option: OrganizationOption) => Promise<OrganizationOption>;
}) {
  const [newOption, setNewOption] = useState("");
  async function addOption(category: string) {
    const label = newOption.trim();
    if (!label) return;
    const option = await onOptionCreated({ id: `${category}-${label}`, category, label });
    onChange(category === "sector" ? "setor" : category, option.label);
    setNewOption("");
  }
  const renderDynamicSelect = (category: string, value: string) => {
    const options = organizationOptions.filter(option => option.category === category).map(option => option.label);
    return <>
      <select value={value} onChange={event => onChange(category === "sector" ? "setor" : category, event.target.value)} className="w-full rounded-xl px-4 py-3.5 text-sm outline-none" style={{ background: "var(--card)", border: "1px solid var(--border)", color: value ? "var(--foreground)" : "var(--muted-foreground)" }}><option value="">Selecione...</option>{options.map(option => <option key={option}>{option}</option>)}<option value="__new__">+ Adicionar nova opção</option></select>
      {value === "__new__" && <div className="flex gap-2 mt-2"><input autoFocus value={newOption} onChange={event => setNewOption(event.target.value)} placeholder="Nova opção" className="flex-1 rounded-lg px-3 py-2 text-sm" style={{ background: "var(--background)", color: "var(--foreground)", border: "1px solid var(--border)" }} /><button type="button" onClick={() => addOption(category)} className="rounded-lg px-3 text-xs font-bold" style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}>Salvar</button></div>}
    </>;
  };
  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-4">
      <div className="mb-1">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: `${nr.color}25`, color: nr.color }}>
            {nr.code}
          </span>
        </div>
        <h2 className="text-xl font-bold" style={{ color: "var(--foreground)" }}>Dados do Trabalho</h2>
        <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>Preencha as informações específicas</p>
      </div>

      {/* Setor */}
      <div className="flex flex-col gap-1.5">
        <label className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--muted-foreground)" }}>
          Setor / Área <span style={{ color: "var(--danger)" }}>*</span>
        </label>
        {renderDynamicSelect("sector", values["setor"] ?? "")}
      </div>

      {nr.fields.map(field => (
        <div key={field.id} className="flex flex-col gap-1.5">
          <label className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--muted-foreground)" }}>
            {field.label}
            {field.unit && <span style={{ color: "var(--faint)" }}> ({field.unit})</span>}
            {field.required && <span style={{ color: "var(--danger)" }}> *</span>}
          </label>
          {field.type === "select" || /local|espaco|multigas|equipamento|veiculo|placa/i.test(field.id) ? (
            <>
            {renderDynamicSelect(field.id, values[field.id] ?? "")}
            </>
          ) : field.type === "number" ? (
            <div className="relative">
              <input
                type="number"
                min="0"
                step="0.01"
                value={values[field.id] ?? ""}
                onChange={e => {
                  const v = parseFloat(e.target.value);
                  if (e.target.value === "" || v >= 0) onChange(field.id, e.target.value);
                }}
                onBlur={e => {
                  const v = parseFloat(e.target.value);
                  if (!isNaN(v) && v < 0) onChange(field.id, "0");
                }}
                placeholder="0"
                className="w-full rounded-xl px-4 py-3.5 text-sm outline-none"
                style={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--foreground)" }}
              />
              {field.unit && (
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs" style={{ color: "var(--muted-foreground)", fontFamily: "'JetBrains Mono',monospace" }}>
                  {field.unit}
                </span>
              )}
            </div>
          ) : (
            <input
              type="text"
              value={values[field.id] ?? ""}
              onChange={e => onChange(field.id, e.target.value)}
              placeholder={`Informe ${field.label.toLowerCase()}...`}
              className="w-full rounded-xl px-4 py-3.5 text-sm outline-none"
              style={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--foreground)" }}
            />
          )}
        </div>
      ))}

      {/* EPI list */}
      <div className="p-4 rounded-xl mt-2" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
        <div className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--muted-foreground)" }}>
          EPIs Obrigatórios — {nr.code}
        </div>
        <div className="flex flex-col gap-1.5">
          {nr.epiList.map((epi, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: nr.color }} />
              <span className="text-xs" style={{ color: "var(--secondary-foreground)" }}>{epi}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── Step: Checklist ────────────────────────────────────── */
function StepChecklist({
  nr,
  answers,
  onChange,
}: {
  nr: NRDefinition;
  answers: Record<string, CheckAnswer>;
  onChange: (id: string, ans: CheckAnswer) => void;
}) {
  const answered = Object.keys(answers).length;
  const total = nr.checklist.length;
  const naoCount = Object.values(answers).filter(a => a === "NÃO").length;
  const pct = Math.round((answered / total) * 100);

  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-3">
      <div className="mb-1">
        <h2 className="text-xl font-bold" style={{ color: "var(--foreground)" }}>Checklist {nr.code}</h2>
        <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
          {answered}/{total} respondidos · {pct}%
          {naoCount > 0 && <span style={{ color: "var(--danger)" }}> · {naoCount} NÃO conforme</span>}
        </p>
      </div>

      <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: "var(--border)" }}>
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${pct}%`, background: naoCount > 0 ? "var(--danger)" : "var(--primary)" }}
        />
      </div>

      <div className="flex flex-col gap-2 mt-1">
        {nr.checklist.map((item, idx) => {
          const ans = answers[item.id];
          return (
            <div
              key={item.id}
              className="rounded-xl p-3.5"
              style={{
                background: "var(--card)",
                border: `1px solid ${ans === "NÃO" ? "#ef444440" : "var(--border)"}`,
              }}
            >
              <div className="text-xs mb-2.5 leading-relaxed" style={{ color: "var(--secondary-foreground)" }}>
                <span className="font-bold mr-1" style={{ color: "var(--faint)", fontFamily: "'JetBrains Mono',monospace" }}>
                  {String(idx + 1).padStart(2, "0")}
                </span>
                {item.label}
              </div>
              <div className="flex gap-2">
                {(["SIM", "NÃO", "NA"] as CheckAnswer[]).map(opt => (
                  <button
                    key={opt}
                    onClick={() => onChange(item.id, opt)}
                    className="flex-1 py-1.5 rounded-lg text-xs font-bold transition-all"
                    style={{
                      background: ans === opt ? (opt === "SIM" ? "var(--primary)" : opt === "NÃO" ? "var(--danger)" : "var(--muted-foreground)") : "var(--background)",
                      color: ans === opt ? (opt === "NA" ? "var(--foreground)" : "var(--primary-foreground)") : "var(--muted-foreground)",
                      border: `1px solid ${ans === opt ? (opt === "SIM" ? "var(--primary)" : opt === "NÃO" ? "var(--danger)" : "var(--muted-foreground)") : "var(--border)"}`,
                    }}
                  >
                    {opt}
                  </button>
                ))}
              </div>
              {ans === "NÃO" && (
                <div className="mt-2 flex items-center gap-1.5 text-[10px]" style={{ color: "var(--danger)" }}>
                  <span>⚠</span> Item não conforme — medida corretiva obrigatória
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Step: Equipe ───────────────────────────────────────── */
function StepEquipe({
  nr,
  employees,
  onCreateEmployee,
  selectedWorkers,
  responsavel,
  onToggleWorker,
  onSelectResponsavel,
}: {
  nr: NRDefinition;
  employees: Employee[];
  selectedWorkers: Set<string>;
  responsavel: string | null;
  onToggleWorker: (id: string) => void;
  onSelectResponsavel: (id: string) => void;
  onCreateEmployee: (employee: Omit<Employee, "id">) => Promise<Employee>;
}) {
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [newEmployee, setNewEmployee] = useState({ name: "", matricula: "", cargo: "", setor: "", treinamentos: [nr.code] });
  const responsaveis = employees.filter(e => e.cargo.toLowerCase().includes("técnic") || e.cargo.toLowerCase().includes("engenheir") || e.cargo.toLowerCase().includes("segurança"));
  const eligible = getEligibleWorkers(nr.code, employees);
  const filtered = eligible.filter(
    e =>
      e.name.toLowerCase().includes(search.toLowerCase()) ||
      e.matricula.includes(search) ||
      e.cargo.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-4">
      <div>
        <h2 className="text-xl font-bold" style={{ color: "var(--foreground)" }}>Equipe de Trabalho</h2>
        <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>Apenas funcionários habilitados em {nr.code}</p>
      </div>

      {/* responsável */}
      <div>
        <div className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--muted-foreground)" }}>
          Responsável Técnico <span style={{ color: "var(--danger)" }}>*</span>
        </div>
        <div className="flex flex-col gap-2">
          {responsaveis.map(r => (
            <button
              key={r.id}
              onClick={() => onSelectResponsavel(r.id)}
              className="flex items-center gap-3 p-3 rounded-xl border text-left transition-all"
              style={{
                background: responsavel === r.id ? "#00d4aa12" : "var(--card)",
                borderColor: responsavel === r.id ? "var(--primary)" : "var(--border)",
              }}
            >
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold flex-shrink-0"
                style={{ background: responsavel === r.id ? "#00d4aa30" : "var(--secondary)", color: responsavel === r.id ? "var(--primary)" : "var(--muted-foreground)" }}
              >
                {r.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold" style={{ color: "var(--foreground)" }}>{r.name}</div>
                <div className="text-xs" style={{ color: "var(--muted-foreground)" }}>{r.cargo}</div>
              </div>
              {responsavel === r.id && (
                <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}>
                  <Check />
                </div>
              )}
            </button>
          ))}
        </div>
        <button type="button" onClick={() => setShowCreate(value => !value)} className="text-xs font-bold mt-3" style={{ color: "var(--primary)" }}>+ Cadastrar profissional nesta permissão</button>
        {showCreate && <div className="grid gap-2 mt-3 p-3 rounded-xl" style={{ background: "var(--muted)", border: "1px solid var(--border)" }}><input placeholder="Nome completo" value={newEmployee.name} onChange={event => setNewEmployee(current => ({ ...current, name: event.target.value }))} className="rounded-lg px-3 py-2 text-sm" style={{ background: "var(--card)", color: "var(--foreground)" }} /><input placeholder="Matrícula" value={newEmployee.matricula} onChange={event => setNewEmployee(current => ({ ...current, matricula: event.target.value }))} className="rounded-lg px-3 py-2 text-sm" style={{ background: "var(--card)", color: "var(--foreground)" }} /><select value={newEmployee.cargo} onChange={event => setNewEmployee(current => ({ ...current, cargo: event.target.value }))} className="rounded-lg px-3 py-2 text-sm" style={{ background: "var(--card)", color: "var(--foreground)" }}><option value="">Cargo</option>{["Técnico de Segurança", "Engenheiro de Segurança", "Vigia de Segurança", "Operador de Produção", "Outro"].map(option => <option key={option}>{option}</option>)}</select><input placeholder="Setor" value={newEmployee.setor} onChange={event => setNewEmployee(current => ({ ...current, setor: event.target.value }))} className="rounded-lg px-3 py-2 text-sm" style={{ background: "var(--card)", color: "var(--foreground)" }} /><button type="button" onClick={async () => { if (!newEmployee.name || !newEmployee.matricula || !newEmployee.cargo || !newEmployee.setor) return; const created = await onCreateEmployee(newEmployee); onToggleWorker(created.id); setShowCreate(false); setNewEmployee({ name: "", matricula: "", cargo: "", setor: "", treinamentos: [nr.code] }); }} className="rounded-lg py-2 text-xs font-bold" style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}>Cadastrar e selecionar</button></div>}
      </div>

      {/* workers */}
      <div>
        <div className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--muted-foreground)" }}>
          Trabalhadores ({selectedWorkers.size} selecionados)
        </div>

        {eligible.length === 0 ? (
          <div className="p-4 rounded-xl text-center" style={{ background: "#ef444415", border: "1px solid #ef444430" }}>
            <div className="text-sm font-semibold mb-1" style={{ color: "var(--danger)" }}>Nenhum funcionário habilitado</div>
            <div className="text-xs" style={{ color: "#ef444490" }}>
              Nenhum funcionário com {nr.code} cadastrado pode ser adicionado.
            </div>
          </div>
        ) : (
          <>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar por nome ou matrícula..."
              className="w-full rounded-xl px-4 py-3 text-sm outline-none mb-3"
              style={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--foreground)" }}
            />
            <div className="flex flex-col gap-2">
              {filtered.map(emp => {
                const isSelected = selectedWorkers.has(emp.id);
                return (
                  <button
                    key={emp.id}
                    onClick={() => onToggleWorker(emp.id)}
                    className="flex items-center gap-3 p-3 rounded-xl border text-left transition-all"
                    style={{
                      background: isSelected ? `${nr.color}10` : "var(--card)",
                      borderColor: isSelected ? nr.color : "var(--border)",
                    }}
                  >
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold flex-shrink-0"
                      style={{ background: isSelected ? `${nr.color}30` : "var(--secondary)", color: isSelected ? nr.color : "var(--muted-foreground)" }}
                    >
                      {emp.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold" style={{ color: "var(--foreground)" }}>{emp.name}</div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>{emp.cargo}</span>
                        <span className="text-[9px] px-1.5 py-0.5 rounded-full font-medium" style={{ background: `${nr.color}20`, color: nr.color }}>
                          {nr.code} ✓
                        </span>
                      </div>
                    </div>
                    <div
                      className="w-5 h-5 rounded-md border flex items-center justify-center transition-all flex-shrink-0"
                      style={{ borderColor: isSelected ? nr.color : "var(--faint)", background: isSelected ? nr.color : "transparent" }}
                    >
                      {isSelected && <Check />}
                    </div>
                  </button>
                );
              })}
              {filtered.length === 0 && search && (
                <div className="text-sm text-center py-4" style={{ color: "var(--faint)" }}>Nenhum resultado para "{search}"</div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

/* ─── Step: Vigia (NR-33 only) ───────────────────────────── */
function StepVigia({
  nr,
  employees,
  selectedVigias,
  onToggle,
}: {
  nr: NRDefinition;
  employees: Employee[];
  selectedVigias: Set<string>;
  onToggle: (id: string) => void;
}) {
  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-4">
      <div>
        <h2 className="text-xl font-bold" style={{ color: "var(--foreground)" }}>Vigia(s) de Segurança</h2>
        <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>Obrigatório para NR-33 — Espaço Confinado</p>
      </div>

      <div className="p-3.5 rounded-xl flex items-start gap-3" style={{ background: "var(--card)", border: "1px solid #f59e0b30" }}>
        <span style={{ color: "var(--warning)" }}>⚠</span>
        <p className="text-xs leading-relaxed" style={{ color: "var(--secondary-foreground)" }}>
          O vigia deve permanecer no local durante toda a execução, manter comunicação constante com a equipe e registrar rondas a cada 30 minutos.
        </p>
      </div>

      <div className="flex flex-col gap-2">
        {employees.filter(e => e.cargo.toLowerCase().includes("vigia") || e.cargo.toLowerCase().includes("segurança") || e.setor === "SESMT").map(vigia => {
          const isSelected = selectedVigias.has(vigia.id);
          const hasTrein = vigia.treinamentos.includes(nr.code);
          return (
            <button
              key={vigia.id}
              onClick={() => hasTrein && onToggle(vigia.id)}
              disabled={!hasTrein}
              className="flex items-center gap-3 p-4 rounded-xl border text-left transition-all"
              style={{
                background: !hasTrein ? "var(--background)" : isSelected ? "#00d4aa10" : "var(--card)",
                borderColor: !hasTrein ? "var(--secondary)" : isSelected ? "var(--primary)" : "var(--border)",
                opacity: hasTrein ? 1 : 0.45,
                cursor: hasTrein ? "pointer" : "not-allowed",
              }}
            >
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold flex-shrink-0"
                style={{ background: isSelected ? "#00d4aa25" : "var(--secondary)", color: isSelected ? "var(--primary)" : "var(--muted-foreground)" }}
              >
                {vigia.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold" style={{ color: hasTrein ? "var(--foreground)" : "var(--faint)" }}>{vigia.name}</div>
                <div className="text-xs" style={{ color: "var(--muted-foreground)" }}>{vigia.cargo}</div>
                <div className="flex items-center gap-1.5 mt-1">
                  <span
                    className="text-[9px] px-1.5 py-0.5 rounded-full font-medium"
                    style={{ background: hasTrein ? "#00d4aa20" : "#ef444420", color: hasTrein ? "var(--primary)" : "var(--danger)" }}
                  >
                    {nr.code} {hasTrein ? "✓" : "Sem habilitação"}
                  </span>
                  <span className="text-[10px]" style={{ color: "var(--faint)", fontFamily: "'JetBrains Mono',monospace" }}>
                    {vigia.matricula}
                  </span>
                </div>
              </div>
              <div
                className="w-5 h-5 rounded-full border flex items-center justify-center transition-all"
                style={{ borderColor: isSelected ? "var(--primary)" : "var(--faint)", background: isSelected ? "var(--primary)" : "transparent" }}
              >
                {isSelected && <Check />}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Step: Schedule ─────────────────────────────────────── */
function StepSchedule({
  date, time,
  onChange,
}: {
  date: string; time: string;
  onChange: (k: "date" | "time", v: string) => void;
}) {
  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-4">
      <div>
        <h2 className="text-xl font-bold" style={{ color: "var(--foreground)" }}>Agendamento</h2>
        <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>Data e hora de abertura da PET</p>
      </div>
      {[
        { key: "date" as const, label: "Data de Abertura", type: "date", val: date },
        { key: "time" as const, label: "Hora de Início", type: "time", val: time },
      ].map(f => (
        <div key={f.key} className="flex flex-col gap-1.5">
          <label className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--muted-foreground)" }}>
            {f.label} <span style={{ color: "var(--danger)" }}>*</span>
          </label>
          <input
            type={f.type}
            value={f.val}
            onChange={e => onChange(f.key, e.target.value)}
            className="w-full rounded-xl px-4 py-3.5 text-sm outline-none"
            style={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--foreground)" }}
          />
        </div>
      ))}
    </div>
  );
}

/* ─── Signature Canvas ───────────────────────────────────── */
function SignatureCanvas({
  value,
  onSigned,
  label,
  color,
}: {
  value: string;
  onSigned: (dataUrl: string) => void;
  label: string;
  color: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isDrawing = useRef(false);
  const [isEmpty, setIsEmpty] = useState(!value);

  useEffect(() => {
    if (value && canvasRef.current) {
      const ctx = canvasRef.current.getContext("2d");
      if (!ctx) return;
      const img = new Image();
      img.onload = () => ctx.drawImage(img, 0, 0);
      img.src = value;
      setIsEmpty(false);
    }
  }, []);

  function getPos(e: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return { x: (e.clientX - rect.left) * scaleX, y: (e.clientY - rect.top) * scaleY };
  }

  function startDraw(e: React.PointerEvent<HTMLCanvasElement>) {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    isDrawing.current = true;
    setIsEmpty(false);
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    const p = getPos(e);
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
  }

  function draw(e: React.PointerEvent<HTMLCanvasElement>) {
    e.preventDefault();
    if (!isDrawing.current) return;
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    const p = getPos(e);
    ctx.lineTo(p.x, p.y);
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
  }

  function endDraw(e: React.PointerEvent<HTMLCanvasElement>) {
    e.preventDefault();
    if (!isDrawing.current) return;
    isDrawing.current = false;
    if (canvasRef.current) onSigned(canvasRef.current.toDataURL("image/png"));
  }

  function clear() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.getContext("2d")?.clearRect(0, 0, canvas.width, canvas.height);
    setIsEmpty(true);
    onSigned("");
  }

  return (
    <div className="flex flex-col gap-2">
      <div className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--muted-foreground)" }}>
        {label}
      </div>
      <div
        className="relative rounded-xl overflow-hidden"
        style={{ background: "var(--background)", border: `1px solid ${isEmpty ? "var(--border)" : color + "60"}` }}
      >
        <canvas
          ref={canvasRef}
          width={380}
          height={120}
          style={{ width: "100%", height: 120, touchAction: "none", cursor: "crosshair", display: "block" }}
          onPointerDown={startDraw}
          onPointerMove={draw}
          onPointerUp={endDraw}
          onPointerCancel={endDraw}
        />
        {isEmpty && (
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none gap-1">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" style={{ opacity: 0.3 }}>
              <path d="M3 14l4-4 3 3 4-5 4 4" stroke="var(--foreground)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="text-xs" style={{ color: "var(--faint)" }}>Assine com o dedo ou mouse</span>
          </div>
        )}
      </div>
      <button
        onClick={clear}
        className="text-xs self-end px-3 py-1.5 rounded-lg"
        style={{ color: "var(--muted-foreground)", background: "var(--card)", border: "1px solid var(--border)" }}
      >
        Limpar
      </button>
    </div>
  );
}

/* ─── Step: Assinatura ───────────────────────────────────── */
function StepAssinatura({
  nr,
  respName,
  vigiaName,
  signResp,
  signVigia,
  onSignResp,
  onSignVigia,
  hasVigia,
}: {
  nr: NRDefinition;
  respName: string;
  vigiaName: string;
  signResp: string;
  signVigia: string;
  onSignResp: (v: string) => void;
  onSignVigia: (v: string) => void;
  hasVigia: boolean;
}) {
  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-5">
      <div>
        <h2 className="text-xl font-bold" style={{ color: "var(--foreground)" }}>Assinatura Digital</h2>
        <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>Assine para validar a PET</p>
      </div>

      <div className="p-3.5 rounded-xl flex items-start gap-3" style={{ background: "var(--card)", border: "1px solid #00d4aa20" }}>
        <span style={{ color: "var(--primary)" }}>ℹ</span>
        <p className="text-xs leading-relaxed" style={{ color: "var(--secondary-foreground)" }}>
          A assinatura digital tem valor equivalente à assinatura física conforme a política interna de segurança do trabalho.
        </p>
      </div>

      <div className="p-4 rounded-xl" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
        <div className="flex items-center gap-2 mb-1">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold"
            style={{ background: `${nr.color}20`, color: nr.color }}
          >
            {respName.split(" ").map(n => n[0]).slice(0, 2).join("")}
          </div>
          <div>
            <div className="text-sm font-semibold" style={{ color: "var(--foreground)" }}>{respName}</div>
            <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>Responsável Técnico</div>
          </div>
        </div>
        <div className="mt-3">
          <SignatureCanvas
            value={signResp}
            onSigned={onSignResp}
            label="Assinatura do Responsável Técnico *"
            color={nr.color}
          />
        </div>
      </div>

      {hasVigia && (
        <div className="p-4 rounded-xl" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold" style={{ background: "#a855f720", color: "#a855f7" }}>
              {vigiaName.split(" ").map(n => n[0]).slice(0, 2).join("")}
            </div>
            <div>
              <div className="text-sm font-semibold" style={{ color: "var(--foreground)" }}>{vigiaName}</div>
              <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>Vigia de Segurança</div>
            </div>
          </div>
          <div className="mt-3">
            <SignatureCanvas
              value={signVigia}
              onSigned={onSignVigia}
              label="Assinatura do Vigia *"
              color="#a855f7"
            />
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Step: Review ───────────────────────────────────────── */
function StepReview({
  permitType,
  employees,
  nr,
  fields,
  answers,
  workers,
  vigias,
  responsavel,
  date, time,
  onEmit,
}: {
  permitType: PermitType;
  employees: Employee[];
  nr: NRDefinition;
  fields: Record<string, string>;
  answers: Record<string, CheckAnswer>;
  workers: Set<string>;
  vigias: Set<string>;
  responsavel: string | null;
  date: string; time: string;
  onEmit: () => void;
}) {
  const naoCount = Object.values(answers).filter(a => a === "NÃO").length;
  const answeredCount = Object.keys(answers).length;
  const respName = employees.find(e => e.id === responsavel)?.name ?? "—";
  const organizationVigias = employees.filter(e => e.cargo.toLowerCase().includes("vigia") || e.cargo.toLowerCase().includes("segurança") || e.setor === "SESMT");
  const vigiaNames = organizationVigias.filter(v => vigias.has(v.id)).map(v => v.name.split(" ")[0]);
  const workerList = employees.filter(e => workers.has(e.id));

  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-4">
      <div>
        <h2 className="text-xl font-bold" style={{ color: "var(--foreground)" }}>Revisão Final</h2>
        <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>Confirme e emita a {permitType}</p>
      </div>

      {naoCount > 0 && (
        <div className="p-3.5 rounded-xl flex items-start gap-3" style={{ background: "#ef444415", border: "1px solid #ef444440" }}>
          <span style={{ color: "var(--danger)" }}>⚠</span>
          <p className="text-xs" style={{ color: "var(--danger)" }}>
            {naoCount} item(ns) NÃO conforme(s). Medida corretiva obrigatória antes de emitir.
          </p>
        </div>
      )}

      <div className="rounded-2xl overflow-hidden" style={{ background: "var(--card)", border: `1px solid ${nr.color}40` }}>
        <div className="h-[3px]" style={{ background: nr.color }} />
        <div className="p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg" style={{ background: `${nr.color}20`, color: nr.color }}>
            {nr.icon}
          </div>
          <div>
            <div className="font-bold text-base" style={{ color: "var(--foreground)" }}>{nr.name}</div>
            <div className="text-xs" style={{ color: nr.color }}>{nr.code} · {fields["setor"] ?? "—"}</div>
          </div>
        </div>
      </div>

      {[
        { label: "Data / Hora", value: `${date} às ${time}` },
        { label: "Responsável", value: respName },
        { label: "Vigia(s)", value: vigiaNames.join(", ") || (nr.code !== "NR-33" ? "N/A" : "—") },
        { label: "Trabalhadores", value: `${workers.size} selecionado(s)` },
        { label: "Checklist", value: `${answeredCount}/${nr.checklist.length} · ${naoCount} NÃO` },
      ].map(row => (
        <div key={row.label} className="flex items-center justify-between py-2 border-b" style={{ borderColor: "var(--border)" }}>
          <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>{row.label}</span>
          <span className="text-xs font-semibold" style={{ color: "var(--foreground)" }}>{row.value}</span>
        </div>
      ))}

      {workerList.length > 0 && (
        <div className="flex flex-col gap-1.5">
          <div className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--muted-foreground)" }}>Equipe</div>
          {workerList.map(w => (
            <div key={w.id} className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full" style={{ background: nr.color }} />
              <span className="text-xs" style={{ color: "var(--secondary-foreground)" }}>{w.name}</span>
              <span className="text-[10px] ml-auto" style={{ color: "var(--faint)" }}>{w.cargo}</span>
            </div>
          ))}
        </div>
      )}

      <button
        onClick={onEmit}
        className="w-full rounded-xl py-4 font-bold text-sm mt-2 flex items-center justify-center gap-2"
        style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
      >
        Emitir {permitType}
      </button>
    </div>
  );
}

/* ─── Main Wizard ────────────────────────────────────────── */
export default function NovaPET({ employees, onBack, onEmit, organizationOptions, onOptionCreated, onCreateEmployee }: Props) {
  const [step, setStep] = useState(0);
  const [permitType, setPermitType] = useState<PermitType | null>(null);
  const [selectedNR, setSelectedNR] = useState<NRCode | null>(null);
  const [fields, setFields] = useState<Record<string, string>>({});
  const [checkAnswers, setCheckAnswers] = useState<Record<string, CheckAnswer>>({});
  const [selectedWorkers, setSelectedWorkers] = useState<Set<string>>(new Set());
  const [selectedVigias, setSelectedVigias] = useState<Set<string>>(new Set());
  const [responsavel, setResponsavel] = useState<string | null>(null);
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [time, setTime] = useState("08:00");
  const [signResp, setSignResp] = useState("");
  const [signVigia, setSignVigia] = useState("");
  const [emitted, setEmitted] = useState(false);

  const nr = NR_DATA.find(n => n.code === selectedNR) ?? null;
  const stepNames = getStepNames(selectedNR);
  const totalSteps = stepNames.length;
  const currentStepName = stepNames[step] as StepName;

  const hasVigia = selectedNR === "NR-33";

  const organizationVigias = employees.filter(e => e.cargo.toLowerCase().includes("vigia") || e.cargo.toLowerCase().includes("segurança") || e.setor === "SESMT");
  const respName = employees.find(e => e.id === responsavel)?.name ?? "";
  const vigiaName = organizationVigias.find(v => selectedVigias.has(v.id))?.name ?? "";

  function canProceed(): boolean {
    switch (currentStepName) {
      case "Tipo": return !!permitType;
      case "NR": return !!selectedNR;
      case "Dados": return !!(fields["setor"] && nr?.fields.filter(f => f.required).every(f => !!fields[f.id]));
      case "Checklist": return Object.keys(checkAnswers).length >= (nr?.checklist.length ?? 0);
      case "Equipe": return !!responsavel && selectedWorkers.size > 0;
      case "Vigia": return selectedVigias.size > 0;
      case "Horário": return !!(date && time);
      case "Assinatura": return !!signResp && (!hasVigia || !!signVigia);
      case "Revisão": return true;
    }
  }

  function next() {
    if (canProceed() && step < totalSteps - 1) setStep(s => s + 1);
  }

  function back() {
    if (step > 0) setStep(s => s - 1);
    else onBack();
  }

  function toggleWorker(id: string) {
    setSelectedWorkers(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  }

  function toggleVigia(id: string) {
    setSelectedVigias(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  }

  function emit() {
    if (!nr) return;
    const resp = employees.find(e => e.id === responsavel)!;
    const vigiaList = organizationVigias.filter(v => selectedVigias.has(v.id));
    const workerList = employees.filter(e => selectedWorkers.has(e.id));
    const num = String(452620 + Math.floor(Math.random() * 1000));
    const pet: PETRecord = {
      id: Date.now().toString(),
      permitType: permitType ?? "PET",
      numero: num,
      nr: nr.code,
      setor: fields["setor"] ?? "—",
      local: fields[nr.fields[0]?.id] ?? "—",
      tipo: nr.name,
      responsavel: resp?.name ?? "—",
      responsavelId: responsavel!,
      vigias: vigiaList,
      workers: workerList,
      fields,
      checkAnswers,
      abertura: `${date} ${time}`,
      status: "aberta",
      nrDef: nr,
      rondas: [],
      signatureResp: signResp,
      signatureVigia: signVigia,
    };
    setEmitted(true);
    setTimeout(() => onEmit(pet), 1400);
  }

  if (emitted) {
    return (
      <div className="theme-screen flex flex-col items-center justify-center min-h-full gap-6 px-8" style={{ background: "var(--background)" }}>
        <div className="w-20 h-20 rounded-full flex items-center justify-center text-3xl" style={{ background: "#00d4aa20", color: "var(--primary)" }}>✓</div>
        <div className="text-center">
          <div className="text-xl font-bold mb-1" style={{ color: "var(--foreground)" }}>{permitType} Emitida!</div>
          <div className="text-sm" style={{ color: "var(--muted-foreground)" }}>Redirecionando ao dashboard...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="theme-screen flex flex-col min-h-full" style={{ background: "var(--background)" }}>
      {/* header */}
      <div className="flex items-center justify-between px-5 pt-12 pb-2">
        <button
          onClick={back}
          className="w-9 h-9 rounded-lg flex items-center justify-center border"
          style={{ background: "var(--card)", borderColor: "var(--border)", color: "var(--secondary-foreground)" }}
        >
          <ArrowLeft />
        </button>
        <div className="text-sm font-bold" style={{ color: "var(--foreground)" }}>Nova {permitType ?? "Permissão"}</div>
        <div
          className="text-[10px] font-medium px-2.5 py-1 rounded-full"
          style={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--muted-foreground)", fontFamily: "'JetBrains Mono',monospace" }}
        >
          {step + 1}/{totalSteps}
        </div>
      </div>

      <StepBar step={step} stepNames={stepNames} />

      <div className="flex-1 overflow-y-auto">
        {currentStepName === "Tipo" && (
          <StepPermitType selected={permitType} onSelect={setPermitType} />
        )}
        {currentStepName === "NR" && (
          <StepNR selected={selectedNR} onSelect={c => { setSelectedNR(c); setCheckAnswers({}); }} />
        )}
        {currentStepName === "Dados" && nr && (
          <StepFields nr={nr} values={fields} organizationOptions={organizationOptions} onOptionCreated={async option => { const created = await onOptionCreated(option); return created; }} onChange={(id, val) => setFields(p => ({ ...p, [id]: val }))} />
        )}
        {currentStepName === "Checklist" && nr && (
          <StepChecklist nr={nr} answers={checkAnswers} onChange={(id, ans) => setCheckAnswers(p => ({ ...p, [id]: ans }))} />
        )}
        {currentStepName === "Equipe" && nr && (
          <StepEquipe nr={nr} employees={employees} selectedWorkers={selectedWorkers} responsavel={responsavel} onToggleWorker={toggleWorker} onSelectResponsavel={setResponsavel} onCreateEmployee={onCreateEmployee} />
        )}
        {currentStepName === "Vigia" && nr && (
          <StepVigia nr={nr} employees={employees} selectedVigias={selectedVigias} onToggle={toggleVigia} />
        )}
        {currentStepName === "Horário" && (
          <StepSchedule date={date} time={time} onChange={(k, v) => { if (k === "date") setDate(v); else setTime(v); }} />
        )}
        {currentStepName === "Assinatura" && nr && (
          <StepAssinatura
            nr={nr}
            respName={respName}
            vigiaName={vigiaName}
            signResp={signResp}
            signVigia={signVigia}
            onSignResp={setSignResp}
            onSignVigia={setSignVigia}
            hasVigia={hasVigia}
          />
        )}
        {currentStepName === "Revisão" && nr && (
          <StepReview
            permitType={permitType ?? "PET"}
            employees={employees}
            nr={nr}
            fields={fields}
            answers={checkAnswers}
            workers={selectedWorkers}
            vigias={selectedVigias}
            responsavel={responsavel}
            date={date} time={time}
            onEmit={emit}
          />
        )}
      </div>

      {currentStepName !== "Revisão" && (
        <div className="px-5 pb-8 pt-4">
          <button
            onClick={next}
            disabled={!canProceed()}
            className="w-full rounded-xl py-4 font-bold text-sm transition-all"
            style={{
              background: canProceed() ? "var(--primary)" : "var(--secondary)",
              color: canProceed() ? "var(--primary-foreground)" : "var(--faint)",
            }}
          >
            {currentStepName === "Assinatura" ? "Revisar PET" : "Continuar"}
          </button>
        </div>
      )}
    </div>
  );
}
