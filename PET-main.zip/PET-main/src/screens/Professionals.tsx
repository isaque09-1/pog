import { useEffect, useState } from "react";
import type { Employee } from "../data/employees";
import { createOrganizationEmployee, deactivateOrganizationEmployee, listOrganizationEmployees, updateOrganizationEmployee } from "../services/employees";

interface Props { organizationId: string; onBack: () => void; }
const JOBS = ["Técnico de Segurança", "Engenheiro de Segurança", "Vigia de Segurança", "Operador de Produção", "Operador de Guindaste", "Eletricista Industrial", "Soldador", "Mecânico Industrial", "Motorista", "Inspetor de Qualidade", "Outro"];
const SECTORS = ["SESMT", "Operacional", "Produção", "Manutenção", "Logística", "Controle de Qualidade", "Administrativo"];
const TRAININGS = ["NR-11", "NR-20", "NR-33", "NR-34", "NR-35"];
const emptyForm = { name: "", matricula: "", cargo: "", setor: "", treinamentos: [] as string[] };

export default function Professionals({ organizationId, onBack }: Props) {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  async function loadEmployees() {
    setLoading(true);
    try { setEmployees(await listOrganizationEmployees(organizationId)); setError(""); }
    catch { setError("Não foi possível carregar os profissionais da organização."); }
    finally { setLoading(false); }
  }
  useEffect(() => { loadEmployees(); }, [organizationId]);
  function resetForm() { setForm(emptyForm); setEditingId(null); }
  function toggleTraining(training: string) { setForm(current => ({ ...current, treinamentos: current.treinamentos.includes(training) ? current.treinamentos.filter(item => item !== training) : [...current.treinamentos, training] })); }
  function edit(employee: Employee) { setEditingId(employee.id); setForm({ name: employee.name, matricula: employee.matricula, cargo: employee.cargo, setor: employee.setor, treinamentos: employee.treinamentos }); window.scrollTo({ top: 0, behavior: "smooth" }); }

  async function submit(event: React.FormEvent) {
    event.preventDefault(); setError("");
    if (!form.name || !form.matricula || !form.cargo || !form.setor || form.treinamentos.length === 0) { setError("Preencha os dados e selecione ao menos um treinamento."); return; }
    setSaving(true);
    try {
      const employee = editingId ? await updateOrganizationEmployee(organizationId, { id: editingId, ...form }) : await createOrganizationEmployee(organizationId, form);
      setEmployees(current => [...current.filter(item => item.id !== employee.id), employee].sort((a, b) => a.name.localeCompare(b.name)));
      resetForm();
    } catch (submitError) { setError(submitError instanceof Error ? submitError.message : "Não foi possível salvar o profissional."); }
    finally { setSaving(false); }
  }

  async function remove(employee: Employee) {
    if (!window.confirm(`Remover ${employee.name} da lista de profissionais?`)) return;
    try { await deactivateOrganizationEmployee(organizationId, employee.id); setEmployees(current => current.filter(item => item.id !== employee.id)); if (editingId === employee.id) resetForm(); }
    catch { setError("Não foi possível remover o profissional."); }
  }

  const fieldStyle = { background: "var(--background)", color: "var(--foreground)", border: "1px solid var(--border)" };
  return <div className="flex flex-col min-h-full p-5" style={{ background: "var(--background)" }}>
    <button onClick={onBack} className="self-start mb-6 rounded-lg px-3 py-2 text-xs" style={{ background: "var(--card)", color: "var(--secondary-foreground)", border: "1px solid var(--border)" }}>Voltar ao painel</button>
    <div className="mb-6"><div className="text-xl font-bold" style={{ color: "var(--foreground)" }}>Profissionais da organização</div><div className="text-sm mt-1" style={{ color: "var(--muted-foreground)" }}>Somente profissionais ativos aqui podem ser escolhidos em PETs e PTs.</div></div>
    <form onSubmit={submit} className="grid gap-3 rounded-2xl p-4 mb-6" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
      <div className="text-sm font-bold" style={{ color: "var(--primary)" }}>{editingId ? "Editar profissional" : "Novo profissional"}</div>
      <label className="grid gap-1 text-xs" style={{ color: "var(--secondary-foreground)" }}>Nome completo<input required value={form.name} onChange={event => setForm(current => ({ ...current, name: event.target.value }))} className="rounded-lg px-3 py-2.5 outline-none" style={fieldStyle} /></label>
      <label className="grid gap-1 text-xs" style={{ color: "var(--secondary-foreground)" }}>Matrícula<input required value={form.matricula} onChange={event => setForm(current => ({ ...current, matricula: event.target.value }))} className="rounded-lg px-3 py-2.5 outline-none" style={fieldStyle} /></label>
      <label className="grid gap-1 text-xs" style={{ color: "var(--secondary-foreground)" }}>Cargo<select required value={form.cargo} onChange={event => setForm(current => ({ ...current, cargo: event.target.value }))} className="rounded-lg px-3 py-2.5 outline-none" style={fieldStyle}><option value="">Selecione o cargo</option>{JOBS.map(job => <option key={job}>{job}</option>)}</select></label>
      <label className="grid gap-1 text-xs" style={{ color: "var(--secondary-foreground)" }}>Setor<select required value={form.setor} onChange={event => setForm(current => ({ ...current, setor: event.target.value }))} className="rounded-lg px-3 py-2.5 outline-none" style={fieldStyle}><option value="">Selecione o setor</option>{SECTORS.map(sector => <option key={sector}>{sector}</option>)}</select></label>
      <fieldset className="grid gap-2"><legend className="text-xs" style={{ color: "var(--secondary-foreground)" }}>Treinamentos válidos</legend><div className="flex flex-wrap gap-2">{TRAININGS.map(training => <label key={training} className="flex items-center gap-2 rounded-lg px-3 py-2 text-xs" style={{ background: form.treinamentos.includes(training) ? "#00d4aa20" : "var(--background)", color: form.treinamentos.includes(training) ? "var(--primary)" : "var(--secondary-foreground)", border: "1px solid var(--border)" }}><input type="checkbox" checked={form.treinamentos.includes(training)} onChange={() => toggleTraining(training)} />{training}</label>)}</div></fieldset>
      {error && <div className="text-xs" style={{ color: "var(--danger)" }}>{error}</div>}
      <div className="flex gap-2"><button disabled={saving} className="flex-1 rounded-lg py-3 text-sm font-bold" style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}>{saving ? "Salvando..." : editingId ? "Salvar alterações" : "Adicionar profissional"}</button>{editingId && <button type="button" onClick={resetForm} className="rounded-lg px-4 text-sm" style={{ background: "var(--border)", color: "var(--foreground)" }}>Cancelar</button>}</div>
    </form>
    {loading ? <div className="text-sm" style={{ color: "var(--muted-foreground)" }}>Carregando profissionais...</div> : <div className="grid gap-2">{employees.map(employee => <div key={employee.id} className="rounded-xl p-3 flex items-center justify-between gap-3" style={{ background: "var(--card)", border: "1px solid var(--border)" }}><div><div className="text-sm font-semibold" style={{ color: "var(--foreground)" }}>{employee.name}</div><div className="text-xs mt-1" style={{ color: "var(--muted-foreground)" }}>{employee.matricula} · {employee.cargo} · {employee.setor}</div><div className="text-[10px] mt-1" style={{ color: "var(--primary)" }}>{employee.treinamentos.join(" · ")}</div></div><div className="flex gap-2"><button onClick={() => edit(employee)} className="rounded-lg px-3 py-2 text-xs" style={{ color: "var(--primary)", border: "1px solid #00d4aa50" }}>Editar</button><button onClick={() => remove(employee)} className="rounded-lg px-3 py-2 text-xs" style={{ color: "var(--danger)", border: "1px solid #ef444450" }}>Remover</button></div></div>)}</div>}
  </div>;
}
