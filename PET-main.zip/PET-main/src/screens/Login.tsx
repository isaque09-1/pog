import { useState } from "react";
import { EMPLOYEES } from "../data/employees";
import { isSupabaseConfigured, supabase } from "../lib/supabase";
import ThemeToggle from "../components/ThemeToggle";

export type UserRole = "admin" | "gestor" | "tecnico" | "vigia";

interface Props {
  onLogin: (role: UserRole, name: string, matricula: string, employeeId: string, organizationId?: string) => void;
  onEnterTestMode: () => void;
}

function detectRole(cargo: string): UserRole {
  return cargo.toLowerCase().includes("vigia") ? "vigia" : "tecnico";
}

function IconShield({ size = 26 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none">
      <path d="M10 2L3 5.5v5c0 4 3.1 7.4 7 8 3.9-.6 7-4 7-8v-5L10 2z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M7 10l2 2 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function Login({ onLogin, onEnterTestMode }: Props) {
  const [matricula, setMatricula] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const identifier = isSupabaseConfigured ? email : matricula;
    if (!identifier.trim() && !senha.trim()) {
      onEnterTestMode();
      return;
    }

    if (isSupabaseConfigured && supabase) {
      if (!email.trim() || !senha.trim()) {
        setError("Informe o e-mail e a senha.");
        return;
      }

      setLoading(true);
      const { data, error: authError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password: senha,
      });

      if (authError || !data.user) {
        setLoading(false);
        setError(authError?.message === "Invalid login credentials" ? "E-mail ou senha inválidos." : authError?.message ?? "Não foi possível entrar.");
        return;
      }

      const [{ data: profile }, { data: membership }] = await Promise.all([
        supabase.from("profiles").select("full_name, matricula").eq("id", data.user.id).maybeSingle(),
        supabase.from("organization_members").select("role, organization_id").eq("user_id", data.user.id).limit(1).maybeSingle(),
      ]);

      setLoading(false);
      if (!profile || !membership) {
        setError("Usuário autenticado, mas ainda não está vinculado a uma organização.");
        await supabase.auth.signOut();
        return;
      }

      onLogin(membership.role, profile.full_name, profile.matricula ?? "", data.user.id, membership.organization_id);
      return;
    }

    const employee = EMPLOYEES.find(emp => emp.matricula === matricula.trim());
    if (!employee) {
      setError("Matrícula não encontrada. Verifique e tente novamente.");
      return;
    }
    if (!senha.trim()) {
      setError("Informe a senha.");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      const role = detectRole(employee.cargo);
      onLogin(role, employee.name, employee.matricula, employee.id);
    }, 1100);
  }

  const previewEmployee = EMPLOYEES.find(e => e.matricula === matricula.trim());

  return (
    <div className="theme-screen flex flex-col min-h-full" style={{ background: "var(--background)" }}>
      <div className="flex justify-end px-6 pt-4">
        <ThemeToggle />
      </div>
      <div className="flex flex-col items-center pt-6 pb-8 px-6">
        <div
          className="w-14 h-14 rounded-2xl flex items-center justify-center mb-3"
          style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
        >
          <IconShield />
        </div>
        <div className="text-lg font-bold" style={{ color: "var(--foreground)" }}>PET Manager</div>
        <div
          className="text-[10px] font-medium uppercase tracking-widest mt-0.5"
          style={{ color: "var(--muted-foreground)", fontFamily: "'JetBrains Mono',monospace" }}
        >
          Gestão de Permissões de Trabalho
        </div>
      </div>

      <div className="flex-1 flex flex-col px-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-1" style={{ color: "var(--foreground)" }}>Acesso ao Sistema</h1>
            <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
            {isSupabaseConfigured ? "Entre com seu e-mail corporativo." : "Seu perfil é identificado automaticamente pela matrícula."}
          </p>
        </div>

        <form onSubmit={submit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--muted-foreground)" }}>
              {isSupabaseConfigured ? "E-mail" : "Matrícula"}
            </label>
            <input
              value={isSupabaseConfigured ? email : matricula}
              onChange={e => { isSupabaseConfigured ? setEmail(e.target.value) : setMatricula(e.target.value); setError(null); }}
              placeholder={isSupabaseConfigured ? "voce@empresa.com" : "Ex: 12345"}
              type={isSupabaseConfigured ? "email" : "text"}
              className="w-full rounded-xl px-4 py-3.5 text-sm outline-none transition-colors"
              style={{
                background: "var(--card)",
                border: `1px solid ${error ? "var(--danger)" : "var(--border)"}`,
                color: "var(--foreground)",
                fontFamily: "'JetBrains Mono',monospace",
              }}
              onFocus={e => { if (!error) e.target.style.borderColor = "var(--primary)"; }}
              onBlur={e => { if (!error) e.target.style.borderColor = "var(--border)"; }}
            />
          </div>

          {/* live employee preview in demo mode */}
          {!isSupabaseConfigured && previewEmployee && (
            <div
              className="flex items-center gap-3 px-4 py-3 rounded-xl -mt-1"
              style={{ background: "var(--card)", border: "1px solid #00d4aa40" }}
            >
              <div
                className="w-9 h-9 rounded-lg flex items-center justify-center text-sm font-bold flex-shrink-0"
                style={{ background: "#00d4aa20", color: "var(--primary)" }}
              >
                {previewEmployee.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold" style={{ color: "var(--foreground)" }}>{previewEmployee.name}</div>
                <div className="text-xs" style={{ color: "var(--muted-foreground)" }}>{previewEmployee.cargo}</div>
              </div>
              <div
                className="text-[10px] font-bold px-2.5 py-1 rounded-full flex-shrink-0"
                style={{
                  background: detectRole(previewEmployee.cargo) === "vigia" ? "#a855f720" : "#00d4aa20",
                  color: detectRole(previewEmployee.cargo) === "vigia" ? "#a855f7" : "var(--primary)",
                }}
              >
                {detectRole(previewEmployee.cargo) === "vigia" ? "Vigia" : "Técnico"}
              </div>
            </div>
          )}

          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--muted-foreground)" }}>
              Senha
            </label>
            <input
              type="password"
              value={senha}
              onChange={e => { setSenha(e.target.value); setError(null); }}
              placeholder="••••••"
              className="w-full rounded-xl px-4 py-3.5 text-sm outline-none transition-colors"
              style={{
                background: "var(--card)",
                border: `1px solid ${error ? "var(--danger)" : "var(--border)"}`,
                color: "var(--foreground)",
              }}
              onFocus={e => { if (!error) e.target.style.borderColor = "var(--primary)"; }}
              onBlur={e => { if (!error) e.target.style.borderColor = "var(--border)"; }}
            />
          </div>

          {error && (
            <div
              className="flex items-center gap-2 px-4 py-3 rounded-xl text-xs"
              style={{ background: "#ef444415", border: "1px solid #ef444430", color: "var(--danger)" }}
            >
              <span>⚠</span> {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl py-4 font-bold text-sm transition-all"
            style={{ background: loading ? "var(--primary-strong)" : "var(--primary)", color: "var(--primary-foreground)" }}
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <span className="w-4 h-4 border-2 border-[var(--primary-foreground)] border-t-transparent rounded-full animate-spin inline-block" />
                Identificando perfil...
              </span>
            ) : "Entrar"}
          </button>
          <p className="text-center text-[11px] -mt-1" style={{ color: "var(--faint)" }}>
            Sem cadastro? Clique em "Entrar" com os campos em branco para abrir o modo de teste.
          </p>
        </form>

        {/* demo hints */}
        {!isSupabaseConfigured && <div className="mt-5 p-4 rounded-xl" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
          <div className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--muted-foreground)" }}>
            Matrículas de demonstração
          </div>
          <div className="flex flex-col gap-1.5">
            {[
              { mat: "12346", name: "Ana Lima", role: "Técnico" },
              { mat: "12357", name: "Priscila Andrade", role: "Vigia" },
              { mat: "12358", name: "Eduardo Torres", role: "Vigia" },
            ].map(u => (
              <button
                key={u.mat}
                onClick={() => { setMatricula(u.mat); setSenha("1234"); setError(null); }}
                className="flex items-center gap-3 text-left"
              >
                <span
                  className="text-[10px] font-bold"
                  style={{ color: "var(--primary)", fontFamily: "'JetBrains Mono',monospace", minWidth: 44 }}
                >
                  {u.mat}
                </span>
                <span className="text-xs flex-1" style={{ color: "var(--secondary-foreground)" }}>{u.name}</span>
                <span
                  className="text-[9px] font-bold px-2 py-0.5 rounded-full"
                  style={{ background: u.role === "Vigia" ? "#a855f720" : "#00d4aa20", color: u.role === "Vigia" ? "#a855f7" : "var(--primary)" }}
                >
                  {u.role}
                </span>
              </button>
            ))}
          </div>
        </div>}
      </div>

      <div className="px-6 pb-8 mt-6 text-center text-[10px]" style={{ color: "var(--faint)" }}>
        © 2026 · PET Manager v2.5.0 · NR-11 · NR-20 · NR-33 · NR-34 · NR-35
      </div>
    </div>
  );
}
