import { useState, useEffect, useCallback } from "react";
import type { PETRecord, Ronda } from "../types";

interface Props {
  pet: PETRecord;
  vigiaName: string;
  onUpdatePet: (updated: PETRecord) => void;
  onBack: () => void;
}

type WorkerStatus = "dentro" | "fora";

function IconAlert() {
  return (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <path d="M16 4l14 24H2L16 4z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
      <path d="M16 13v7M16 23.5v1" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

function IconPhone() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <path d="M6.5 3h-2a1 1 0 00-1 1v1.5c0 7.18 5.82 13 13 13H18a1 1 0 001-1v-2a1 1 0 00-.7-.95l-2.8-.93a1 1 0 00-1.1.37l-.9 1.2a11 11 0 01-5.14-5.14l1.2-.9a1 1 0 00.37-1.1l-.93-2.8A1 1 0 006.5 3z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
    </svg>
  );
}

function IconCheck() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M3 8l3.5 3.5 6.5-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function IconX() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function IconArrowLeft() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
      <path d="M11 4L6 9l5 5" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function now() {
  return new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

function nowFull() {
  return new Date().toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
}

const RESCUE_CONTACTS = [
  { label: "SAMU", number: "192", color: "var(--danger)" },
  { label: "Bombeiros", number: "193", color: "var(--warning)" },
  { label: "SESMT", number: "(45) 3243-1293", color: "#3b82f6" },
  { label: "Emergência Planta", number: "Ramal 190", color: "#a855f7" },
];

export default function VigiaView({ pet, vigiaName, onUpdatePet, onBack }: Props) {
  async function downloadReport() {
    try {
      const { generatePDF } = await import("../utils/generatePDF");
      generatePDF(pet);
    } catch (error) {
      console.error("Não foi possível gerar o relatório.", error);
      window.alert("Não foi possível gerar o relatório. Tente novamente.");
    }
  }
  const [workerStatus, setWorkerStatus] = useState<Record<string, WorkerStatus>>(() => {
    const init: Record<string, WorkerStatus> = {};
    pet.workers.forEach(w => { init[w.id] = "fora"; });
    return init;
  });
  const [emergency, setEmergency] = useState(false);
  const [holdProgress, setHoldProgress] = useState(0);
  const [holding, setHolding] = useState(false);
  const [rondaMsg, setRondaMsg] = useState("");
  const [addingRonda, setAddingRonda] = useState(false);
  const [elapsed, setElapsed] = useState("00:00");

  const insideCount = Object.values(workerStatus).filter(s => s === "dentro").length;

  // elapsed timer
  useEffect(() => {
    const start = Date.now();
    const iv = setInterval(() => {
      const diff = Math.floor((Date.now() - start) / 1000);
      const m = Math.floor(diff / 60).toString().padStart(2, "0");
      const s = (diff % 60).toString().padStart(2, "0");
      setElapsed(`${m}:${s}`);
    }, 1000);
    return () => clearInterval(iv);
  }, []);

  // hold to trigger emergency
  useEffect(() => {
    if (!holding) {
      setHoldProgress(0);
      return;
    }
    const iv = setInterval(() => {
      setHoldProgress(p => {
        if (p >= 100) {
          setEmergency(true);
          setHolding(false);
          clearInterval(iv);
          return 100;
        }
        return p + 4;
      });
    }, 80);
    return () => clearInterval(iv);
  }, [holding]);

  const toggleWorker = useCallback((id: string) => {
    setWorkerStatus(prev => ({
      ...prev,
      [id]: prev[id] === "dentro" ? "fora" : "dentro",
    }));
  }, []);

  function addRonda() {
    const r: Ronda = {
      id: Date.now().toString(),
      time: nowFull(),
      vigia: vigiaName,
      note: rondaMsg.trim() || "Ronda OK — sem ocorrências",
      ok: true,
    };
    onUpdatePet({ ...pet, rondas: [...pet.rondas, r] });
    setRondaMsg("");
    setAddingRonda(false);
  }

  const nrColor = pet.nrDef.color;

  return (
    <div className="theme-screen flex flex-col min-h-full pb-10" style={{ background: "var(--background)" }}>
      {/* header */}
      <div className="flex items-center justify-between px-5 pt-12 pb-3">
        <button
          onClick={onBack}
          className="w-9 h-9 rounded-lg flex items-center justify-center border"
          style={{ background: "var(--card)", borderColor: "var(--border)", color: "var(--secondary-foreground)" }}
        >
          <IconArrowLeft />
        </button>
        <div className="text-center">
          <div className="text-xs font-bold" style={{ color: "var(--foreground)" }}>MODO VIGIA</div>
          <div
            className="text-[9px] font-medium"
            style={{ color: "var(--primary)", fontFamily: "'JetBrains Mono',monospace" }}
          >
            {elapsed} em serviço
          </div>
        </div>
        <div
          className="px-2.5 py-1 rounded-full text-[10px] font-bold"
          style={{ background: "#ef444420", color: "var(--danger)" }}
        >
          ● ATIVO
        </div>
      </div>

      {/* PET card */}
      <div className="px-5 mb-4">
        <div className="rounded-2xl overflow-hidden" style={{ background: "var(--card)", border: `1px solid ${nrColor}40` }}>
          <div className="h-[3px]" style={{ background: nrColor }} />
          <div className="p-4">
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span
                    className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                    style={{ background: `${nrColor}25`, color: nrColor }}
                  >
                    {pet.nr}
                  </span>
                  <span
                    className="text-[10px]"
                    style={{ color: "var(--muted-foreground)", fontFamily: "'JetBrains Mono',monospace" }}
                  >
                    Nº {pet.numero}
                  </span>
                </div>
                <div className="text-base font-bold" style={{ color: "var(--foreground)" }}>{pet.tipo}</div>
                <div className="text-xs mt-0.5" style={{ color: "var(--muted-foreground)" }}>{pet.local} · {pet.setor}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
              {[
                { label: "Abertura", value: pet.abertura },
                { label: "Responsável", value: pet.responsavel.split(" ")[0] },
                { label: "Vigia", value: vigiaName.split(" ")[0] },
              ].map(r => (
                <div key={r.label}>
                  <div className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: "var(--faint)" }}>{r.label}</div>
                  <div className="text-xs font-medium" style={{ color: "var(--secondary-foreground)" }}>{r.value}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* workers inside/outside */}
      <div className="px-5 mb-4">
        <div className="flex items-center justify-between mb-2">
          <div className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--muted-foreground)" }}>
            Controle de Entrada
          </div>
          <div
            className="text-[10px] font-bold px-2.5 py-1 rounded-full"
            style={{
              background: insideCount > 0 ? "#ef444418" : "#00d4aa18",
              color: insideCount > 0 ? "var(--danger)" : "var(--primary)",
            }}
          >
            {insideCount} dentro
          </div>
        </div>

        <div className="flex flex-col gap-2">
          {pet.workers.map(w => {
            const inside = workerStatus[w.id] === "dentro";
            return (
              <div
                key={w.id}
                className="flex items-center gap-3 p-3 rounded-xl transition-all"
                style={{
                  background: inside ? "#ef444412" : "var(--card)",
                  border: `1px solid ${inside ? "#ef444440" : "var(--border)"}`,
                }}
              >
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold flex-shrink-0"
                  style={{
                    background: inside ? "#ef444425" : "var(--secondary)",
                    color: inside ? "var(--danger)" : "var(--muted-foreground)",
                  }}
                >
                  {w.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold" style={{ color: "var(--foreground)" }}>{w.name}</div>
                  <div className="text-xs" style={{ color: inside ? "var(--danger)" : "var(--muted-foreground)" }}>
                    {inside ? "● Dentro do local" : "○ Fora / Aguardando"}
                  </div>
                </div>
                <button
                  onClick={() => toggleWorker(w.id)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all"
                  style={{
                    background: inside ? "#00d4aa15" : "#ef444415",
                    color: inside ? "var(--primary)" : "var(--danger)",
                    border: `1px solid ${inside ? "#00d4aa30" : "#ef444430"}`,
                  }}
                >
                  {inside ? <><IconCheck /> Saiu</> : <><IconX /> Entrou</>}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* ronda log */}
      <div className="px-5 mb-4">
        <div className="flex items-center justify-between mb-2">
          <div className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--muted-foreground)" }}>
            Registro de Rondas
          </div>
          <button
            onClick={() => setAddingRonda(v => !v)}
            className="text-[10px] font-bold px-2.5 py-1 rounded-full"
            style={{ background: "#00d4aa20", color: "var(--primary)" }}
          >
            + Registrar
          </button>
        </div>

        {addingRonda && (
          <div className="rounded-xl p-3 mb-3" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
            <input
              value={rondaMsg}
              onChange={e => setRondaMsg(e.target.value)}
              placeholder="Observação (opcional)..."
              className="w-full rounded-lg px-3 py-2.5 text-xs outline-none mb-2"
              style={{ background: "var(--background)", border: "1px solid var(--border)", color: "var(--foreground)" }}
            />
            <div className="flex gap-2">
              <button onClick={() => setAddingRonda(false)} className="flex-1 py-2 rounded-lg text-xs font-medium" style={{ background: "var(--secondary)", color: "var(--muted-foreground)" }}>
                Cancelar
              </button>
              <button onClick={addRonda} className="flex-1 py-2 rounded-lg text-xs font-bold" style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}>
                Confirmar Ronda
              </button>
            </div>
          </div>
        )}

        {pet.rondas.length === 0 && !addingRonda && (
          <div
            className="rounded-xl p-4 text-center"
            style={{ background: "var(--card)", border: "1px solid var(--border)" }}
          >
            <div className="text-xs" style={{ color: "var(--faint)" }}>Nenhuma ronda registrada ainda</div>
            <div className="text-[10px] mt-0.5" style={{ color: "var(--faint)" }}>Registre rondas a cada 30 minutos</div>
          </div>
        )}

        <div className="flex flex-col gap-2">
          {[...pet.rondas].reverse().map(r => (
            <div key={r.id} className="flex items-start gap-3 p-3 rounded-xl" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
              <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: "#00d4aa20", color: "var(--primary)" }}>
                <IconCheck />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-semibold" style={{ color: "var(--foreground)" }}>Ronda OK</div>
                  <div className="text-[10px]" style={{ color: "var(--faint)", fontFamily: "'JetBrains Mono',monospace" }}>{r.time}</div>
                </div>
                <div className="text-[11px] mt-0.5" style={{ color: "var(--muted-foreground)" }}>{r.note}</div>
                <div className="text-[10px] mt-0.5" style={{ color: "var(--faint)" }}>por {r.vigia}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ─── PDF BUTTON ──────────────────────────────────── */}
      <div className="px-5 mb-4">
        <button
          onClick={downloadReport}
          className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl text-sm font-semibold transition-all"
          style={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--secondary-foreground)" }}
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M9 1H4a1 1 0 00-1 1v11a1 1 0 001 1h8a1 1 0 001-1V5L9 1z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
            <path d="M9 1v4h4M4 9h8M4 11.5h5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
          </svg>
          Gerar PDF da PET
        </button>
      </div>

      {/* ─── EMERGENCY BUTTON ─────────────────────────────── */}
      <div className="px-5 mt-2">
        <div
          className="text-[10px] font-semibold uppercase tracking-wider text-center mb-3"
          style={{ color: "var(--muted-foreground)" }}
        >
          Segurar 2 segundos para acionar emergência
        </div>

        <div className="relative overflow-hidden rounded-2xl" style={{ border: "2px solid var(--danger)" }}>
          {/* hold progress fill */}
          {holding && (
            <div
              className="absolute inset-0 transition-none"
              style={{ background: "#ef444440", width: `${holdProgress}%`, zIndex: 0 }}
            />
          )}
          <button
            onPointerDown={() => setHolding(true)}
            onPointerUp={() => setHolding(false)}
            onPointerLeave={() => setHolding(false)}
            className="relative w-full py-6 flex flex-col items-center gap-2 transition-all select-none"
            style={{
              background: holding ? "transparent" : "#ef444418",
              color: "var(--danger)",
              zIndex: 1,
            }}
          >
            <IconAlert />
            <div className="text-lg font-black tracking-wide">EMERGÊNCIA</div>
            <div className="text-xs font-medium" style={{ color: "#ef444480" }}>
              {holding ? `Acionando... ${Math.min(100, holdProgress)}%` : "Segurar para acionar"}
            </div>
          </button>
        </div>
      </div>

      {/* Emergency Modal */}
      {emergency && (
        <div
          className="fixed inset-0 z-50 flex flex-col"
          style={{ background: "var(--danger-well)", maxWidth: 430, margin: "0 auto" }}
        >
          {/* pulsing top bar */}
          <div className="h-2 animate-pulse" style={{ background: "var(--danger)" }} />

          <div className="flex-1 flex flex-col px-5 pt-8 pb-10 overflow-y-auto">
            {/* header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center animate-pulse" style={{ background: "#ef444430", color: "var(--danger)" }}>
                  <IconAlert />
                </div>
                <div>
                  <div className="text-xl font-black" style={{ color: "var(--danger)" }}>EMERGÊNCIA</div>
                  <div className="text-xs font-medium" style={{ color: "#ef444480" }}>Acionado às {now()}</div>
                </div>
              </div>
              <button
                onClick={() => setEmergency(false)}
                className="px-3 py-2 rounded-lg text-xs font-medium"
                style={{ background: "var(--danger-well)", border: "1px solid #ef444430", color: "var(--danger)" }}
              >
                Cancelar
              </button>
            </div>

            {/* PET info */}
            <div className="rounded-xl p-4 mb-4" style={{ background: "var(--danger-well)", border: "1px solid #ef444430" }}>
              <div className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "#ef444470" }}>
                PET em Emergência
              </div>
              <div className="text-sm font-bold" style={{ color: "var(--foreground)" }}>{pet.tipo}</div>
              <div className="text-xs mt-0.5" style={{ color: "var(--danger)" }}>{pet.local} · {pet.setor}</div>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: "#ef444430", color: "var(--danger)" }}>
                  {pet.nr}
                </span>
                <span className="text-[10px]" style={{ color: "var(--muted-foreground)", fontFamily: "'JetBrains Mono',monospace" }}>
                  Nº {pet.numero}
                </span>
              </div>
            </div>

            {/* workers inside */}
            <div className="rounded-xl p-4 mb-4" style={{ background: "var(--danger-well)", border: "1px solid #ef444430" }}>
              <div className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "#ef444470" }}>
                {insideCount} Trabalhador(es) no Local
              </div>
              {pet.workers.map(w => (
                <div key={w.id} className="flex items-center gap-2 py-1.5">
                  <div
                    className="w-1.5 h-1.5 rounded-full flex-shrink-0 animate-pulse"
                    style={{ background: workerStatus[w.id] === "dentro" ? "var(--danger)" : "var(--faint)" }}
                  />
                  <span className="text-sm" style={{ color: workerStatus[w.id] === "dentro" ? "var(--foreground)" : "var(--faint)" }}>
                    {w.name}
                  </span>
                  <span className="text-xs ml-auto" style={{ color: workerStatus[w.id] === "dentro" ? "var(--danger)" : "var(--faint)" }}>
                    {workerStatus[w.id] === "dentro" ? "DENTRO" : "fora"}
                  </span>
                </div>
              ))}
            </div>

            {/* rescue contacts */}
            <div className="text-[10px] font-semibold uppercase tracking-wider mb-3" style={{ color: "#ef444470" }}>
              Contatos de Resgate — Ligue Agora
            </div>
            <div className="flex flex-col gap-3">
              {RESCUE_CONTACTS.map(c => (
                <a
                  key={c.label}
                  href={`tel:${c.number.replace(/\D/g, "")}`}
                  className="flex items-center gap-4 p-4 rounded-xl no-underline transition-all active:opacity-80"
                  style={{ background: `${c.color}18`, border: `1px solid ${c.color}50` }}
                >
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: `${c.color}25`, color: c.color }}
                  >
                    <IconPhone />
                  </div>
                  <div className="flex-1">
                    <div className="text-base font-black" style={{ color: c.color }}>{c.label}</div>
                    <div
                      className="text-sm font-bold mt-0.5"
                      style={{ color: "var(--foreground)", fontFamily: "'JetBrains Mono',monospace" }}
                    >
                      {c.number}
                    </div>
                  </div>
                  <div style={{ color: c.color, opacity: 0.6 }}>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path d="M7 4l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                </a>
              ))}
            </div>

            {/* vigia info */}
            <div className="mt-4 p-3 rounded-xl text-center" style={{ background: "var(--danger-well)", border: "1px solid var(--border)" }}>
              <div className="text-xs" style={{ color: "var(--muted-foreground)" }}>
                Emergência acionada por <strong style={{ color: "var(--foreground)" }}>{vigiaName}</strong>
              </div>
              <div className="text-[10px] mt-0.5" style={{ color: "var(--faint)" }}>
                Resp: {pet.responsavel}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
