create table if not exists public.organization_options (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  category text not null,
  label text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (organization_id, category, label)
);

alter table public.organization_options enable row level security;
create policy "members can read organization options"
  on public.organization_options for select
  using (public.is_organization_member(organization_id));
create policy "admins can create organization options"
  on public.organization_options for insert
  with check (public.has_organization_role(organization_id, array['admin', 'gestor', 'tecnico']::public.member_role[]));

create or replace function public.close_permit(
  target_permit_id uuid,
  target_status public.permit_status,
  target_reason text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare target_org uuid;
begin
  select organization_id into target_org from public.permits where id = target_permit_id;
  if target_org is null or not public.has_organization_role(target_org, array['admin', 'gestor', 'tecnico']::public.member_role[]) then
    raise exception 'Usuário não autorizado para encerrar esta permissão';
  end if;
  update public.permits
  set status = target_status, closed_at = now(), cancel_reason = target_reason, updated_at = now()
  where id = target_permit_id;
  insert into public.audit_logs (organization_id, user_id, permit_id, action, metadata)
  values (target_org, auth.uid(), target_permit_id, 'permit.closed', jsonb_build_object('status', target_status, 'reason', target_reason));
end;
$$;

grant execute on function public.close_permit(uuid, public.permit_status, text) to authenticated;
