alter table public.employees
  drop constraint if exists employees_organization_id_matricula_key;

with duplicated as (
  select id,
    row_number() over (
      partition by organization_id, matricula
      order by created_at desc, id desc
    ) as position
  from public.employees
  where active = true
)
update public.employees
set active = false
where id in (select id from duplicated where position > 1);

create unique index if not exists employees_active_organization_matricula_key
  on public.employees (organization_id, matricula)
  where active = true;