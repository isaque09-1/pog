alter table public.permit_workers
  drop constraint if exists permit_workers_employee_id_fkey;

alter table public.permit_workers
  add constraint permit_workers_employee_id_fkey
  foreign key (employee_id) references public.employees(id) on delete restrict;

alter table public.permit_watchers
  rename column user_id to employee_id;

alter table public.permit_watchers
  drop constraint if exists permit_watchers_user_id_fkey;

alter table public.permit_watchers
  add constraint permit_watchers_employee_id_fkey
  foreign key (employee_id) references public.employees(id) on delete restrict;

create policy "technical members can create permit workers"
  on public.permit_workers for insert
  with check (exists (
    select 1 from public.permits p
    where p.id = permit_id
      and public.has_organization_role(p.organization_id, array['admin', 'gestor', 'tecnico']::public.member_role[])
  ));

create policy "technical members can create permit watchers"
  on public.permit_watchers for insert
  with check (exists (
    select 1 from public.permits p
    where p.id = permit_id
      and public.has_organization_role(p.organization_id, array['admin', 'gestor', 'tecnico']::public.member_role[])
  ));
