create or replace function public.create_permit_with_people(payload jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  created_id uuid;
  target_org uuid := (payload->>'organization_id')::uuid;
  current_user_id uuid := auth.uid();
begin
  if current_user_id is null or not public.has_organization_role(target_org, array['admin', 'gestor', 'tecnico']::public.member_role[]) then
    raise exception 'Usuário não autorizado para esta organização';
  end if;

  insert into public.permits (
    organization_id, number, permit_type, nr_code, sector, location, title,
    responsible_user_id, created_by, status, fields, check_answers,
    signature_resp, signature_vigia, opened_at
  ) values (
    target_org,
    payload->>'number',
    (payload->>'permit_type')::public.permit_type,
    payload->>'nr_code',
    payload->>'sector',
    payload->>'location',
    payload->>'title',
    current_user_id,
    current_user_id,
    coalesce((payload->>'status')::public.permit_status, 'aberta'),
    coalesce(payload->'fields', '{}'::jsonb),
    coalesce(payload->'check_answers', '{}'::jsonb),
    nullif(payload->>'signature_resp', ''),
    nullif(payload->>'signature_vigia', ''),
    coalesce((payload->>'opened_at')::timestamptz, now())
  ) returning id into created_id;

  insert into public.permit_workers (permit_id, employee_id)
  select created_id, value::uuid
  from jsonb_array_elements_text(coalesce(payload->'worker_ids', '[]'::jsonb));

  insert into public.permit_watchers (permit_id, employee_id)
  select created_id, value::uuid
  from jsonb_array_elements_text(coalesce(payload->'watcher_ids', '[]'::jsonb));

  insert into public.audit_logs (organization_id, user_id, permit_id, action, metadata)
  values (target_org, current_user_id, created_id, 'permit.created', jsonb_build_object('permit_type', payload->>'permit_type'));

  return created_id;
end;
$$;
