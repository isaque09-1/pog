create or replace function public.has_organization_role(
  target_organization_id uuid,
  allowed_roles public.member_role[]
)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.organization_members
    where organization_id = target_organization_id
      and user_id = auth.uid()
      and role = any(allowed_roles)
  );
$$;

drop policy if exists "technical members can create permits" on public.permits;
create policy "technical members can create permits"
  on public.permits for insert
  with check (
    public.has_organization_role(
      organization_id,
      array['admin', 'gestor', 'tecnico']::public.member_role[]
    )
    and created_by = auth.uid()
  );

drop policy if exists "technical members can update permits" on public.permits;
create policy "technical members can update permits"
  on public.permits for update
  using (
    public.has_organization_role(
      organization_id,
      array['admin', 'gestor', 'tecnico']::public.member_role[]
    )
  )
  with check (
    public.has_organization_role(
      organization_id,
      array['admin', 'gestor', 'tecnico']::public.member_role[]
    )
  );

drop policy if exists "watchers can create rounds" on public.rounds;
create policy "watchers can create rounds"
  on public.rounds for insert
  with check (
    watcher_user_id = auth.uid()
    and exists (
      select 1
      from public.permits p
      where p.id = permit_id
        and public.has_organization_role(
          p.organization_id,
          array['admin', 'gestor', 'tecnico', 'vigia']::public.member_role[]
        )
    )
  );
