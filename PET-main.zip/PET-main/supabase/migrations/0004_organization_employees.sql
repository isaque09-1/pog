create table if not exists public.employees (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  full_name text not null,
  matricula text not null,
  cargo text not null,
  setor text not null,
  treinamentos text[] not null default '{}',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (organization_id, matricula)
);

create index if not exists employees_organization_active_idx
  on public.employees (organization_id, active, full_name);

alter table public.employees enable row level security;

create policy "members can read organization employees"
  on public.employees for select
  using (public.is_organization_member(organization_id));

create policy "admins can create organization employees"
  on public.employees for insert
  with check (public.has_organization_role(organization_id, array['admin', 'gestor']::public.member_role[]));

create policy "admins can update organization employees"
  on public.employees for update
  using (public.has_organization_role(organization_id, array['admin', 'gestor']::public.member_role[]))
  with check (public.has_organization_role(organization_id, array['admin', 'gestor']::public.member_role[]));
