create extension if not exists "pgcrypto";

create type public.permit_type as enum ('PET', 'PT');
create type public.permit_status as enum ('aberta', 'encerrada', 'cancelada');
create type public.member_role as enum ('admin', 'gestor', 'tecnico', 'vigia');

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  matricula text,
  created_at timestamptz not null default now()
);

create table public.organization_members (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role public.member_role not null default 'tecnico',
  created_at timestamptz not null default now(),
  primary key (organization_id, user_id)
);

create table public.permits (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  number text not null,
  permit_type public.permit_type not null,
  nr_code text not null,
  sector text not null,
  location text not null,
  title text not null,
  responsible_user_id uuid not null references public.profiles(id) on delete restrict,
  status public.permit_status not null default 'aberta',
  fields jsonb not null default '{}'::jsonb,
  check_answers jsonb not null default '{}'::jsonb,
  signature_resp text,
  signature_vigia text,
  opened_at timestamptz not null default now(),
  closed_at timestamptz,
  cancel_reason text,
  created_by uuid not null references public.profiles(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, number)
);

create table public.permit_workers (
  permit_id uuid not null references public.permits(id) on delete cascade,
  employee_id uuid not null references public.profiles(id) on delete restrict,
  primary key (permit_id, employee_id)
);

create table public.permit_watchers (
  permit_id uuid not null references public.permits(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete restrict,
  primary key (permit_id, user_id)
);

create table public.rounds (
  id uuid primary key default gen_random_uuid(),
  permit_id uuid not null references public.permits(id) on delete cascade,
  watcher_user_id uuid not null references public.profiles(id) on delete restrict,
  note text not null default '',
  ok boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete set null,
  permit_id uuid references public.permits(id) on delete set null,
  action text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index permits_organization_status_idx on public.permits (organization_id, status);
create index permits_organization_opened_idx on public.permits (organization_id, opened_at desc);
create index audit_logs_organization_created_idx on public.audit_logs (organization_id, created_at desc);

create or replace function public.is_organization_member(target_organization_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.organization_members
    where organization_id = target_organization_id
      and user_id = auth.uid()
  );
$$;

alter table public.organizations enable row level security;
alter table public.profiles enable row level security;
alter table public.organization_members enable row level security;
alter table public.permits enable row level security;
alter table public.permit_workers enable row level security;
alter table public.permit_watchers enable row level security;
alter table public.rounds enable row level security;
alter table public.audit_logs enable row level security;

create policy "members can read organizations"
  on public.organizations for select
  using (public.is_organization_member(id));

create policy "users can read their profile"
  on public.profiles for select
  using (id = auth.uid());

create policy "members can read organization membership"
  on public.organization_members for select
  using (user_id = auth.uid() or public.is_organization_member(organization_id));

create policy "members can read permits"
  on public.permits for select
  using (public.is_organization_member(organization_id));

create policy "technical members can create permits"
  on public.permits for insert
  with check (public.is_organization_member(organization_id));

create policy "technical members can update permits"
  on public.permits for update
  using (public.is_organization_member(organization_id))
  with check (public.is_organization_member(organization_id));

create policy "members can read permit workers"
  on public.permit_workers for select
  using (exists (select 1 from public.permits p where p.id = permit_id and public.is_organization_member(p.organization_id)));

create policy "members can read permit watchers"
  on public.permit_watchers for select
  using (exists (select 1 from public.permits p where p.id = permit_id and public.is_organization_member(p.organization_id)));

create policy "members can read rounds"
  on public.rounds for select
  using (exists (select 1 from public.permits p where p.id = permit_id and public.is_organization_member(p.organization_id)));

create policy "watchers can create rounds"
  on public.rounds for insert
  with check (watcher_user_id = auth.uid());

create policy "members can read audit logs"
  on public.audit_logs for select
  using (public.is_organization_member(organization_id));

create policy "members can create audit logs"
  on public.audit_logs for insert
  with check (public.is_organization_member(organization_id));
