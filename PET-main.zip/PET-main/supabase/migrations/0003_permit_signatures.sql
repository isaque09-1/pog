alter table public.permits
  add column if not exists signature_resp text,
  add column if not exists signature_vigia text;