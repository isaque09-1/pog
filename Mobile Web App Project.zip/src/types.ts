import type { Employee } from "./data/employees";
import type { NRCode, NRDefinition, CheckAnswer } from "./data/nrData";

export type { CheckAnswer };

export interface Ronda {
  id: string;
  time: string;
  vigia: string;
  note: string;
  ok: boolean;
}

export interface PETRecord {
  id: string;
  numero: string;
  nr: NRCode;
  setor: string;
  local: string;
  tipo: string;
  responsavel: string;
  responsavelId: string;
  vigias: Employee[];
  workers: Employee[];
  fields: Record<string, string>;
  checkAnswers: Record<string, CheckAnswer>;
  abertura: string;
  status: "aberta" | "encerrada";
  nrDef: NRDefinition;
  rondas: Ronda[];
  signatureResp?: string;
  signatureVigia?: string;
}
