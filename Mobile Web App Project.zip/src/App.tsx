import { useState } from "react";
import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import type { PETRecord, Ronda } from "./types";
import Login from "./screens/Login";
import NovaPET from "./screens/NovaPET";
import VigiaView from "./screens/VigiaView";
import { EMPLOYEES, Employee } from "./data/employees";
import { NR_COLORS, NRCode } from "./data/nrData";

/* ─── Shared Types (re-exported for convenience) ────────── */
export type { Ronda, PETRecord } from "./types";

type Screen = "login" | "dashboard" | "nova-pet" | "vigia";
type Period = "dia" | "semanal" | "mensal" | "semestral" | "anual";
type UserRole = "tecnico" | "vigia";

/* ─── Seed PETs ─────────────────────────────────────────── */
import { NR_DATA } from "./data/nrData";

function makeSeedPET(id: string, num: string, nrCode: NRCode, setor: string, local: string, workerId: string, vigiaId: string, respId: string): PETRecord {
  const nr = NR_DATA.find(n => n.code === nrCode)!;
  return {
    id,
    numero: num,
    nr: nrCode,
    setor,
    local,
    tipo: nr.name,
    responsavel: EMPLOYEES.find(e => e.id === respId)?.name ?? "",
    responsavelId: respId,
    vigias: [EMPLOYEES.find(e => e.id === vigiaId)!],
    workers: [EMPLOYEES.find(e => e.id === workerId)!],
    fields: { setor },
    checkAnswers: {},
    abertura: "05/09 08:14",
    status: "aberta",
    nrDef: nr,
    rondas: [],
  };
}

const INITIAL_PETS: PETRecord[] = [
  makeSeedPET("p1", "452610", "NR-33", "Operacional", "Tanque T-07", "e1", "e13", "e2"),
  makeSeedPET("p2", "452611", "NR-35", "Manutenção", "Torre de Resfriamento", "e8", "e14", "e7"),
  makeSeedPET("p3", "452612", "NR-11", "Produção", "Galpão Central", "e3", "e15", "e2"),
  makeSeedPET("p4", "452613", "NR-20", "Controle de Qualidade", "Sala de GLP", "e4", "e13", "e7"),
  makeSeedPET("p5", "452614", "NR-35", "Operacional", "Silo S-03", "e5", "e14", "e2"),
];

/* ─── Period Data ───────────────────────────────────────── */
const MULT: Record<Period, number> = { dia: 1, semanal: 5, mensal: 22, semestral: 130, anual: 260 };

const LOCAL_COLORS = [
  "#00d4aa", "#f59e0b", "#3b82f6", "#a855f7", "#ef4444", "#22c55e", "#ec4899", "#06b6d4",
];

function getPeriodData(pets: PETRecord[], period: Period) {
  const m = MULT[period];
  const nrCount: Record<NRCode, number> = { "NR-11": 0, "NR-20": 0, "NR-33": 0, "NR-34": 0, "NR-35": 0 };
  pets.forEach(p => { nrCount[p.nr] = (nrCount[p.nr] ?? 0) + 1; });
  const nrData = Object.entries(nrCount).map(([name, val]) => ({
    name,
    value: Math.max(1, Math.round(val * m)),
  }));
  const localMap: Record<string, number> = {};
  pets.forEach(p => { localMap[p.local] = (localMap[p.local] ?? 0) + 1; });
  const localData = Object.entries(localMap)
    .sort((a, b) => b[1] - a[1])
    .map(([name, val], i) => ({
      name,
      value: Math.max(1, Math.round(val * m)),
      color: LOCAL_COLORS[i % LOCAL_COLORS.length],
    }));
  const setorMap: Record<string, number> = {};
  pets.forEach(p => { setorMap[p.setor] = (setorMap[p.setor] ?? 0) + 1; });
  const setorData = [
    { setor: "Operacional", total: Math.round((setorMap["Operacional"] ?? 0) * m + 2 * m) },
    { setor: "Produção", total: Math.round((setorMap["Produção"] ?? 0) * m + 1 * m) },
    { setor: "Manutenção", total: Math.round((setorMap["Manutenção"] ?? 0) * m + 1 * m) },
    { setor: "C. Qualidade", total: Math.round((setorMap["Controle de Qualidade"] ?? 0) * m) || m },
    { setor: "Adm.", total: Math.round((setorMap["Administrativo"] ?? 0) * m) || m },
  ];
  return { nrData, localData, setorData };
}

/* ─── Tooltip Components ─────────────────────────────────── */
function PieTip({ active, payload }: { active?: boolean; payload?: { name: string; value: number }[] }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg px-3 py-2 text-xs" style={{ background: "#1e2330", border: "1px solid #232a3a", color: "#f0f2f5" }}>
      <div className="font-bold">{payload[0].name}</div>
      <div style={{ color: "#00d4aa" }}>{payload[0].value} PETs</div>
    </div>
  );
}

function BarTip({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg px-3 py-2 text-xs" style={{ background: "#1e2330", border: "1px solid #232a3a", color: "#f0f2f5" }}>
      <div className="font-bold">{label}</div>
      <div style={{ color: "#00d4aa" }}>{payload[0].value} PETs</div>
    </div>
  );
}

/* ─── Icons ─────────────────────────────────────────────── */
function IconShield() {
  return (
    <svg width="16" height="16" viewBox="0 0 20 20" fill="none">
      <path d="M10 2L3 5.5v5c0 4 3.1 7.4 7 8 3.9-.6 7-4 7-8v-5L10 2z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M7 10l2 2 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function IconPlus() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M8 3v10M3 8h10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function IconLogout() {
  return (
    <svg width="16" height="16" viewBox="0 0 18 18" fill="none">
      <path d="M7 3H4a1 1 0 00-1 1v10a1 1 0 001 1h3M12 13l4-4-4-4M16 9H7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function IconX() {
  return (
    <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
      <path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" />
    </svg>
  );
}

function IconEye() {
  return (
    <svg width="14" height="14" viewBox="0 0 22 22" fill="none">
      <path d="M1 11S4.5 5 11 5s10 6 10 6-3.5 6-10 6S1 11 1 11z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
      <circle cx="11" cy="11" r="2.5" stroke="currentColor" strokeWidth="1.8" />
    </svg>
  );
}

/* ─── Dashboard ─────────────────────────────────────────── */
function Dashboard({
  pets,
  userName,
  userRole,
  onNovaPET,
  onLogout,
  onVigia,
  onClosePet,
}: {
  pets: PETRecord[];
  userName: string;
  userRole: UserRole;
  onNovaPET: () => void;
  onLogout: () => void;
  onVigia: (pet: PETRecord) => void;
  onClosePet: (id: string) => void;
}) {
  const [period, setPeriod] = useState<Period>("dia");
  const [closing, setClosing] = useState<string | null>(null);
  const [pieDim, setPieDim] = useState<"nr" | "local">("nr");
  const [activeTab, setActiveTab] = useState<"abertas" | "historico">("abertas");

  const openPets = pets.filter(p => p.status === "aberta");
  const closedPets = pets.filter(p => p.status === "encerrada");
  const { nrData, localData, setorData } = getPeriodData(pets, period);
  const pieData = pieDim === "nr" ? nrData : localData;
  const totalPie = pieData.reduce((a, b) => a + b.value, 0);

  const PERIODS: { key: Period; label: string }[] = [
    { key: "dia", label: "Dia" },
    { key: "semanal", label: "Semanal" },
    { key: "mensal", label: "Mensal" },
    { key: "semestral", label: "Semestral" },
    { key: "anual", label: "Anual" },
  ];

  function handleClose(id: string) {
    setClosing(id);
    setTimeout(() => { onClosePet(id); setClosing(null); }, 900);
  }

  return (
    <div className="flex flex-col min-h-full pb-10" style={{ background: "#0f1117" }}>
      {/* top bar */}
      <div className="flex items-center justify-between px-5 pt-12 pb-4">
        <div>
          <div className="flex items-center gap-2 mb-0.5">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "#00d4aa", color: "#0f1117" }}>
              <IconShield />
            </div>
            <span className="font-bold text-base" style={{ color: "#f0f2f5" }}>PET Manager</span>
          </div>
          <div className="text-[10px] pl-9" style={{ color: "#6b7590", fontFamily: "'JetBrains Mono',monospace" }}>
            {userName.split(" ")[0]} · {userRole === "tecnico" ? "Técnico" : "Vigia"}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {userRole === "tecnico" && (
            <button
              onClick={onNovaPET}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-bold"
              style={{ background: "#00d4aa", color: "#0f1117" }}
            >
              <IconPlus />
              Nova PET
            </button>
          )}
          <button
            onClick={onLogout}
            className="flex items-center gap-1 px-3 py-2.5 rounded-xl text-xs"
            style={{ background: "#181c25", border: "1px solid #232a3a", color: "#6b7590" }}
          >
            <IconLogout />
          </button>
        </div>
      </div>

      {/* stats */}
      <div className="px-5 mb-5">
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "PETs Abertas", value: openPets.length, color: "#00d4aa" },
            { label: "PETs Hoje", value: pets.length, color: "#f59e0b" },
            { label: "Encerradas", value: pets.filter(p => p.status === "encerrada").length, color: "#6b7590" },
          ].map(s => (
            <div key={s.label} className="rounded-xl p-3.5" style={{ background: "#181c25", border: "1px solid #232a3a" }}>
              <div className="text-2xl font-bold leading-none mb-1" style={{ color: s.color }}>{s.value}</div>
              <div className="text-[10px] leading-tight" style={{ color: "#6b7590" }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* period filter */}
      <div className="px-5 mb-5">
        <div className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "#6b7590", fontFamily: "'JetBrains Mono',monospace" }}>
          Período Amostrado
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
          {PERIODS.map(p => (
            <button
              key={p.key}
              onClick={() => setPeriod(p.key)}
              className="flex-shrink-0 px-4 py-2 rounded-lg text-xs font-semibold transition-all"
              style={{
                background: period === p.key ? "#00d4aa" : "#181c25",
                color: period === p.key ? "#0f1117" : "#6b7590",
                border: `1px solid ${period === p.key ? "#00d4aa" : "#232a3a"}`,
              }}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* pie chart */}
      <div className="px-5 mb-5">
        <div className="rounded-2xl p-4" style={{ background: "#181c25", border: "1px solid #232a3a" }}>
          {/* header + dim toggle */}
          <div className="flex items-start justify-between mb-4">
            <div>
              <div className="text-sm font-bold" style={{ color: "#f0f2f5" }}>
                {pieDim === "nr" ? "PETs por Norma Regulamentadora" : "PETs por Local do Serviço"}
              </div>
              <div className="text-[10px]" style={{ color: "#6b7590" }}>Total: {totalPie} PETs</div>
            </div>
            <div className="flex rounded-lg overflow-hidden flex-shrink-0" style={{ border: "1px solid #232a3a" }}>
              {([["nr", "Por NR"], ["local", "Locais"]] as const).map(([key, label]) => (
                <button
                  key={key}
                  onClick={() => setPieDim(key)}
                  className="px-3 py-1.5 text-[10px] font-semibold transition-all"
                  style={{
                    background: pieDim === key ? "#00d4aa" : "#0f1117",
                    color: pieDim === key ? "#0f1117" : "#6b7590",
                  }}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div style={{ width: 140, height: 140, flexShrink: 0 }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={38} outerRadius={62} paddingAngle={2} dataKey="value" strokeWidth={0}>
                    {pieData.map((entry, i) => (
                      <Cell
                        key={entry.name}
                        fill={pieDim === "nr" ? NR_COLORS[entry.name as NRCode] : LOCAL_COLORS[i % LOCAL_COLORS.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<PieTip />} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-col gap-2 flex-1 min-w-0">
              {pieData.map((entry, i) => {
                const col = pieDim === "nr" ? NR_COLORS[entry.name as NRCode] : LOCAL_COLORS[i % LOCAL_COLORS.length];
                return (
                  <div key={entry.name} className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: col }} />
                    <div className="flex-1 min-w-0">
                      <div className="text-[11px] font-bold leading-none truncate" style={{ color: "#f0f2f5" }}>{entry.name}</div>
                    </div>
                    <div className="text-xs font-bold flex-shrink-0" style={{ color: col }}>{entry.value}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* bar chart */}
      <div className="px-5 mb-5">
        <div className="rounded-2xl p-4" style={{ background: "#181c25", border: "1px solid #232a3a" }}>
          <div className="mb-3">
            <div className="text-sm font-bold" style={{ color: "#f0f2f5" }}>PETs por Setor</div>
            <div className="text-[10px]" style={{ color: "#6b7590" }}>Distribuição por área</div>
          </div>
          <div style={{ height: 170 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={setorData} barSize={20} margin={{ top: 0, right: 6, left: -18, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke="#232a3a" strokeDasharray="3 0" />
                <XAxis dataKey="setor" tick={{ fill: "#6b7590", fontSize: 9, fontFamily: "DM Sans" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#6b7590", fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip content={<BarTip />} cursor={{ fill: "#ffffff08" }} />
                <Bar dataKey="total" fill="#00d4aa" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* tabs */}
      <div className="px-5 mb-4">
        <div className="flex rounded-xl overflow-hidden" style={{ background: "#181c25", border: "1px solid #232a3a" }}>
          {[
            { key: "abertas" as const, label: "Abertas", count: openPets.length },
            { key: "historico" as const, label: "Histórico", count: closedPets.length },
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold transition-all"
              style={{
                background: activeTab === tab.key ? "#00d4aa" : "transparent",
                color: activeTab === tab.key ? "#0f1117" : "#6b7590",
              }}
            >
              {tab.label}
              <span
                className="px-1.5 py-0.5 rounded-full text-[10px] font-bold"
                style={{
                  background: activeTab === tab.key ? "#0f111730" : "#232a3a",
                  color: activeTab === tab.key ? "#0f1117" : "#a8b0c0",
                }}
              >
                {tab.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* open PETs list */}
      {activeTab === "abertas" && (
      <div className="px-5">
        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="text-sm font-bold" style={{ color: "#f0f2f5" }}>PETs Abertas Agora</div>
            <div className="text-[10px]" style={{ color: "#6b7590" }}>{openPets.length} ativa(s)</div>
          </div>
          <div className="px-2.5 py-1 rounded-full text-[10px] font-bold" style={{ background: openPets.length > 0 ? "#ef444420" : "#00d4aa20", color: openPets.length > 0 ? "#ef4444" : "#00d4aa" }}>
            {openPets.length > 0 ? "● ATIVO" : "● LIMPO"}
          </div>
        </div>

        {openPets.length === 0 && (
          <div className="rounded-2xl p-8 text-center" style={{ background: "#181c25", border: "1px solid #232a3a" }}>
            <div className="text-3xl mb-2">✓</div>
            <div className="text-sm font-semibold" style={{ color: "#f0f2f5" }}>Nenhuma PET aberta</div>
          </div>
        )}

        <div className="flex flex-col gap-3">
          {openPets.map(pet => {
            const col = NR_COLORS[pet.nr];
            return (
              <div
                key={pet.id}
                className="rounded-2xl overflow-hidden transition-all"
                style={{
                  background: closing === pet.id ? "#0f1117" : "#181c25",
                  border: `1px solid ${col}40`,
                  opacity: closing === pet.id ? 0.5 : 1,
                }}
              >
                <div className="h-[3px]" style={{ background: col }} />
                <div className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: `${col}25`, color: col }}>{pet.nr}</span>
                        <span className="text-[10px]" style={{ color: "#6b7590", fontFamily: "'JetBrains Mono',monospace" }}>Nº {pet.numero}</span>
                      </div>
                      <div className="text-sm font-bold" style={{ color: "#f0f2f5" }}>{pet.tipo}</div>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {/* vigia button */}
                      <button
                        onClick={() => onVigia(pet)}
                        className="flex items-center gap-1 px-2.5 py-2 rounded-lg text-[11px] font-semibold"
                        style={{ background: "#1e2330", color: "#a8b0c0", border: "1px solid #232a3a" }}
                      >
                        <IconEye /> Vigia
                      </button>
                      {/* encerrar button */}
                      {userRole === "tecnico" && (
                        <button
                          onClick={() => handleClose(pet.id)}
                          disabled={closing === pet.id}
                          className="flex items-center gap-1 px-2.5 py-2 rounded-lg text-[11px] font-semibold"
                          style={{ background: "#ef444415", color: "#ef4444", border: "1px solid #ef444430" }}
                        >
                          {closing === pet.id ? (
                            <span className="w-3 h-3 border border-[#ef4444] border-t-transparent rounded-full animate-spin inline-block" />
                          ) : <IconX />}
                          Encerrar
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
                    {[
                      { label: "Local", value: pet.local },
                      { label: "Setor", value: pet.setor },
                      { label: "Responsável", value: pet.responsavel.split(" ")[0] || "—" },
                      { label: "Abertura", value: pet.abertura },
                    ].map(r => (
                      <div key={r.label}>
                        <div className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: "#3a4255" }}>{r.label}</div>
                        <div className="text-[11px] font-medium" style={{ color: "#a8b0c0" }}>{r.value}</div>
                      </div>
                    ))}
                  </div>

                  {/* workers preview */}
                  {pet.workers.length > 0 && (
                    <div className="flex items-center gap-1.5 mt-3 pt-3" style={{ borderTop: "1px solid #232a3a" }}>
                      <div className="flex -space-x-2">
                        {pet.workers.slice(0, 3).map(w => (
                          <div
                            key={w.id}
                            className="w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-bold ring-2"
                            style={{ background: `${col}30`, color: col, outline: "2px solid #181c25" }}
                          >
                            {w.name[0]}
                          </div>
                        ))}
                      </div>
                      <span className="text-[10px]" style={{ color: "#6b7590" }}>
                        {pet.workers.length} trabalhador(es) · {pet.vigias.length} vigia(s)
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      )}

      {/* history */}
      {activeTab === "historico" && (
      <div className="px-5">
        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="text-sm font-bold" style={{ color: "#f0f2f5" }}>PETs Encerradas</div>
            <div className="text-[10px]" style={{ color: "#6b7590" }}>{closedPets.length} registro(s)</div>
          </div>
          <div className="px-2.5 py-1 rounded-full text-[10px] font-bold" style={{ background: "#6b759020", color: "#6b7590" }}>
            ● HISTÓRICO
          </div>
        </div>

        {closedPets.length === 0 && (
          <div className="rounded-2xl p-8 text-center" style={{ background: "#181c25", border: "1px solid #232a3a" }}>
            <div className="text-3xl mb-2">📋</div>
            <div className="text-sm font-semibold" style={{ color: "#f0f2f5" }}>Nenhuma PET encerrada</div>
            <div className="text-xs mt-1" style={{ color: "#6b7590" }}>As PETs encerradas aparecerão aqui</div>
          </div>
        )}

        <div className="flex flex-col gap-3">
          {closedPets.map(pet => {
            const col = NR_COLORS[pet.nr];
            return (
              <div
                key={pet.id}
                className="rounded-2xl overflow-hidden"
                style={{ background: "#181c25", border: "1px solid #232a3a", opacity: 0.85 }}
              >
                <div className="h-[3px]" style={{ background: "#3a4255" }} />
                <div className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: "#3a425520", color: "#6b7590" }}>{pet.nr}</span>
                        <span className="text-[10px]" style={{ color: "#6b7590", fontFamily: "'JetBrains Mono',monospace" }}>Nº {pet.numero}</span>
                      </div>
                      <div className="text-sm font-bold" style={{ color: "#a8b0c0" }}>{pet.tipo}</div>
                    </div>
                    <div className="px-2.5 py-1 rounded-full text-[10px] font-bold flex-shrink-0" style={{ background: "#22c55e15", color: "#22c55e" }}>
                      ✓ Encerrada
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
                    {[
                      { label: "Local", value: pet.local },
                      { label: "Setor", value: pet.setor },
                      { label: "Responsável", value: pet.responsavel.split(" ")[0] || "—" },
                      { label: "Abertura", value: pet.abertura },
                    ].map(r => (
                      <div key={r.label}>
                        <div className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: "#3a4255" }}>{r.label}</div>
                        <div className="text-[11px] font-medium" style={{ color: "#6b7590" }}>{r.value}</div>
                      </div>
                    ))}
                  </div>

                  {pet.workers.length > 0 && (
                    <div className="flex items-center gap-1.5 mt-3 pt-3" style={{ borderTop: "1px solid #232a3a" }}>
                      <div className="flex -space-x-2">
                        {pet.workers.slice(0, 3).map(w => (
                          <div
                            key={w.id}
                            className="w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-bold"
                            style={{ background: "#3a425530", color: "#6b7590", outline: "2px solid #181c25" }}
                          >
                            {w.name[0]}
                          </div>
                        ))}
                      </div>
                      <span className="text-[10px]" style={{ color: "#3a4255" }}>
                        {pet.workers.length} trabalhador(es) · {pet.vigias.length} vigia(s)
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      )}
    </div>
  );
}

/* ─── App Root ──────────────────────────────────────────── */
export default function App() {
  const [screen, setScreen] = useState<Screen>("login");
  const [userRole, setUserRole] = useState<UserRole>("tecnico");
  const [userName, setUserName] = useState("");
  const [userEmployeeId, setUserEmployeeId] = useState("");
  const [pets, setPets] = useState<PETRecord[]>(INITIAL_PETS);
  const [activePet, setActivePet] = useState<PETRecord | null>(null);

  function handleLogin(role: UserRole, name: string, _matricula: string, employeeId: string) {
    setUserRole(role);
    setUserName(name);
    setUserEmployeeId(employeeId);
    setScreen("dashboard");
  }

  function handleEmitPet(pet: PETRecord) {
    setPets(prev => [...prev, pet]);
    setScreen("dashboard");
  }

  function handleClosePet(id: string) {
    setPets(prev => prev.map(p => p.id === id ? { ...p, status: "encerrada" } : p));
  }

  function handleOpenVigia(pet: PETRecord) {
    setActivePet(pet);
    setScreen("vigia");
  }

  function handleUpdatePet(updated: PETRecord) {
    setPets(prev => prev.map(p => p.id === updated.id ? updated : p));
    setActivePet(updated);
  }

  return (
    <div style={{ maxWidth: 430, margin: "0 auto", minHeight: "100%" }}>
      {screen === "login" && (
        <Login onLogin={handleLogin} />
      )}
      {screen === "dashboard" && (
        <Dashboard
          pets={userRole === "vigia"
            ? pets.filter(p => p.vigias.some(v => v.id === userEmployeeId))
            : pets}
          userName={userName}
          userRole={userRole}
          onNovaPET={() => setScreen("nova-pet")}
          onLogout={() => setScreen("login")}
          onVigia={handleOpenVigia}
          onClosePet={handleClosePet}
        />
      )}
      {screen === "nova-pet" && (
        <NovaPET
          onBack={() => setScreen("dashboard")}
          onEmit={handleEmitPet}
        />
      )}
      {screen === "vigia" && activePet && (
        <VigiaView
          pet={activePet}
          vigiaName={userName || activePet.vigias[0]?.name || "Vigia"}
          onUpdatePet={handleUpdatePet}
          onBack={() => setScreen("dashboard")}
        />
      )}
    </div>
  );
}
