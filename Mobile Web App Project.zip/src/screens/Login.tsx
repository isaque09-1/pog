import { useState } from "react";
import { EMPLOYEES } from "../data/employees";

export type UserRole = "tecnico" | "vigia";

interface Props {
  onLogin: (role: UserRole, name: string, matricula: string, employeeId: string) => void;
}

function detectRole(cargo: string): UserRole {
  return cargo.toLowerCase().includes("vigia") ? "vigia" : "tecnico";
}

function IconShield({ size = 26 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none">
      <path d="M10 2L3 5.5v5c0 4 3.1 7.4 7 8 3.9-.6 7-4 7-8v-5L10 2z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M7 10l2 2 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function Login({ onLogin }: Props) {
  const [matricula, setMatricula] = useState("");
  const [senha, setSenha] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const employee = EMPLOYEES.find(emp => emp.matricula === matricula.trim());
    if (!employee) {
      setError("Matrícula não encontrada. Verifique e tente novamente.");
      return;
    }
    if (!senha.trim()) {
      setError("Informe a senha.");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      const role = detectRole(employee.cargo);
      onLogin(role, employee.name, employee.matricula, employee.id);
    }, 1100);
  }

  const previewEmployee = EMPLOYEES.find(e => e.matricula === matricula.trim());

  return (
    <div className="flex flex-col min-h-full" style={{ background: "#0f1117" }}>
      <div className="flex flex-col items-center pt-14 pb-8 px-6">
        <div
          className="w-14 h-14 rounded-2xl flex items-center justify-center mb-3"
          style={{ background: "#00d4aa", color: "#0f1117" }}
        >
          <IconShield />
        </div>
        <div className="text-lg font-bold" style={{ color: "#f0f2f5" }}>PET Manager</div>
        <div
          className="text-[10px] font-medium uppercase tracking-widest mt-0.5"
          style={{ color: "#6b7590", fontFamily: "'JetBrains Mono',monospace" }}
        >
          Gestão de Permissões de Trabalho
        </div>
      </div>

      <div className="flex-1 flex flex-col px-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-1" style={{ color: "#f0f2f5" }}>Acesso ao Sistema</h1>
          <p className="text-sm" style={{ color: "#6b7590" }}>
            Seu perfil é identificado automaticamente pela matrícula.
          </p>
        </div>

        <form onSubmit={submit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "#6b7590" }}>
              Matrícula
            </label>
            <input
              value={matricula}
              onChange={e => { setMatricula(e.target.value); setError(null); }}
              placeholder="Ex: 12345"
              className="w-full rounded-xl px-4 py-3.5 text-sm outline-none transition-colors"
              style={{
                background: "#181c25",
                border: `1px solid ${error ? "#ef4444" : "#232a3a"}`,
                color: "#f0f2f5",
                fontFamily: "'JetBrains Mono',monospace",
              }}
              onFocus={e => { if (!error) e.target.style.borderColor = "#00d4aa"; }}
              onBlur={e => { if (!error) e.target.style.borderColor = "#232a3a"; }}
            />
          </div>

          {/* live employee preview */}
          {previewEmployee && (
            <div
              className="flex items-center gap-3 px-4 py-3 rounded-xl -mt-1"
              style={{ background: "#181c25", border: "1px solid #00d4aa40" }}
            >
              <div
                className="w-9 h-9 rounded-lg flex items-center justify-center text-sm font-bold flex-shrink-0"
                style={{ background: "#00d4aa20", color: "#00d4aa" }}
              >
                {previewEmployee.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold" style={{ color: "#f0f2f5" }}>{previewEmployee.name}</div>
                <div className="text-xs" style={{ color: "#6b7590" }}>{previewEmployee.cargo}</div>
              </div>
              <div
                className="text-[10px] font-bold px-2.5 py-1 rounded-full flex-shrink-0"
                style={{
                  background: detectRole(previewEmployee.cargo) === "vigia" ? "#a855f720" : "#00d4aa20",
                  color: detectRole(previewEmployee.cargo) === "vigia" ? "#a855f7" : "#00d4aa",
                }}
              >
                {detectRole(previewEmployee.cargo) === "vigia" ? "Vigia" : "Técnico"}
              </div>
            </div>
          )}

          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "#6b7590" }}>
              Senha
            </label>
            <input
              type="password"
              value={senha}
              onChange={e => { setSenha(e.target.value); setError(null); }}
              placeholder="••••••"
              className="w-full rounded-xl px-4 py-3.5 text-sm outline-none transition-colors"
              style={{
                background: "#181c25",
                border: `1px solid ${error ? "#ef4444" : "#232a3a"}`,
                color: "#f0f2f5",
              }}
              onFocus={e => { if (!error) e.target.style.borderColor = "#00d4aa"; }}
              onBlur={e => { if (!error) e.target.style.borderColor = "#232a3a"; }}
            />
          </div>

          {error && (
            <div
              className="flex items-center gap-2 px-4 py-3 rounded-xl text-xs"
              style={{ background: "#ef444415", border: "1px solid #ef444430", color: "#ef4444" }}
            >
              <span>⚠</span> {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl py-4 font-bold text-sm transition-all"
            style={{ background: loading ? "#00a87f" : "#00d4aa", color: "#0f1117" }}
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <span className="w-4 h-4 border-2 border-[#0f1117] border-t-transparent rounded-full animate-spin inline-block" />
                Identificando perfil...
              </span>
            ) : "Entrar"}
          </button>
        </form>

        {/* demo hints */}
        <div className="mt-5 p-4 rounded-xl" style={{ background: "#181c25", border: "1px solid #232a3a" }}>
          <div className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "#6b7590" }}>
            Matrículas de demonstração
          </div>
          <div className="flex flex-col gap-1.5">
            {[
              { mat: "12346", name: "Ana Lima", role: "Técnico" },
              { mat: "12357", name: "Priscila Andrade", role: "Vigia" },
              { mat: "12358", name: "Eduardo Torres", role: "Vigia" },
            ].map(u => (
              <button
                key={u.mat}
                onClick={() => { setMatricula(u.mat); setSenha("1234"); setError(null); }}
                className="flex items-center gap-3 text-left"
              >
                <span
                  className="text-[10px] font-bold"
                  style={{ color: "#00d4aa", fontFamily: "'JetBrains Mono',monospace", minWidth: 44 }}
                >
                  {u.mat}
                </span>
                <span className="text-xs flex-1" style={{ color: "#a8b0c0" }}>{u.name}</span>
                <span
                  className="text-[9px] font-bold px-2 py-0.5 rounded-full"
                  style={{ background: u.role === "Vigia" ? "#a855f720" : "#00d4aa20", color: u.role === "Vigia" ? "#a855f7" : "#00d4aa" }}
                >
                  {u.role}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="px-6 pb-8 mt-6 text-center text-[10px]" style={{ color: "#3a4255" }}>
        © 2026 · PET Manager v2.5.0 · NR-11 · NR-20 · NR-33 · NR-34 · NR-35
      </div>
    </div>
  );
}
