import { useState, useRef, useEffect } from "react";
import { NR_DATA, NRCode, CheckAnswer, NRDefinition } from "../data/nrData";
import { EMPLOYEES, VIGIAS, RESPONSAVEIS, Employee } from "../data/employees";
import type { PETRecord } from "../types";

/* ─── Step system ────────────────────────────────────────── */
type StepName = "NR" | "Dados" | "Checklist" | "Equipe" | "Vigia" | "Horário" | "Assinatura" | "Revisão";

function getStepNames(nrCode: NRCode | null): StepName[] {
  if (nrCode === "NR-33") {
    return ["NR", "Dados", "Checklist", "Equipe", "Vigia", "Horário", "Assinatura", "Revisão"];
  }
  return ["NR", "Dados", "Checklist", "Equipe", "Horário", "Assinatura", "Revisão"];
}

// Workers eligible for the PET: must have the required NR in their training
function getEligibleWorkers(nrCode: string) {
  return EMPLOYEES.filter(
    e =>
      e.treinamentos.includes(nrCode) &&
      !RESPONSAVEIS.some(r => r.id === e.id) &&
      !VIGIAS.some(v => v.id === e.id)
  );
}

interface Props {
  onBack: () => void;
  onEmit: (pet: PETRecord) => void;
}

/* ─── Icons ─────────────────────────────────────────────── */
function ArrowLeft() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
      <path d="M11 4L6 9l5 5" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Check() {
  return (
    <svg width="11" height="11" viewBox="0 0 11 11" fill="none">
      <path d="M2 5.5l2.5 2.5 4.5-4.5" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ChevronRight() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M5 3l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ─── Step Progress ─────────────────────────────────────── */
function StepBar({ step, stepNames }: { step: number; stepNames: StepName[] }) {
  const show = stepNames.length <= 7 ? stepNames : stepNames;
  const abbreviated = show.map(s => s.slice(0, 4));
  return (
    <div className="px-5 py-3">
      <div className="flex items-center">
        {abbreviated.map((label, i) => (
          <div key={i} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center gap-0.5">
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-bold transition-all"
                style={{
                  background: i < step ? "#00d4aa" : i === step ? "#00d4aa" : "#1e2330",
                  color: i <= step ? "#0f1117" : "#6b7590",
                }}
              >
                {i < step ? <Check /> : i + 1}
              </div>
              <span
                className="text-[8px] font-semibold"
                style={{ color: i === step ? "#00d4aa" : i < step ? "#a8b0c0" : "#3a4255" }}
              >
                {label}
              </span>
            </div>
            {i < abbreviated.length - 1 && (
              <div
                className="flex-1 h-[1px] mb-3 mx-0.5"
                style={{ background: i < step ? "#00d4aa" : "#232a3a" }}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Step: Select NR ────────────────────────────────────── */
function StepNR({ selected, onSelect }: { selected: NRCode | null; onSelect: (c: NRCode) => void }) {
  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-3">
      <div className="mb-1">
        <h2 className="text-xl font-bold" style={{ color: "#f0f2f5" }}>Tipo de Trabalho</h2>
        <p className="text-sm" style={{ color: "#6b7590" }}>Selecione a norma regulamentadora</p>
      </div>
      {NR_DATA.map(nr => (
        <button
          key={nr.code}
          onClick={() => onSelect(nr.code)}
          className="flex items-center gap-4 p-4 rounded-2xl border text-left transition-all"
          style={{
            background: selected === nr.code ? `${nr.color}12` : "#181c25",
            borderColor: selected === nr.code ? nr.color : "#232a3a",
          }}
        >
          <div
            className="w-11 h-11 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
            style={{ background: `${nr.color}20`, color: nr.color }}
          >
            {nr.icon}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: `${nr.color}25`, color: nr.color }}>
                {nr.code}
              </span>
              {nr.code === "NR-33" && (
                <span className="text-[9px] px-1.5 py-0.5 rounded-full font-medium" style={{ background: "#a855f720", color: "#a855f7" }}>
                  Requer Vigia
                </span>
              )}
            </div>
            <div className="text-sm font-bold mt-0.5" style={{ color: "#f0f2f5" }}>{nr.name}</div>
            <div className="text-xs" style={{ color: "#6b7590" }}>{nr.subtitle}</div>
          </div>
          <div style={{ color: selected === nr.code ? nr.color : "#3a4255" }}>
            <ChevronRight />
          </div>
        </button>
      ))}
    </div>
  );
}

/* ─── Step: NR Fields ────────────────────────────────────── */
function StepFields({
  nr,
  values,
  onChange,
}: {
  nr: NRDefinition;
  values: Record<string, string>;
  onChange: (id: string, val: string) => void;
}) {
  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-4">
      <div className="mb-1">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: `${nr.color}25`, color: nr.color }}>
            {nr.code}
          </span>
        </div>
        <h2 className="text-xl font-bold" style={{ color: "#f0f2f5" }}>Dados do Trabalho</h2>
        <p className="text-sm" style={{ color: "#6b7590" }}>Preencha as informações específicas</p>
      </div>

      {/* Setor */}
      <div className="flex flex-col gap-1.5">
        <label className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "#6b7590" }}>
          Setor / Área <span style={{ color: "#ef4444" }}>*</span>
        </label>
        <select
          value={values["setor"] ?? ""}
          onChange={e => onChange("setor", e.target.value)}
          className="w-full rounded-xl px-4 py-3.5 text-sm outline-none"
          style={{ background: "#181c25", border: "1px solid #232a3a", color: values["setor"] ? "#f0f2f5" : "#6b7590" }}
        >
          <option value="" disabled>Selecione o setor...</option>
          {["Operacional", "Produção", "Manutenção", "Controle de Qualidade", "Administrativo", "Logística"].map(s => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </div>

      {nr.fields.map(field => (
        <div key={field.id} className="flex flex-col gap-1.5">
          <label className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "#6b7590" }}>
            {field.label}
            {field.unit && <span style={{ color: "#3a4255" }}> ({field.unit})</span>}
            {field.required && <span style={{ color: "#ef4444" }}> *</span>}
          </label>
          {field.type === "select" ? (
            <select
              value={values[field.id] ?? ""}
              onChange={e => onChange(field.id, e.target.value)}
              className="w-full rounded-xl px-4 py-3.5 text-sm outline-none"
              style={{ background: "#181c25", border: "1px solid #232a3a", color: values[field.id] ? "#f0f2f5" : "#6b7590" }}
            >
              <option value="" disabled>Selecione...</option>
              {field.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
          ) : field.type === "number" ? (
            <div className="relative">
              <input
                type="number"
                min="0"
                step="0.01"
                value={values[field.id] ?? ""}
                onChange={e => {
                  const v = parseFloat(e.target.value);
                  if (e.target.value === "" || v >= 0) onChange(field.id, e.target.value);
                }}
                onBlur={e => {
                  const v = parseFloat(e.target.value);
                  if (!isNaN(v) && v < 0) onChange(field.id, "0");
                }}
                placeholder="0"
                className="w-full rounded-xl px-4 py-3.5 text-sm outline-none"
                style={{ background: "#181c25", border: "1px solid #232a3a", color: "#f0f2f5" }}
              />
              {field.unit && (
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs" style={{ color: "#6b7590", fontFamily: "'JetBrains Mono',monospace" }}>
                  {field.unit}
                </span>
              )}
            </div>
          ) : (
            <input
              type="text"
              value={values[field.id] ?? ""}
              onChange={e => onChange(field.id, e.target.value)}
              placeholder={`Informe ${field.label.toLowerCase()}...`}
              className="w-full rounded-xl px-4 py-3.5 text-sm outline-none"
              style={{ background: "#181c25", border: "1px solid #232a3a", color: "#f0f2f5" }}
            />
          )}
        </div>
      ))}

      {/* EPI list */}
      <div className="p-4 rounded-xl mt-2" style={{ background: "#181c25", border: "1px solid #232a3a" }}>
        <div className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "#6b7590" }}>
          EPIs Obrigatórios — {nr.code}
        </div>
        <div className="flex flex-col gap-1.5">
          {nr.epiList.map((epi, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: nr.color }} />
              <span className="text-xs" style={{ color: "#a8b0c0" }}>{epi}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── Step: Checklist ────────────────────────────────────── */
function StepChecklist({
  nr,
  answers,
  onChange,
}: {
  nr: NRDefinition;
  answers: Record<string, CheckAnswer>;
  onChange: (id: string, ans: CheckAnswer) => void;
}) {
  const answered = Object.keys(answers).length;
  const total = nr.checklist.length;
  const naoCount = Object.values(answers).filter(a => a === "NÃO").length;
  const pct = Math.round((answered / total) * 100);

  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-3">
      <div className="mb-1">
        <h2 className="text-xl font-bold" style={{ color: "#f0f2f5" }}>Checklist {nr.code}</h2>
        <p className="text-sm" style={{ color: "#6b7590" }}>
          {answered}/{total} respondidos · {pct}%
          {naoCount > 0 && <span style={{ color: "#ef4444" }}> · {naoCount} NÃO conforme</span>}
        </p>
      </div>

      <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: "#232a3a" }}>
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${pct}%`, background: naoCount > 0 ? "#ef4444" : "#00d4aa" }}
        />
      </div>

      <div className="flex flex-col gap-2 mt-1">
        {nr.checklist.map((item, idx) => {
          const ans = answers[item.id];
          return (
            <div
              key={item.id}
              className="rounded-xl p-3.5"
              style={{
                background: "#181c25",
                border: `1px solid ${ans === "NÃO" ? "#ef444440" : "#232a3a"}`,
              }}
            >
              <div className="text-xs mb-2.5 leading-relaxed" style={{ color: "#a8b0c0" }}>
                <span className="font-bold mr-1" style={{ color: "#3a4255", fontFamily: "'JetBrains Mono',monospace" }}>
                  {String(idx + 1).padStart(2, "0")}
                </span>
                {item.label}
              </div>
              <div className="flex gap-2">
                {(["SIM", "NÃO", "NA"] as CheckAnswer[]).map(opt => (
                  <button
                    key={opt}
                    onClick={() => onChange(item.id, opt)}
                    className="flex-1 py-1.5 rounded-lg text-xs font-bold transition-all"
                    style={{
                      background: ans === opt ? (opt === "SIM" ? "#00d4aa" : opt === "NÃO" ? "#ef4444" : "#6b7590") : "#0f1117",
                      color: ans === opt ? (opt === "NA" ? "#f0f2f5" : "#0f1117") : "#6b7590",
                      border: `1px solid ${ans === opt ? (opt === "SIM" ? "#00d4aa" : opt === "NÃO" ? "#ef4444" : "#6b7590") : "#232a3a"}`,
                    }}
                  >
                    {opt}
                  </button>
                ))}
              </div>
              {ans === "NÃO" && (
                <div className="mt-2 flex items-center gap-1.5 text-[10px]" style={{ color: "#ef4444" }}>
                  <span>⚠</span> Item não conforme — medida corretiva obrigatória
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Step: Equipe ───────────────────────────────────────── */
function StepEquipe({
  nr,
  selectedWorkers,
  responsavel,
  onToggleWorker,
  onSelectResponsavel,
}: {
  nr: NRDefinition;
  selectedWorkers: Set<string>;
  responsavel: string | null;
  onToggleWorker: (id: string) => void;
  onSelectResponsavel: (id: string) => void;
}) {
  const [search, setSearch] = useState("");
  const eligible = getEligibleWorkers(nr.code);
  const filtered = eligible.filter(
    e =>
      e.name.toLowerCase().includes(search.toLowerCase()) ||
      e.matricula.includes(search) ||
      e.cargo.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-4">
      <div>
        <h2 className="text-xl font-bold" style={{ color: "#f0f2f5" }}>Equipe de Trabalho</h2>
        <p className="text-sm" style={{ color: "#6b7590" }}>Apenas funcionários habilitados em {nr.code}</p>
      </div>

      {/* responsável */}
      <div>
        <div className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "#6b7590" }}>
          Responsável Técnico <span style={{ color: "#ef4444" }}>*</span>
        </div>
        <div className="flex flex-col gap-2">
          {RESPONSAVEIS.map(r => (
            <button
              key={r.id}
              onClick={() => onSelectResponsavel(r.id)}
              className="flex items-center gap-3 p-3 rounded-xl border text-left transition-all"
              style={{
                background: responsavel === r.id ? "#00d4aa12" : "#181c25",
                borderColor: responsavel === r.id ? "#00d4aa" : "#232a3a",
              }}
            >
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold flex-shrink-0"
                style={{ background: responsavel === r.id ? "#00d4aa30" : "#1e2330", color: responsavel === r.id ? "#00d4aa" : "#6b7590" }}
              >
                {r.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold" style={{ color: "#f0f2f5" }}>{r.name}</div>
                <div className="text-xs" style={{ color: "#6b7590" }}>{r.cargo}</div>
              </div>
              {responsavel === r.id && (
                <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: "#00d4aa", color: "#0f1117" }}>
                  <Check />
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* workers */}
      <div>
        <div className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "#6b7590" }}>
          Trabalhadores ({selectedWorkers.size} selecionados)
        </div>

        {eligible.length === 0 ? (
          <div className="p-4 rounded-xl text-center" style={{ background: "#ef444415", border: "1px solid #ef444430" }}>
            <div className="text-sm font-semibold mb-1" style={{ color: "#ef4444" }}>Nenhum funcionário habilitado</div>
            <div className="text-xs" style={{ color: "#ef444490" }}>
              Nenhum funcionário com {nr.code} cadastrado pode ser adicionado.
            </div>
          </div>
        ) : (
          <>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar por nome ou matrícula..."
              className="w-full rounded-xl px-4 py-3 text-sm outline-none mb-3"
              style={{ background: "#181c25", border: "1px solid #232a3a", color: "#f0f2f5" }}
            />
            <div className="flex flex-col gap-2">
              {filtered.map(emp => {
                const isSelected = selectedWorkers.has(emp.id);
                return (
                  <button
                    key={emp.id}
                    onClick={() => onToggleWorker(emp.id)}
                    className="flex items-center gap-3 p-3 rounded-xl border text-left transition-all"
                    style={{
                      background: isSelected ? `${nr.color}10` : "#181c25",
                      borderColor: isSelected ? nr.color : "#232a3a",
                    }}
                  >
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold flex-shrink-0"
                      style={{ background: isSelected ? `${nr.color}30` : "#1e2330", color: isSelected ? nr.color : "#6b7590" }}
                    >
                      {emp.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold" style={{ color: "#f0f2f5" }}>{emp.name}</div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs" style={{ color: "#6b7590" }}>{emp.cargo}</span>
                        <span className="text-[9px] px-1.5 py-0.5 rounded-full font-medium" style={{ background: `${nr.color}20`, color: nr.color }}>
                          {nr.code} ✓
                        </span>
                      </div>
                    </div>
                    <div
                      className="w-5 h-5 rounded-md border flex items-center justify-center transition-all flex-shrink-0"
                      style={{ borderColor: isSelected ? nr.color : "#3a4255", background: isSelected ? nr.color : "transparent" }}
                    >
                      {isSelected && <Check />}
                    </div>
                  </button>
                );
              })}
              {filtered.length === 0 && search && (
                <div className="text-sm text-center py-4" style={{ color: "#3a4255" }}>Nenhum resultado para "{search}"</div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

/* ─── Step: Vigia (NR-33 only) ───────────────────────────── */
function StepVigia({
  nr,
  selectedVigias,
  onToggle,
}: {
  nr: NRDefinition;
  selectedVigias: Set<string>;
  onToggle: (id: string) => void;
}) {
  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-4">
      <div>
        <h2 className="text-xl font-bold" style={{ color: "#f0f2f5" }}>Vigia(s) de Segurança</h2>
        <p className="text-sm" style={{ color: "#6b7590" }}>Obrigatório para NR-33 — Espaço Confinado</p>
      </div>

      <div className="p-3.5 rounded-xl flex items-start gap-3" style={{ background: "#181c25", border: "1px solid #f59e0b30" }}>
        <span style={{ color: "#f59e0b" }}>⚠</span>
        <p className="text-xs leading-relaxed" style={{ color: "#a8b0c0" }}>
          O vigia deve permanecer no local durante toda a execução, manter comunicação constante com a equipe e registrar rondas a cada 30 minutos.
        </p>
      </div>

      <div className="flex flex-col gap-2">
        {VIGIAS.map(vigia => {
          const isSelected = selectedVigias.has(vigia.id);
          const hasTrein = vigia.treinamentos.includes(nr.code);
          return (
            <button
              key={vigia.id}
              onClick={() => onToggle(vigia.id)}
              className="flex items-center gap-3 p-4 rounded-xl border text-left transition-all"
              style={{
                background: isSelected ? "#00d4aa10" : "#181c25",
                borderColor: isSelected ? "#00d4aa" : "#232a3a",
              }}
            >
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold flex-shrink-0"
                style={{ background: isSelected ? "#00d4aa25" : "#1e2330", color: isSelected ? "#00d4aa" : "#6b7590" }}
              >
                {vigia.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold" style={{ color: "#f0f2f5" }}>{vigia.name}</div>
                <div className="text-xs" style={{ color: "#6b7590" }}>{vigia.cargo}</div>
                <div className="flex items-center gap-1.5 mt-1">
                  <span
                    className="text-[9px] px-1.5 py-0.5 rounded-full font-medium"
                    style={{ background: hasTrein ? "#00d4aa20" : "#ef444420", color: hasTrein ? "#00d4aa" : "#ef4444" }}
                  >
                    {nr.code} {hasTrein ? "✓" : "✗"}
                  </span>
                  <span className="text-[10px]" style={{ color: "#3a4255", fontFamily: "'JetBrains Mono',monospace" }}>
                    {vigia.matricula}
                  </span>
                </div>
              </div>
              <div
                className="w-5 h-5 rounded-full border flex items-center justify-center transition-all"
                style={{ borderColor: isSelected ? "#00d4aa" : "#3a4255", background: isSelected ? "#00d4aa" : "transparent" }}
              >
                {isSelected && <Check />}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Step: Schedule ─────────────────────────────────────── */
function StepSchedule({
  date, time,
  onChange,
}: {
  date: string; time: string;
  onChange: (k: "date" | "time", v: string) => void;
}) {
  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-4">
      <div>
        <h2 className="text-xl font-bold" style={{ color: "#f0f2f5" }}>Agendamento</h2>
        <p className="text-sm" style={{ color: "#6b7590" }}>Data e hora de abertura da PET</p>
      </div>
      {[
        { key: "date" as const, label: "Data de Abertura", type: "date", val: date },
        { key: "time" as const, label: "Hora de Início", type: "time", val: time },
      ].map(f => (
        <div key={f.key} className="flex flex-col gap-1.5">
          <label className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "#6b7590" }}>
            {f.label} <span style={{ color: "#ef4444" }}>*</span>
          </label>
          <input
            type={f.type}
            value={f.val}
            onChange={e => onChange(f.key, e.target.value)}
            className="w-full rounded-xl px-4 py-3.5 text-sm outline-none"
            style={{ background: "#181c25", border: "1px solid #232a3a", color: "#f0f2f5" }}
          />
        </div>
      ))}
    </div>
  );
}

/* ─── Signature Canvas ───────────────────────────────────── */
function SignatureCanvas({
  value,
  onSigned,
  label,
  color,
}: {
  value: string;
  onSigned: (dataUrl: string) => void;
  label: string;
  color: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isDrawing = useRef(false);
  const [isEmpty, setIsEmpty] = useState(!value);

  useEffect(() => {
    if (value && canvasRef.current) {
      const ctx = canvasRef.current.getContext("2d");
      if (!ctx) return;
      const img = new Image();
      img.onload = () => ctx.drawImage(img, 0, 0);
      img.src = value;
      setIsEmpty(false);
    }
  }, []);

  function getPos(e: React.MouseEvent | React.TouchEvent) {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    if ("touches" in e) {
      const t = e.touches[0];
      return { x: (t.clientX - rect.left) * scaleX, y: (t.clientY - rect.top) * scaleY };
    }
    return { x: ((e as React.MouseEvent).clientX - rect.left) * scaleX, y: ((e as React.MouseEvent).clientY - rect.top) * scaleY };
  }

  function startDraw(e: React.MouseEvent | React.TouchEvent) {
    e.preventDefault();
    isDrawing.current = true;
    setIsEmpty(false);
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    const p = getPos(e);
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
  }

  function draw(e: React.MouseEvent | React.TouchEvent) {
    e.preventDefault();
    if (!isDrawing.current) return;
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    const p = getPos(e);
    ctx.lineTo(p.x, p.y);
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
  }

  function endDraw(e: React.MouseEvent | React.TouchEvent) {
    e.preventDefault();
    if (!isDrawing.current) return;
    isDrawing.current = false;
    if (canvasRef.current) onSigned(canvasRef.current.toDataURL());
  }

  function clear() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.getContext("2d")?.clearRect(0, 0, canvas.width, canvas.height);
    setIsEmpty(true);
    onSigned("");
  }

  return (
    <div className="flex flex-col gap-2">
      <div className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "#6b7590" }}>
        {label}
      </div>
      <div
        className="relative rounded-xl overflow-hidden"
        style={{ background: "#0f1117", border: `1px solid ${isEmpty ? "#232a3a" : color + "60"}` }}
      >
        <canvas
          ref={canvasRef}
          width={380}
          height={120}
          style={{ width: "100%", height: 120, touchAction: "none", cursor: "crosshair", display: "block" }}
          onMouseDown={startDraw}
          onMouseMove={draw}
          onMouseUp={endDraw}
          onMouseLeave={endDraw}
          onTouchStart={startDraw}
          onTouchMove={draw}
          onTouchEnd={endDraw}
        />
        {isEmpty && (
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none gap-1">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" style={{ opacity: 0.3 }}>
              <path d="M3 14l4-4 3 3 4-5 4 4" stroke="#f0f2f5" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="text-xs" style={{ color: "#3a4255" }}>Assine com o dedo ou mouse</span>
          </div>
        )}
      </div>
      <button
        onClick={clear}
        className="text-xs self-end px-3 py-1.5 rounded-lg"
        style={{ color: "#6b7590", background: "#181c25", border: "1px solid #232a3a" }}
      >
        Limpar
      </button>
    </div>
  );
}

/* ─── Step: Assinatura ───────────────────────────────────── */
function StepAssinatura({
  nr,
  respName,
  vigiaName,
  signResp,
  signVigia,
  onSignResp,
  onSignVigia,
  hasVigia,
}: {
  nr: NRDefinition;
  respName: string;
  vigiaName: string;
  signResp: string;
  signVigia: string;
  onSignResp: (v: string) => void;
  onSignVigia: (v: string) => void;
  hasVigia: boolean;
}) {
  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-5">
      <div>
        <h2 className="text-xl font-bold" style={{ color: "#f0f2f5" }}>Assinatura Digital</h2>
        <p className="text-sm" style={{ color: "#6b7590" }}>Assine para validar a PET</p>
      </div>

      <div className="p-3.5 rounded-xl flex items-start gap-3" style={{ background: "#181c25", border: "1px solid #00d4aa20" }}>
        <span style={{ color: "#00d4aa" }}>ℹ</span>
        <p className="text-xs leading-relaxed" style={{ color: "#a8b0c0" }}>
          A assinatura digital tem valor equivalente à assinatura física conforme a política interna de segurança do trabalho.
        </p>
      </div>

      <div className="p-4 rounded-xl" style={{ background: "#181c25", border: "1px solid #232a3a" }}>
        <div className="flex items-center gap-2 mb-1">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold"
            style={{ background: `${nr.color}20`, color: nr.color }}
          >
            {respName.split(" ").map(n => n[0]).slice(0, 2).join("")}
          </div>
          <div>
            <div className="text-sm font-semibold" style={{ color: "#f0f2f5" }}>{respName}</div>
            <div className="text-[10px]" style={{ color: "#6b7590" }}>Responsável Técnico</div>
          </div>
        </div>
        <div className="mt-3">
          <SignatureCanvas
            value={signResp}
            onSigned={onSignResp}
            label="Assinatura do Responsável Técnico *"
            color={nr.color}
          />
        </div>
      </div>

      {hasVigia && (
        <div className="p-4 rounded-xl" style={{ background: "#181c25", border: "1px solid #232a3a" }}>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold" style={{ background: "#a855f720", color: "#a855f7" }}>
              {vigiaName.split(" ").map(n => n[0]).slice(0, 2).join("")}
            </div>
            <div>
              <div className="text-sm font-semibold" style={{ color: "#f0f2f5" }}>{vigiaName}</div>
              <div className="text-[10px]" style={{ color: "#6b7590" }}>Vigia de Segurança</div>
            </div>
          </div>
          <div className="mt-3">
            <SignatureCanvas
              value={signVigia}
              onSigned={onSignVigia}
              label="Assinatura do Vigia *"
              color="#a855f7"
            />
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Step: Review ───────────────────────────────────────── */
function StepReview({
  nr,
  fields,
  answers,
  workers,
  vigias,
  responsavel,
  date, time,
  onEmit,
}: {
  nr: NRDefinition;
  fields: Record<string, string>;
  answers: Record<string, CheckAnswer>;
  workers: Set<string>;
  vigias: Set<string>;
  responsavel: string | null;
  date: string; time: string;
  onEmit: () => void;
}) {
  const naoCount = Object.values(answers).filter(a => a === "NÃO").length;
  const answeredCount = Object.keys(answers).length;
  const respName = EMPLOYEES.find(e => e.id === responsavel)?.name ?? "—";
  const vigiaNames = VIGIAS.filter(v => vigias.has(v.id)).map(v => v.name.split(" ")[0]);
  const workerList = EMPLOYEES.filter(e => workers.has(e.id));

  return (
    <div className="px-5 pt-2 pb-6 flex flex-col gap-4">
      <div>
        <h2 className="text-xl font-bold" style={{ color: "#f0f2f5" }}>Revisão Final</h2>
        <p className="text-sm" style={{ color: "#6b7590" }}>Confirme e emita a PET</p>
      </div>

      {naoCount > 0 && (
        <div className="p-3.5 rounded-xl flex items-start gap-3" style={{ background: "#ef444415", border: "1px solid #ef444440" }}>
          <span style={{ color: "#ef4444" }}>⚠</span>
          <p className="text-xs" style={{ color: "#ef4444" }}>
            {naoCount} item(ns) NÃO conforme(s). Medida corretiva obrigatória antes de emitir.
          </p>
        </div>
      )}

      <div className="rounded-2xl overflow-hidden" style={{ background: "#181c25", border: `1px solid ${nr.color}40` }}>
        <div className="h-[3px]" style={{ background: nr.color }} />
        <div className="p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg" style={{ background: `${nr.color}20`, color: nr.color }}>
            {nr.icon}
          </div>
          <div>
            <div className="font-bold text-base" style={{ color: "#f0f2f5" }}>{nr.name}</div>
            <div className="text-xs" style={{ color: nr.color }}>{nr.code} · {fields["setor"] ?? "—"}</div>
          </div>
        </div>
      </div>

      {[
        { label: "Data / Hora", value: `${date} às ${time}` },
        { label: "Responsável", value: respName },
        { label: "Vigia(s)", value: vigiaNames.join(", ") || (nr.code !== "NR-33" ? "N/A" : "—") },
        { label: "Trabalhadores", value: `${workers.size} selecionado(s)` },
        { label: "Checklist", value: `${answeredCount}/${nr.checklist.length} · ${naoCount} NÃO` },
      ].map(row => (
        <div key={row.label} className="flex items-center justify-between py-2 border-b" style={{ borderColor: "#232a3a" }}>
          <span className="text-xs" style={{ color: "#6b7590" }}>{row.label}</span>
          <span className="text-xs font-semibold" style={{ color: "#f0f2f5" }}>{row.value}</span>
        </div>
      ))}

      {workerList.length > 0 && (
        <div className="flex flex-col gap-1.5">
          <div className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "#6b7590" }}>Equipe</div>
          {workerList.map(w => (
            <div key={w.id} className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full" style={{ background: nr.color }} />
              <span className="text-xs" style={{ color: "#a8b0c0" }}>{w.name}</span>
              <span className="text-[10px] ml-auto" style={{ color: "#3a4255" }}>{w.cargo}</span>
            </div>
          ))}
        </div>
      )}

      <button
        onClick={onEmit}
        className="w-full rounded-xl py-4 font-bold text-sm mt-2 flex items-center justify-center gap-2"
        style={{ background: "#00d4aa", color: "#0f1117" }}
      >
        Emitir PET
      </button>
    </div>
  );
}

/* ─── Main Wizard ────────────────────────────────────────── */
export default function NovaPET({ onBack, onEmit }: Props) {
  const [step, setStep] = useState(0);
  const [selectedNR, setSelectedNR] = useState<NRCode | null>(null);
  const [fields, setFields] = useState<Record<string, string>>({});
  const [checkAnswers, setCheckAnswers] = useState<Record<string, CheckAnswer>>({});
  const [selectedWorkers, setSelectedWorkers] = useState<Set<string>>(new Set());
  const [selectedVigias, setSelectedVigias] = useState<Set<string>>(new Set());
  const [responsavel, setResponsavel] = useState<string | null>(null);
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [time, setTime] = useState("08:00");
  const [signResp, setSignResp] = useState("");
  const [signVigia, setSignVigia] = useState("");
  const [emitted, setEmitted] = useState(false);

  const nr = NR_DATA.find(n => n.code === selectedNR) ?? null;
  const stepNames = getStepNames(selectedNR);
  const totalSteps = stepNames.length;
  const currentStepName = stepNames[step] as StepName;

  const hasVigia = selectedNR === "NR-33";

  const respName = EMPLOYEES.find(e => e.id === responsavel)?.name ?? "";
  const vigiaName = VIGIAS.find(v => selectedVigias.has(v.id))?.name ?? "";

  function canProceed(): boolean {
    switch (currentStepName) {
      case "NR": return !!selectedNR;
      case "Dados": return !!(fields["setor"] && nr?.fields.filter(f => f.required).every(f => !!fields[f.id]));
      case "Checklist": return Object.keys(checkAnswers).length >= (nr?.checklist.length ?? 0);
      case "Equipe": return !!responsavel && selectedWorkers.size > 0;
      case "Vigia": return selectedVigias.size > 0;
      case "Horário": return !!(date && time);
      case "Assinatura": return !!signResp && (!hasVigia || !!signVigia);
      case "Revisão": return true;
    }
  }

  function next() {
    if (canProceed() && step < totalSteps - 1) setStep(s => s + 1);
  }

  function back() {
    if (step > 0) setStep(s => s - 1);
    else onBack();
  }

  function toggleWorker(id: string) {
    setSelectedWorkers(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  }

  function toggleVigia(id: string) {
    setSelectedVigias(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  }

  function emit() {
    if (!nr) return;
    const resp = EMPLOYEES.find(e => e.id === responsavel)!;
    const vigiaList = VIGIAS.filter(v => selectedVigias.has(v.id));
    const workerList = EMPLOYEES.filter(e => selectedWorkers.has(e.id));
    const num = String(452620 + Math.floor(Math.random() * 1000));
    const pet: PETRecord = {
      id: Date.now().toString(),
      numero: num,
      nr: nr.code,
      setor: fields["setor"] ?? "—",
      local: fields[nr.fields[0]?.id] ?? "—",
      tipo: nr.name,
      responsavel: resp?.name ?? "—",
      responsavelId: responsavel!,
      vigias: vigiaList,
      workers: workerList,
      fields,
      checkAnswers,
      abertura: `${date} ${time}`,
      status: "aberta",
      nrDef: nr,
      rondas: [],
      signatureResp: signResp,
      signatureVigia: signVigia,
    };
    setEmitted(true);
    setTimeout(() => onEmit(pet), 1400);
  }

  if (emitted) {
    return (
      <div className="flex flex-col items-center justify-center min-h-full gap-6 px-8" style={{ background: "#0f1117" }}>
        <div className="w-20 h-20 rounded-full flex items-center justify-center text-3xl" style={{ background: "#00d4aa20", color: "#00d4aa" }}>✓</div>
        <div className="text-center">
          <div className="text-xl font-bold mb-1" style={{ color: "#f0f2f5" }}>PET Emitida!</div>
          <div className="text-sm" style={{ color: "#6b7590" }}>Redirecionando ao dashboard...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-full" style={{ background: "#0f1117" }}>
      {/* header */}
      <div className="flex items-center justify-between px-5 pt-12 pb-2">
        <button
          onClick={back}
          className="w-9 h-9 rounded-lg flex items-center justify-center border"
          style={{ background: "#181c25", borderColor: "#232a3a", color: "#a8b0c0" }}
        >
          <ArrowLeft />
        </button>
        <div className="text-sm font-bold" style={{ color: "#f0f2f5" }}>Nova PET</div>
        <div
          className="text-[10px] font-medium px-2.5 py-1 rounded-full"
          style={{ background: "#181c25", border: "1px solid #232a3a", color: "#6b7590", fontFamily: "'JetBrains Mono',monospace" }}
        >
          {step + 1}/{totalSteps}
        </div>
      </div>

      <StepBar step={step} stepNames={stepNames} />

      <div className="flex-1 overflow-y-auto">
        {currentStepName === "NR" && (
          <StepNR selected={selectedNR} onSelect={c => { setSelectedNR(c); setCheckAnswers({}); }} />
        )}
        {currentStepName === "Dados" && nr && (
          <StepFields nr={nr} values={fields} onChange={(id, val) => setFields(p => ({ ...p, [id]: val }))} />
        )}
        {currentStepName === "Checklist" && nr && (
          <StepChecklist nr={nr} answers={checkAnswers} onChange={(id, ans) => setCheckAnswers(p => ({ ...p, [id]: ans }))} />
        )}
        {currentStepName === "Equipe" && nr && (
          <StepEquipe nr={nr} selectedWorkers={selectedWorkers} responsavel={responsavel} onToggleWorker={toggleWorker} onSelectResponsavel={setResponsavel} />
        )}
        {currentStepName === "Vigia" && nr && (
          <StepVigia nr={nr} selectedVigias={selectedVigias} onToggle={toggleVigia} />
        )}
        {currentStepName === "Horário" && (
          <StepSchedule date={date} time={time} onChange={(k, v) => { if (k === "date") setDate(v); else setTime(v); }} />
        )}
        {currentStepName === "Assinatura" && nr && (
          <StepAssinatura
            nr={nr}
            respName={respName}
            vigiaName={vigiaName}
            signResp={signResp}
            signVigia={signVigia}
            onSignResp={setSignResp}
            onSignVigia={setSignVigia}
            hasVigia={hasVigia}
          />
        )}
        {currentStepName === "Revisão" && nr && (
          <StepReview
            nr={nr}
            fields={fields}
            answers={checkAnswers}
            workers={selectedWorkers}
            vigias={selectedVigias}
            responsavel={responsavel}
            date={date} time={time}
            onEmit={emit}
          />
        )}
      </div>

      {currentStepName !== "Revisão" && (
        <div className="px-5 pb-8 pt-4">
          <button
            onClick={next}
            disabled={!canProceed()}
            className="w-full rounded-xl py-4 font-bold text-sm transition-all"
            style={{
              background: canProceed() ? "#00d4aa" : "#1e2330",
              color: canProceed() ? "#0f1117" : "#3a4255",
            }}
          >
            {currentStepName === "Assinatura" ? "Revisar PET" : "Continuar"}
          </button>
        </div>
      )}
    </div>
  );
}
